package encriptadordesencriptador;
/**
 * Clase la cual se encarga de encriptar y desencriptar un texto
 * @author Kevin Sanchez, Daniel Barrantes, Kevin Lanzas
 * 
 */
public class EncriptarDesencriptar {
  
  /**
   * metodo con la tarea de encriptar un texto
   * @param pTexto es de tipo String y es el texto a encriptar
   * @return el texto que se ingreso encriptado
   */
  public String encriptar(String pTexto){
    char array[] = pTexto.toCharArray();
    
    for (int i = 0; i < array.length; i++){
      array[i] = (char)(array[i] + (char)7);
    }
    
    String encriptado = String.valueOf(array);
    return encriptado;
  }
  
  /**
   * Metodo con la tarea de desencriptar un texto
   * @param pTexto es de tipo String y es el texto a desencriptar
   * @return el texto encriptado ya desencriptado
   */
  public String desencriptar(String pTexto){
    char arrayDesencriptar[] = pTexto.toCharArray();
    
    for (int i=0; i < arrayDesencriptar.length; i++){
      arrayDesencriptar[i] = (char)(arrayDesencriptar[i]-(char)7);
    }
    String desencriptado = String.valueOf(arrayDesencriptar);
    return desencriptado;
  }
}
