package usuarios;

import gestorbasedatos.BaseDatosUsuarios;
import javax.xml.transform.TransformerException;

/**
 * Clase Admin la cual se encarga de presentar los datos de un administrador y permite realizar sus funciones
 * @author Kevin Sanchez, Kevin Lanzas, Daniel Barrantes
 */
public class Admin extends Usuario{
  private String contrasenia;    
   
  /**
   * Metodo constructor de la clase Admin
   * @param pNombre es de tipo String y es el nombre del usuario
   * @param pCorreo es de tipo String y es el correo del usuario
   * @param pUsuario es de tipo String y es el correo del usuario
   * @param pContrasenia es de tipo String y es la contrasenia del usuario 
   */  
  public Admin(String pNombre, String pCorreo, String pUsuario, String pContrasenia){
    super(pNombre, pCorreo, pUsuario);
    contrasenia = pContrasenia;
  }
  
  public void registrarUsuario(UsuarioFinal pUsuario) throws Exception{
    BaseDatosUsuarios baseD = new BaseDatosUsuarios();
    baseD.agregarUsuario(pUsuario);
  }
  
  public void eliminarUsuario(String eliminado) throws TransformerException{
    BaseDatosUsuarios baseD = new BaseDatosUsuarios();
    baseD.eliminarUsuario(eliminado);
  }
}