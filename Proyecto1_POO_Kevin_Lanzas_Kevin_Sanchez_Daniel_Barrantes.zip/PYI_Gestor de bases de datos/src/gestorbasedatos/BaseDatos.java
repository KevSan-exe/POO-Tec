package gestorbasedatos;

import encriptadordesencriptador.EncriptarDesencriptar;
import java.awt.List;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Metodo BaseDatos la cual se encarga de las funciones de las bases de datos de
 * los usuarios
 * @author Daniel Barrantes, Kevin Sanchez, Kevin Lanzas
 */
public class BaseDatos {
  private static Document documento;
  private static Element raiz;
  private static String nombreDoc;
  private static Element elemento; 
  
  
 /**
  * Metodo la cual se encarga de crear una base de datos
  * @param pNombre es de tipo String y es el nombre de la base de datos a crear
  * @throws ParserConfigurationException
  * @throws TransformerException 
  */
  public void crearBaseDatos(String pNombre) throws ParserConfigurationException, TransformerException{
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder dBuilder;
    dBuilder = dbFactory.newDocumentBuilder();
    Document doc = dBuilder.newDocument();
    documento = doc;
    raiz = documento.createElement(pNombre);
    documento.appendChild(raiz);
    nombreDoc = pNombre;
    int id=1;
    guardar();
  }
  
  public Document getDocumento(){
    return documento;
  }
  
  public Element getRaiz(){
    return raiz;
  }
  
  public String getnombreDoc(){
    return nombreDoc;
  }
  
  public Element getElemento(){
    return elemento;
  }
  /**
   * Metodo la cual se encarga de cargar informacion en una base de datos
   * @throws TransformerException 
   */
  public void guardar() throws TransformerException{
    String nombreDocumento = nombreDoc + ".xml";
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();           
    DOMSource source = new DOMSource(documento);   
    StreamResult file = new StreamResult(new File(nombreDocumento));
    transformer.transform(source, file); 
      
  }
  /**
   * Metodo que se encargar de insertar los elementos ya creados een la funcion sobrecargada del mismo nombre en las tablas
   * @param pNombreEtiqueta es de tipo String y es la etiqueta deel xml
   * @param valor es de tipo String y es lo que va dentro de la etiqueta
   * @param pDocumento es de tipo Document y es el documento donde se guardara
   * @return retorna el nodo el cual se va a garegar
   */ 
  public static Node crearElementoTabla(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
  /**
   * Metodo la cual se encarga de crear los elementos que iran en el xml de la tabla
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @param pNombreCampo es de tipo String y es el nombre del campo
   * @param pTipo es  de tipo String y es el tipo del dato
   * @param pRequerido es de tipo boolean y es si es requerido 
   * @param pDocumento es de tipo Document y es el documento donde se va a guardar
   * @return retorna la variable usuario el cual contiene los elementos creados
   */
  public static Node crearElementoTabla(String pNombreTabla,String pNombreCampo,String pTipo,boolean pRequerido, Document pDocumento) {
    Element usuario = pDocumento.createElement(pNombreTabla);
    usuario.appendChild(crearElementoTabla(pNombreCampo,pNombreCampo, pDocumento));
    usuario.appendChild(crearElementoTabla("Tipo",pTipo, pDocumento));
    if(pRequerido==true){
      usuario.appendChild(crearElementoTabla("Requerido","SI", pDocumento));
    }else{
      usuario.appendChild(crearElementoTabla("Requerido","NO", pDocumento));
    }
    return usuario;
  }
  /**
   * Metodo que se encarga de revisar si la tabla esta vacia
   * @param tabla es de tipo NodeListt y es la tabla 
   * @return retorna un valos booleano dependiendo del estado de la tabla
   */
  public boolean esTablaVacia(NodeList tabla){
    int cant = 0;
    for (int i = 0; i < tabla.getLength(); i++){
      cant++; 
    }
    if (cant == 1) {
      return true;
    }else{
      return false;
    }
  }
  /**
   * Metodo que se encarga de eliminar una tabla solamente si no posee datos
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @throws TransformerConfigurationException
   * @throws TransformerException
   * @throws SAXException
   * @throws IOException
   * @throws ParserConfigurationException 
   * @return retorna un valor booleano dependiendo si se pudo borrar o no
   */
  public boolean eliminarTabla(String pNombreBaseDatos, String pNombreTabla) throws TransformerConfigurationException, TransformerException, SAXException, IOException, ParserConfigurationException{
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      NodeList nodeList = document.getElementsByTagName(pNombreTabla);
      for (int i = 0; i < nodeList.getLength(); i++){
        Node node = nodeList.item(i);
        Element eElement = (Element) node;
        if(eElement.getTagName().equals(pNombreTabla)){
          NodeList tabla = eElement.getChildNodes();
          if (esTablaVacia(tabla)){ 
            node.getParentNode().removeChild(eElement);
            File archivoNuevo = new File(pNombreBaseDatos + ".xml");
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(archivoNuevo);
            Source input = new DOMSource(document);
            transformer.transform(input, output);
            return true;
          }else{
            return false; 
          }
        }
          
      }return false; 
      
    } catch (IOException | ParserConfigurationException | DOMException | SAXException e){} 
      return false;
  }
 /**
  * Metodo que se encarga de agregar una tabla a una base de datos con su estructura
  * @param pNombreBaseDatos es de tipo String y es el nombre de la abse de datos
  * @param pNombreTabla es de tipo String y es el nombre de la tabla
  * @param pNombreCampo es de tipo String y es el nombre del campo
  * @param pTipo es de String y es el tipo del dato que ingreso el usuario
  * @param pRequerido es de tipo booleann y es si es requerido
  * @throws Exception 
  */
  public void agregarTabla(String pNombreBaseDatos,String pNombreTabla,String pNombreCampo,String pTipo,boolean pRequerido) throws Exception{
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      int p=posicionTabla(pNombreTabla,rootElement);
      DOMSource source = new DOMSource(document);
      
      if(rootElement.getChildNodes().getLength()==0){
        rootElement.appendChild(usuario);
        usuario.appendChild(crearElementoTabla("Campos",pNombreCampo,pTipo,pRequerido,document));
      }else if(validarTabla(pNombreTabla,rootElement)){
          rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla(pNombreCampo,pNombreCampo,document));
          rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla("Tipo",pTipo, document));
          if(pRequerido==true){
            rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla("Requerido","SI", document));
          }else{
            rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla("Requerido","NO", document));
          }
          
      }else{
          rootElement.appendChild(usuario);
          usuario.appendChild(crearElementoTabla("Campos",pNombreCampo,pTipo,pRequerido,document));    
      }
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }
 /**
  * Metodo que se encarga de validar el nombre de la tabla
  * @param nombre es de tipo String y es el nombre de la tabla
  * @param rootElement es de tipo Element y es el que tiene los elementos del documento
  * @return retorna un valor booleano dependiendo del resultado
  */
  public boolean validarTabla(String nombre,Element rootElement){
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return true;
      }
    }return false;   
  }
  /**
   * Metodo que se encarga de averiguar en que posicion se encuentra la  tabla
   * @param nombre es de tipo String y es el nombre de la tabla
   * @param rootElement es de tipo Element y es el que tiene los elementos del documento
   * @return retorna un valor entero el cual es donde se encuentra la tabla
   */
  public int posicionTabla(String nombre,Element rootElement){
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }
  /**
   * Metodo la cual se encarga de validar que el nombre de la tabla se encuentre en la basae de datos
   * @param nombre es de tipo String y es el nombre de la tabla
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException 
   * @return retorna un valor booleano dependiendo del resultado de la busqueda
   */
  public boolean validarNombreTabla(String nombre,String pNombreBaseDatos) throws ParserConfigurationException, SAXException, IOException{
    File archivo = new File(pNombreBaseDatos + ".xml");
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    Document document = documentBuilder.parse(archivo);
    Element rootElement = document.getDocumentElement();
      
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return true;
      }
    }return false;   
  }
  /**
   * Metodo la cual se encarga de agregar registros a las tablas
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @param pLista es de tipo List y es la etiqueta 
   * @param pLista2 es de tipo List y son los datos que ingreso el usuario
   * @throws Exception 
   */
  public void agregarRegistros(String pNombreBaseDatos,String pNombreTabla,List pLista, List pLista2) throws Exception{
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      int p=posicionTabla(pNombreTabla,rootElement);
      DOMSource source = new DOMSource(document);
  
      rootElement.getChildNodes().item(p).appendChild(crearElementoInsertar(pLista,pLista2,document));
      
      
      
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }
  /**
   * Metodo la cual se encarga de ingresar registros a las tablas
   * @param pLista es de tipo List y es la etiqueta
   * @param pLista2 es de tipo List y son los datos que ingreso el usuario
   * @param pDocumento es de tipo Document y es el documento donde se guardara
   * @return retorna el nodo el  caul tiene los elementos que se deben insertar
   */
  public static Node crearElementoInsertar(List pLista,List pLista2, Document pDocumento) {
    Element usuario = pDocumento.createElement("Registros");
    int j=0;
    for(int i=0; i<pLista.getItemCount();i++){
      usuario.appendChild(crearElementoTabla(pLista2.getItem(j),pLista.getItem(i), pDocumento));   
      j+=3;
    }return usuario;
  }
  /**
   * Metodo la cual se encarga de sacar el largo de la estructura de la tabla 
   * @param pLista es de tipo List y es la estructura de la tabla
   * @return retorna un entero que seria el lago de la estructura de la tabla
   */
  public int estructuralargoInsertar(List pLista){
    int cont=0;
    for(int i=0; i< pLista.getItemCount();i+=3){
      cont++; 
    }return cont;
  }
  /**
   * Metodo la cual se encarga de verificar si lo que el usuario digito se encuentra en la estructura de la tabla
   * @param pLista es de tipo List y es la etiqueta
   * @param pLista2 es de tipo List y son los datos que ingreso el usuario
   * @return retorna un valor booleano dependiendo del resultado
   */
  public boolean VerificarEstructuraSeleccionarDatos(List pLista,List pLista2){
    int item=0;
    for(int i=0; i< pLista.getItemCount();i++){
      for(int j=0; j< pLista2.getItemCount();j+=3){
        if(pLista.getItem(i).equals(pLista2.getItem(j))){
          item++;
          break;
        }
      }
    }return item==pLista.getItemCount();
  }
  /**
   * Metodo la cual se encarga de printear al usuario lo que seleeciono
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @param pLista es de tipo lista y es lo que selecciono el usuario
   * @param pCondicion es de tipo String y es la etiqueta
   * @param pCondicion2 es de tipo String y es la condicion que digito el usuario
   * @param pSigno es de tipo String y es el signo que digito el usuario
   * @return retorna una lista la cual contiene los datos que solicito el usuario
   */
  public List PrintearSeleccionarDatos(String pNombreBaseDatos,String pNombreTabla,List pLista,String pCondicion, String pCondicion2,String pSigno){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element elem=document.getDocumentElement();
      int posicion=posicionTabla(pNombreTabla,elem);
      boolean bandera=false;
      List listita=new List();
      if("".equals(pSigno)){
         for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
           for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
             for(int y=0; y< pLista.getItemCount();y++){  
               if(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName().equals(pLista.getItem(y))){
                 listita.add(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
                 break;
               }  
             }     
           }
         }return listita;
      }else if(verificarCajita(pSigno)==1){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                bandera=true;
                break;
              }
            }
          }if(bandera==true){
             for(int x=0; x< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();x++){
               for(int y=0; y< pLista.getItemCount();y++){  
                 if(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                   listita.add(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                   bandera=false;
                   break;
                 }  
               }  
             }
          }
        } return listita;
        
      }else if(verificarCajita(pSigno)==2){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(!pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                bandera=true;
                break;
              }
            }
          }if(bandera==true){
             for(int x=0; x< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();x++){
               for(int y=0; y< pLista.getItemCount();y++){  
                 if(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                   listita.add(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                   bandera=false;
                   break;
                 }  
               }  
             }
          }
        }return listita;
        
      }else if(verificarCajita(pSigno)==3){
        if("Int".equals(validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2); 
          return PrintearSeleccionarEnteros(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);
        }else{
          float condicion2=Float.parseFloat(pCondicion2);
          return PrintearSeleccionarFlotantes(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);   
            
        }
          
      }else if(verificarCajita(pSigno)==4){
        if("Int".equals(validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2);
          return PrintearSeleccionarEnteros(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);
        }else if("Float".equals(validarTipo(pCondicion2))){
          float condicion2=Float.parseFloat(pCondicion2);
          return PrintearSeleccionarFlotantes(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);
        }
      
      }         
    } catch (Exception e){} 
      return null;
  }
  /**
   * Metodo la cual se encarga de verificar que lo que el usuario inserto en la caja de signos
   * @param pValor es de tipo String y es el signo que el usuario escogio
   * @return retorna un entero donde 1 es ==, 2 es !=, 3 es mayor y 4 es menor
   */
  public int verificarCajita(String pValor){
    if("==".equals(pValor)){
      return 1;
    }else if("!=".equals(pValor)){
      return 2;
    }else if(">".equals(pValor)){
      return 3;
    }else if("<".equals(pValor)){
      return 4;
    }return 0;
  }
  /**
   * Metodo que se encarga de validar el tipo que ingresa el usuario
   * @param cadena es de tipo String y es la cadena de caracteres que se va a validar
   * @return retorna un String el cual dice que tipo es lo que el usuario ingreso
   */
  public String validarTipo(String cadena){
    boolean f=true;
    if (f==true){
      try {
        Integer.parseInt(cadena);
          return "Int";

      }catch(NumberFormatException nfe){
        f=false;
      }
    }if(f==false){
       for(int i =0; i<cadena.length(); i++){
         if(cadena.charAt(i) == '.'){
           return "Float";
         }
       }f=true;
    }if(f==true){
      String cadena2 = cadena.toLowerCase();
      if("false".equals(cadena2) || "true".equals(cadena2)){
        return "Logico";
      }
    }return "String";
  }
  /**
   * Metodo la cual se encarga de printear cuantos registros fueron eliminados
   * @param pNombreBaseDatos es de tipo String que es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @param pCondicion es de tipo String y es la etiqueta que puso el usuario
   * @param pCondicion2 es de tipo String y son los datos que digito el ususario
   * @param pSigno es de tipo String y es el signo que digito el usuario
   * @return 
   */
  public int PrintearEliminarRegistros(String pNombreBaseDatos,String pNombreTabla,String pCondicion, String pCondicion2,String pSigno){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element elem=document.getDocumentElement();
      int posicion=posicionTabla(pNombreTabla,elem);
      boolean bandera=false;
      List listita=new List();
      DOMSource source = new DOMSource(document);
      int contEliminados=0;
      if("".equals(pSigno)){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          elem.getChildNodes().item(posicion).removeChild(elem.getChildNodes().item(posicion).getChildNodes().item(i));
          contEliminados++;
          i=0;
        }   
      }else if(verificarCajita(pSigno)==1){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                elem.getChildNodes().item(posicion).removeChild(elem.getChildNodes().item(posicion).getChildNodes().item(i));
                i=0;
                contEliminados++;
                break;
              }
            }
          }
        }
      }else if(verificarCajita(pSigno)==2){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(!pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                elem.getChildNodes().item(posicion).removeChild(elem.getChildNodes().item(posicion).getChildNodes().item(i));
                i=0;
                contEliminados++;
                break;
              }
            }
          }
        } 
      }else if(verificarCajita(pSigno)==3){
        if("Int".equals(validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2);
          contEliminados=EliminarEnteros(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);
        }else if("Float".equals(validarTipo(pCondicion2))){
          float condicion2=Float.parseFloat(pCondicion2);
          contEliminados=EliminarFlotantes(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);    
        }
      }else if(verificarCajita(pSigno)==4){
        if("Int".equals(validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2);
          contEliminados=EliminarEnteros(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);     
        }else if("Float".equals(validarTipo(pCondicion2))){
          float condicion2=Float.parseFloat(pCondicion2);
          contEliminados=EliminarFlotantes(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);      
        }
      }Transformer transformer = TransformerFactory.newInstance().newTransformer();
       Result output = new StreamResult(archivo);
       Source input = new DOMSource(document);
       transformer.transform(input, output); 
       return contEliminados;
    }catch (Exception e){} 
     return 0;
    
  }
  /**
   * Metodo que se enncarga de printeaar los datos que el usuario selecciono cuando son flotantes
   * @param pCondicion es de tipo String y es la etiqueta
   * @param pCondicion2 es de tipo String y son los datos que digito el usuario
   * @param pPosicion es de tipo int y es la posicion de la tabla
   * @param pElem es de tipo Element y son los elementos del xml
   * @param pListita es de tipo List son los elementos que se van a printear 
   * @param pBandera es de tipo boolean y es un validador
   * @param pLista es de tipo List y son los campos seleccionados por el usuario
   * @param pSigno es de Tipo String y es el signo que digito el usuario
   * @return retorna una lista con los elemntos a printear
   */
  public List PrintearSeleccionarFlotantes(String pCondicion,float pCondicion2,int pPosicion,Element pElem,List pListita,boolean pBandera,List pLista,String pSigno){
    if (verificarCajita(pSigno)==3){
      for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
              if(modificador2 > pCondicion2){
                pBandera=true;
                break;
              }
          }
        }if(pBandera==true){
          for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
            for(int y=0; y< pLista.getItemCount();y++){  
              if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                pBandera=false;
                break;
              }  
            }  
          }
        }
      }return pListita;
    }else{
      for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 < pCondicion2){
              pBandera=true;
              break;
            }
          }
        }if(pBandera==true){
          for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
            for(int y=0; y< pLista.getItemCount();y++){  
              if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                pBandera=false;
                break;
              }  
            }  
          }
        }
      } return pListita;     
    }
  }
  /**
   * Metodo que se encarga de printear los elementos que selecciono el usuario cuando son enteros
   * @param pCondicion es de tipo String y es la etiqueta que digito el usuario
   * @param pCondicion2 es de tipo String y es la condicion que digito el usuario
   * @param pPosicion es de tipo int y es la posicion de la tabla
   * @param pElem es de tipo Element y son lso datos del xml
   * @param pListita es de tipo List y son los elementos que se tienen que printear
   * @param pBandera es de tipo boolean y es un validador
   * @param pLista es de tipo List y es la seleccion que hizo el usuario
   * @param pSigno es de  tipo String y es el signo que digito el usuario
   * @return retorna una lista la cual contiene los elementos que el usuario solicito
   */
  public List PrintearSeleccionarEnteros(String pCondicion,float pCondicion2,int pPosicion,Element pElem,List pListita,boolean pBandera,List pLista,String pSigno){
    if(verificarCajita(pSigno)==3){
      for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 > pCondicion2){
              pBandera=true;
              break;
            }
          }
        }if(pBandera==true){
           for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
             for(int y=0; y< pLista.getItemCount();y++){  
               if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                 pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                 pBandera=false;
                 break;
               }  
             }  
           }
        }
      } return pListita; 
    }else{
       for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
         for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
           if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
             int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
             if(modificador2 < pCondicion2){
               pBandera=true;
               break;
             }
           }
         }if(pBandera==true){
            for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
              for(int y=0; y< pLista.getItemCount();y++){  
                if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                  pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                  pBandera=false;
                  break;
                }  
              }  
            }
         }
       } return pListita;
    }
  }
  /**
   * Metodo que se encarga de printear cuantos elementos fueron eliminados cuando son enteros
   * @param pCondicion es de tipo String y es la etiqueta que digito el usuario
   * @param pCondicion2 es de tipo String y es la condicion que digito el usuario
   * @param pPosicion es de tipo int y es la posicion de la tabla
   * @param pElem es de tipo Element y son los elementos del xml
   * @param pBandera es de tipo boolean y es un validador
   * @param pSigno es de tipo String y es el signo que digito el usuario
   * @param pCont es de tipo int y es el contador
   * @return retorna un entero el cual es la cantidad de registros que se eliminaron 
   */        
  public int EliminarEnteros(String pCondicion,float pCondicion2,int pPosicion,Element pElem,boolean pBandera,String pSigno,int pCont){
    if(verificarCajita(pSigno)==3){       
      for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 > pCondicion2){
              pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
              i=0;
              pCont++;
              break;
            }
          }
        }
      }
    }else{
       for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
         for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
           if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
             int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
             if(modificador2 < pCondicion2){
               pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
               i=0;
               pCont++;
               break;
             }
           }
         }
       }    
    }return pCont;
  }
  /**
   * Clase que se encarga de printear cuantos registros fueron eliminados cuando son enteros
   * @param pCondicion es de tipo String y es la etiqueta que digito el usuario
   * @param pCondicion2 es de tipo String y es la condicion que dijito el usuario
   * @param pPosicion es de tipo int y es la posicion de la tabla
   * @param pElem es de tipo Element y son los elementos del xml
   * @param pBandera es de tipo boolean y es un validador
   * @param pSigno esde tipo String y es el signo que digito el usuario
   * @param pCont es de tipo int y es el contador
   * @return retorna la cantidad de registros eliminados 
   */
  public int EliminarFlotantes(String pCondicion,float pCondicion2,int pPosicion,Element pElem,boolean pBandera,String pSigno,int pCont){
    if(verificarCajita(pSigno)==3){       
      for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            Float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 > pCondicion2){
              pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
              i=0;
              pCont++;
              break;
            }
          }
        }
      }
    }else{
      for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            Float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 < pCondicion2){
              pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
              i=0;
              pCont++;
              break;
            }
          }
        }
      }    
    }return pCont;
  }
  /**
   * Metodo que printea la estructura de la tabla en la parte de CrearTabla 
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @return retorna una lista con los elementos a printear
   * @throws SAXException
   * @throws ParserConfigurationException
   * @throws IOException 
   */
  public List printearEstructuraCrear(String pNombreBaseDatos,String pNombreTabla) throws SAXException, ParserConfigurationException, IOException{
    File archivo = new File(pNombreBaseDatos + ".xml");
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    Document document = documentBuilder.parse(archivo);
      
    Element elem=document.getDocumentElement(); 
    int posicion=posicionTabla(pNombreTabla,elem);
    List lista=new List();
    for(int i=0; i<elem.getChildNodes().item(posicion).getChildNodes().item(0).getChildNodes().getLength();i++){
      lista.add(elem.getChildNodes().item(posicion).getChildNodes().item(0).getChildNodes().item(i).getTextContent());
    }return lista;
  }
  /**
   * Metodo para validar el nombre de una cadena de caracteres
   * @param pNombre es de tipo String y es el nombre de la tabla o base de datos a validar
   * @return retorna un valor booleano dependiendo del resultado
   */
  public boolean validarNombre(String pNombre){
    String texto="abcdefghijklmnopqrstuwxyz";
    String minusculo=pNombre.toLowerCase();
    int cont=0;  
    for(int i=0;i< pNombre.length();i++){
      for(int j=0; j< texto.length();j++){
        if(minusculo.charAt(i)==texto.charAt(j)){
          cont++;
          break;
        }
      }
    }if(cont==pNombre.length()){
       return true; 
    }else{
       return false;
    }
  }
  /**
   * Metodo para validar que no existan campos repetidos en la estructura de la tabla
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreCampo es de tipo String y es el nombre del campo
   * @return retorna un booleano segun el resultado
   */
  public boolean validarRepetidos(String pNombreTabla, String pNombreBaseDatos,String pNombreCampo){  
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      int p=posicionTabla(pNombreTabla,rootElement);
      DOMSource source = new DOMSource(document);
      if(rootElement.getChildNodes().item(p).getChildNodes().getLength()==0){
        return true;    
      }else{
        for(int i=0; i< rootElement.getChildNodes().item(p).getChildNodes().item(0).getChildNodes().getLength(); i++){
          if(rootElement.getChildNodes().item(p).getChildNodes().item(0).getChildNodes().item(i).getNodeName().equals(pNombreCampo)){
            return false; 
          }
        }return true;
      }
    }catch(IOException | ParserConfigurationException | SAXException e){}
      return false;
  }
   /**
    * Metodo para validar que la tabla que el usuario digita se enceuntre dentro de la base de datos
    * @param pNombreTabla es de tipo String y es el nombre de la tabla
    * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
    * @return retorna un valor booleano dependiendo del resultado
    */
   public boolean validarCambiarNombreTabla(String pNombreTabla, String pNombreBaseDatos){  
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      DOMSource source = new DOMSource(document);
      if(rootElement.getChildNodes().getLength()==0){
        return false;    
      }else{
        for(int i=0; i< rootElement.getChildNodes().getLength(); i++){
          if(rootElement.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
            return true; 
          }
        }return false;
      }
    }catch(IOException | ParserConfigurationException | SAXException e){}
      return false;
  }
}

 
 