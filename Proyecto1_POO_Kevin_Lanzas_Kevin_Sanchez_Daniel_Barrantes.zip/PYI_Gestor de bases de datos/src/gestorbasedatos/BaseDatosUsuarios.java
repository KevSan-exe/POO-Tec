package gestorbasedatos;

import usuarios.UsuarioFinal;

import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import encriptadordesencriptador.EncriptarDesencriptar;
import java.awt.List;
import java.util.ArrayList;

/**
 * Metodo BaseDatosUsuarios la cual se encarga de ingresar usuarios finales a la 
 * base de datos donde se almacenan
 * @author Daniel Barrantes, Kevin Sanchez, Kevin Lanzas
 */
public class BaseDatosUsuarios {
  /**
   * Metodo agregarUsuario que agrega un usuario al archivo Xml donde se almacenan
   * @param pUsuario que es de tipo UsuarioFinal y es el usuario que se va agregar
   * @throws Exception 
   */
  public void agregarUsuario(UsuarioFinal pUsuario) throws Exception{
    try{
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      
      DOMSource source = new DOMSource(document);
      
      rootElement.appendChild(crearElementoUsuario(pUsuario, document));

      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }
  /**
   * Metodo que se encarga de agregar una base de datos
   * @param pNombre es de tipo String  y es el nombre de la base de datos
   * @throws Exception 
   */
  public void agregarBaseDatos(String pNombre) throws Exception{
    try{
      File archivo = new File("nombresbasesdedatos.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      int id=(int)(Math.random()*1000)+1;
      String idString=Integer.toString(id);
      DOMSource source = new DOMSource(document);
      
      rootElement.appendChild(crearElementoBaseDatos(pNombre,idString,document));
      
      
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }
  /**
   * Metodo que se encarga de crear los elementos que se deben insertan en la base de datos
   * @param pNombre es de tipo String y es el nombre de la base de datos
   * @param pId Es de tipo String y es el ID de la base de datos
   * @param pDocumento es de tipo Document y es el documento donde se guardara la base de datos
   * @return retorna el nodo que tiene que ser insertado
   */
  public static Node crearElementoBaseDatos(String pNombre,String pId,Document pDocumento) {
    Element usuario = pDocumento.createElement("BaseDatos");
    usuario.appendChild(crearElementoBaseDatosS("nombre", pNombre, pDocumento));
    usuario.appendChild(crearElementoBaseDatosS("ID", pId, pDocumento));
    return usuario;
  }
  /**
   * Metodo que se encarga de devolver el nodo base de datos que se ingresara a la base de datos
   * @param pNombreEtiqueta Es de tipo String y es el nombre de la etiqueta que aparecera en el xml
   * @param valor Es de tipo String y es lo que esta dentro de la etiqueta
   * @param pDocumento Es de tipo Document y es el documento donde se va a guardar la  base de datos
   * @return retorna el nodo que se va a ingresar
   */ 
  public static Node crearElementoBaseDatosS(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
  
  /**
   * Metodo que se encarga de devolver el nodo usuario final que se ingresara a la base de datos
   * @param pNombreEtiqueta Es de tipo String y es el nombre de la etiqueta que aparecera en el xml
   * @param valor Es de tipo String y es lo que esta dentro de la etiqueta
   * @param pDocumento Es de tipo Document y es el documento donde se guardara la base de datos
   * @return retorna el nodo que se va a ingresar 
   */
  public static Node crearElementoUsuario(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
  
  /**
   * Metodo el cual se encarga de crear el nodo usuario final que se ingresara a la base de datos
   * @param pDocumento Es de tipo Document y es el documento donde se va a guardar la base de datos
   * @param pUsuario Es de tipo UsuarioFinal y es el usuario al que se va a agregar a la base de datos
   * @return retorna el nodo del usuario
   */  
  public static Node crearElementoUsuario(UsuarioFinal pUsuario, Document pDocumento) {
    EncriptarDesencriptar encriptador=new EncriptarDesencriptar();
    Element usuario = pDocumento.createElement("Usuario");
    usuario.appendChild(crearElementoUsuario("nombre",encriptador.encriptar(pUsuario.getNombre()), pDocumento));
    usuario.appendChild(crearElementoUsuario("puesto",encriptador.encriptar(pUsuario.getPuesto()), pDocumento));
    usuario.appendChild(crearElementoUsuario("nombreUsuario",encriptador.encriptar(pUsuario.getUsuario()), pDocumento));
    usuario.appendChild(crearElementoUsuario("correo",encriptador.encriptar(pUsuario.getCorreo()), pDocumento));
    usuario.appendChild(crearElementoUsuario("telefono",encriptador.encriptar(pUsuario.getTelefono()), pDocumento));
    usuario.appendChild(crearElementoUsuario("contrasenia",encriptador.encriptar(pUsuario.getContrasenia()), pDocumento));
    return usuario;
  }
  /**
   * Metodo que se encarga de eliminar un usuario 
   * @param pEliminado Es de tipo String y es el correo del usuario que va a ser eliminado
   * @return retorna un valor booleano depemndiendo del resultado
   * @throws TransformerConfigurationException
   * @throws TransformerException 
   */
  public boolean eliminarUsuario(String pEliminado) throws TransformerConfigurationException, TransformerException{
    try{
      EncriptarDesencriptar desencriptaa=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      NodeList nodeList = document.getElementsByTagName("Usuario");
      for (int i = 0; i < nodeList.getLength(); i++){
        Node node = nodeList.item(i);
        Element eElement = (Element) node;
        String texto= desencriptaa.desencriptar(eElement.getElementsByTagName("nombreUsuario").item(0).getTextContent());
        if (texto.equals("admin")){
            
        }else if(texto.equals(pEliminado)){
          node.getParentNode().removeChild(eElement);
          File archivoNuevo = new File("basededatosusuarios_Admin.xml");
          Transformer transformer = TransformerFactory.newInstance().newTransformer();
          Result output = new StreamResult(archivoNuevo);
          Source input = new DOMSource(document);
          transformer.transform(input, output);
          return true;
        }
      }return false; 
    }catch (IOException | ParserConfigurationException | DOMException | SAXException e){} 
     return false;
  }
  /**
   * Metodo que se encarga de recorrar un xml
   * @param cont Es de tipo int y es un contador para recorrer el  xml
   * @return retorna el elemento que se esta buscando
   */
  public String recorrer(int cont){
    try{
      EncriptarDesencriptar desencriptor=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      for (int i = cont; i < childeren.item(0).getChildNodes().getLength(); i++){
        int contador=0;
        for (int j = 0; j < childeren.item(0).getChildNodes().item(i).getChildNodes().getLength(); j++){
          if(contador==2){
            String printear=(desencriptor.desencriptar(childeren.item(0).getChildNodes().item(i).getChildNodes().item(j).getTextContent()));
            return printear;
          }else{
            contador++;
          }          
        }    
      } 
    }catch (Exception e){} 
      return null;  
  }
  /**
   * Metodo que se encarga de retornar el largo de un elemento
   * @return retorna el largo de un elemento
   */
  public int prueba(){
    try{
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      return childeren.item(0).getChildNodes().getLength();
    } catch (Exception e){} 
      return 0;
  }
  /**
   * Metodo que se encarga de recorrer un xml
   * @param pUsuario Es de tipo String y es el usuario al que se va a validar
   * @param pContrasenia es de tipo String y es la contrasenia del usuario 
   * @return retorna un valor booleano dependiendo del resultado
   */
  public boolean recorrer(String pUsuario, String pContrasenia){
    try{
      EncriptarDesencriptar desencriptador=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();  
      for (int i = 0; i <  childeren.item(0).getChildNodes().getLength(); i++){
        int bandera1=0;
        int cont=0;
        for (int j = 0; j < childeren.item(0).getChildNodes().item(i).getChildNodes().getLength(); j++){
          String desencriptado=desencriptador.desencriptar(childeren.item(0).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
          if(pUsuario.equals(desencriptado)&& cont==2){
            bandera1++;
            cont++;
          }else if(pContrasenia.equals(desencriptado)&& cont==5){
             bandera1++;
             break;          
          }else{
            cont++;
          }
        }if (bandera1==2){
          return true;
        }    
      }  
    } catch (Exception e){} 
      return false;
  }
  /**
   * Metodo que se encarga de recorrer un xml
   * @param pCorreo es de tipo String  y es el correo del usuario al que se va a buscar
   * @return retorna un valor booleano segun el resultado
   */
  public boolean recorrer(String pCorreo){
    try{
      EncriptarDesencriptar desencripto=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  childeren.item(0).getChildNodes().getLength(); i++){
        for (int j = 0; j < childeren.item(0).getChildNodes().item(i).getChildNodes().getLength(); j++){
          String desencrip=desencripto.desencriptar(childeren.item(0).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
          if(pCorreo.equals(desencrip)){
            return true; 
          }
        }
      }      
    } catch (Exception e){} 
      return false;
  }
  /**
   * Metodo que se encarga de recorrer un xml
   * @param pNombre es de tipo String y es el nombre de la base de datos que se va a buscar
   * @return retorna un valor booleano dependiendo del resultado
   */
  public boolean recorrerNombreBaseDatos(String pNombre){
    try{
      File archivo = new File("nombresbasesdedatos.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  childeren.item(0).getChildNodes().getLength(); i++){
        for (int j = 0; j < childeren.item(0).getChildNodes().item(i).getChildNodes().getLength(); j++){
          if(pNombre.equals(childeren.item(0).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
            return true; 
          }
        }  
      }  
    } catch (Exception e){} 
      return false;
  }
  /**
   * Metodo que se encarga de recorrer un xml
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @return retorna un valor booleano dependiendo del resultado
   */
  public boolean recorrerCambiarNombre(String pNombreBaseDatos,String pNombreTabla){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return true;
        }
      }return false;   
    } catch (Exception e){} 
      return false;
  }
  /**
   * Metodo que se encarga de mandar correos
   * @param pDestinatario es de tipo String y es el correo del destinario
   * @param pContrasenia Es de tipo String y es la contrasenia del usuario
   */
  public void mandarMail(String pDestinatario, String pContrasenia){
    Properties propiedad = new Properties();
    propiedad.setProperty("mail.smtp.host", "smtp.gmail.com");
    propiedad.setProperty("mail.smtp.starttls.enable", "true");
    propiedad.setProperty("mail.smtp.port", "587");
    propiedad.setProperty("mail.smtp.auth", "true");
    Session sesion = Session.getDefaultInstance(propiedad);    
    String correoEnvia = "adpyipoogestorbasedatos@gmail.com";
    String contrasena = "1234Adm$";
    String destinatario = pDestinatario;
    String asunto = "Nombre de Usuario y Contraseña";
    String mensaje = "Su nombre de usuario es:" +  pDestinatario  +  "y su contraseña es:"  +  pContrasenia; 
    MimeMessage mail = new MimeMessage(sesion); 
    try {
      mail.setFrom(new InternetAddress (correoEnvia));
      mail.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
      mail.setSubject(asunto);
      mail.setText(mensaje);  
      Transport transporte = sesion.getTransport("smtp");
      transporte.connect(correoEnvia,contrasena);
      transporte.sendMessage(mail, mail.getRecipients(Message.RecipientType.TO));
      transporte.close();     
      JOptionPane.showMessageDialog(null, "Se ha enviado un correo electronico con su nombre de usuario y su contraseña");
    } catch (AddressException ex) {
        Logger.getLogger(BaseDatosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
    } catch (MessagingException ex) {
        Logger.getLogger(BaseDatosUsuarios.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
  /**
   * Metodo que se encarga de cambiar el nombre a una tabla
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla actualmente
   * @param pNombreTablaNuevo es de tipo String y es el nombre de la tabla nueva
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws TransformerException 
   */
  public void changeTagName(String pNombreBaseDatos, String pNombreTabla, String pNombreTablaNuevo) throws ParserConfigurationException, SAXException, IOException, TransformerException {
    File archivo = new File(pNombreBaseDatos + ".xml");
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    Document document = documentBuilder.parse(archivo);
    NodeList nodes = document.getElementsByTagName(pNombreTabla);
    for (int i = 0; i < nodes.getLength(); i++) {
      if(nodes.item(i) instanceof Element) {
        Element elem = (Element)nodes.item(i);
        document.renameNode(elem, elem.getNamespaceURI(), pNombreTablaNuevo);
        File archivoNuevo = new File(pNombreBaseDatos + ".xml");  
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        Result output = new StreamResult(archivoNuevo);
        Source input = new DOMSource(document);
        transformer.transform(input, output);
      }
    }
  }

  /**
   * Metodo que se encarga de agrregar bases de datos a los usuarios
   * @param pUsuario es de tipo String y es el usuario al que se le va a agregar la abse de datos
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   */
  public void AgregarBaseDatosAUsuarios(String pUsuario,String pNombreBaseDatos){
    try{
      EncriptarDesencriptar dencriptadoor=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());  
        if(desen.equals(pUsuario)){
          elem.getChildNodes().item(i).appendChild(crearElementoBaseDatosAUsuario("BaseDatos",pNombreBaseDatos,document ));
          break;
        }
      }Transformer transformer = TransformerFactory.newInstance().newTransformer();
       Result output = new StreamResult(archivo);
       Source input = new DOMSource(document);
       transformer.transform(input, output);     
    } catch (Exception e){}     
  }
  /**
   * Metodo que se encarga de devolver el nodo Base de datos del usuario que se ingresara a la base de datos
   * @param pNombreEtiqueta  Es de tipo String y es el nombre de la etiqueta que tendra el xml
   * @param valor es de tipo String y es lo que va dentro de la etiqueta lo que digita el usuario
   * @param pDocumento Es de tipo Document y es el documento donde se va a guardar los elementos 
   * @return retorna el nodo que se va a ingresar
   */
  public static Node crearElementoBaseDatosAUsuario(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
  /**
   * Metodo que se encarga de validar que la base de datos se encuentra en el usuario
   * @param pUsuario es de tipo String y es el usuario
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @return retorna un valor booleano dependiendo del resultado
   */
  public boolean ValidarBasesDatosUsuario(String pUsuario,String pNombreBaseDatos){
    try{
      EncriptarDesencriptar dencriptadoor=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=6; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            if(elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent().equals(pNombreBaseDatos)){
              return true;
            }
          }  
        }
      }return false;   
    }catch (Exception e){} 
     return false;
      
  }
  /**
   * Metodo que se encarga de printear las bases de datos de los usuarios
   * @param pUsuario es de tipo String y es el usuario
   * @param cont es de tipo int y es el contador para recorrer el xml
   * @return 
   */
  public String PrintearBasesDatos(String pUsuario,int cont){
    try{
      EncriptarDesencriptar dencriptadoor=new EncriptarDesencriptar();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=cont; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            return elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent();  
          }  
        }
      }   
    }catch (Exception e){} 
     return null;    
  }
  /**
   * Metodo que se encarga de obtener el largo del xml donde se encuentran los usuarios
   * @param pUsuario es de tipo String y es el usuario
   * @return retorna el largo de un xml
   */
  public int largoDocumento(String pUsuario){
    try{
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      int posicion=posicionTabla(pUsuario,elem);
      return elem.getChildNodes().item(posicion).getChildNodes().getLength();
    } catch (Exception e){} 
      return 0; 
  }
  /**
   *Metodo que se encarga de obtener la posicion en la que se encuentra una tabla
   * @param nombre es de tipo String y es el nombre de la tabla
   * @param rootElement es de tipo Element y son los elementos del xml
   * @return retorna la posicion de la tabla
   */
  public int posicionTabla(String nombre,Element rootElement){
    EncriptarDesencriptar des=new EncriptarDesencriptar();
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      String desencripto=des.desencriptar(rootElement.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
      if(desencripto.equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }
  /**
   * Metodo que se encarga de printear las tablas de los usuarios
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de  datos
   * @param cont es de tipo int y es el contador para buscar la base de datos
   * @return 
   */
  public String PrintearTablas(String pNombreBaseDatos,int cont){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      return elem.getChildNodes().item(cont).getNodeName();        
    } catch (Exception e){} 
      return null;
  }
  /**
   * Metodo que se encarga de sacar el largo al xml de las tablas
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @return 
   */
  public int largoDocTablas(String pNombreBaseDatos){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      return elem.getChildNodes().getLength();
    } catch (Exception e){} 
      return 0; 
  }
  /**
   * Metodo que se encarga de printear la estructura de la tabla a los usuarios
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es  de tipo String y es el nombre de la tabla
   * @param cont es de tipo int y es el contador
   * @return 
   */
  public String printearEstructuraTabla(String pNombreBaseDatos,String pNombreTabla, int cont){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().item(cont).getTextContent();
        }
      }   
    } catch (Exception e){} 
      return null;
  }
  /**
   * Metodo que se encarga de obtener el largo de un xml
   * @param pNombreBaseDatos es de tipo String y es el nombre de la base de datos
   * @param pNombreTabla es de tipo String y es el nombre de la tabla
   * @return retorna el largo del xml
   */
  public int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      for(int i = 0; i<elem.getChildNodes().getLength();i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().getLength();
        }
      }  
    }catch (Exception e){} 
     return 0;
  }
  /**
   * Metodo que se encarga de obtener la posicion de la estructura de la tabla
   * @param pNombreTabla  es de tipo String y es el nombre de la tabla
   * @param rootElement es de tipo Element y son los elementos del xml
   * @return retorna la posicion de la estructura de lla tabla
   */
  public int posicionEstructura(String pNombreTabla,Element rootElement){
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(0).equals(pNombreTabla)){
        return rootElement.getChildNodes().item(0).getFirstChild().getChildNodes().getLength();
      }
    }return cont;   
  }
  /**
   * Metodo que se encarga de transformar en una lista los datos que ingresa un usuario
   * @param pDatos es de tipo String y son los datos que se van a convertir en una lista
   * @return retorna una lista con los datos que ingreso el usuario
   */ 
  public List ConstruirStringIngresar(String pDatos){
    List lista= new List();
    String prueba="";
    int contComa= ContadorComas(pDatos);
    int cont=0;
    boolean bandera=false;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        lista.add(prueba);
        prueba="";
        cont++;     
      }else if(cont==contComa){
        for(int j=i; j< pDatos.length();j++){
          if(pDatos.charAt(j)!='"'){
            prueba=prueba+pDatos.charAt(j); 
          }  
        }bandera=true;
         break;
      } else if(pDatos.charAt(i)=='"'){
          
      } else if (pDatos.charAt(i) != '"'){
        prueba=prueba+pDatos.charAt(i);
      }
    }lista.add(prueba);
    for(int i=0; i< lista.getItemCount();i++){
    }return lista;
  }  
    
  /**
   * Metodo que se encarga de contar las comas donde el usuario ingreso datos
   * @param pDatos es de tipo String y son los atso que digito el usuario
   * @return retorna la cantidad de comas
   */ 
  public int ContadorComas(String pDatos){
    int cont=0;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        cont++;
      }  
    }return cont;
  }
  /**
   * Metodo que se encarga de validar el tipo del dato que ingreso el usuario
   * @param cadena es de tipo String y es una cadeda de caracterers para ser validada
   * @return retorna el tipo del dato
   */
  public String validarTipo(String cadena){
    boolean f=true;
    if (f==true){
      try {
        Integer.parseInt(cadena);
        return "Int";
      } catch (NumberFormatException nfe){
        f=false;
      }
    }if(f==false){
      for(int i =0; i<cadena.length(); i++){
        if(cadena.charAt(i) == '.'){
          return "Float";
        }
      }f=true;
    }if(f==true){
      String cadena2 = cadena.toLowerCase();
      if("false".equals(cadena2) || "true".equals(cadena2)){
        return "Logico";
      }
    }return "String";
  }
  /**
   * Metodo que se encarga de de validar si el requerimiento es SI o NO
   * @param pLista es de tipo List y es la lista que ingreso el usuario
   * @param pLista2 es de tipo List y es la lista de la estructura
   * @return retorna valor booleano dependiendo del resultado
   */ 
  public boolean ValidarSupport(List pLista, List pLista2){
    int cont=1;
    for(int i=0; i< pLista.getItemCount();i++){
      String vari=validarTipo((pLista.getItem(i)));
      if(!"".equals(pLista.getItem(i))){  
        if(vari.equals(pLista2.getItem(cont))){
          cont++;
          if("SI".equals(pLista2.getItem(cont))){
            if(pLista.getItem(i).length()>0){
              cont+=2;
            }else{
              return false;
            }
          }else{
            cont+=2;
          }
        }else{ 
          return false;
        }
      }else{
        cont++;
        if("SI".equals(pLista2.getItem(cont))){
          if(pLista.getItem(i).length()>0){
            cont+=2;
          }else{
            return false;
          }
        }else{
          cont+=2;
        }    
      }
    }return true; 
  }
  /**
   * Metodo que se encarga de dar acceso a los diferentes tipos de datos dependiendo del comparador que escoja
   * @param pCondicion es de tipo String y es el signo que el usuario escogio
   * @param pTexto es de tipo String y es la etiqueta que el usuario escogio
   * @param pTexto2 es de tipo String y es lo que el usuario digito
   * @return retorna un valor booleano dependiendo del resultado
   */ 
  public boolean ValidarCondicion(String pCondicion,String pTexto, String pTexto2){
    String validado=validarTipo(pTexto);
    String validado2=validarTipo(pTexto2);
    if("String".equals(validado2)){
      if("==".equals(pCondicion) || "!=".equals(pCondicion)){
        return true;
      }else{
        return false;   
      } 
    }else if("Int".equals(validado2)){
      return true;    
    }else if("Logico".equals(validado2)){
      if("==".equals(pCondicion) || "!=".equals(pCondicion)){ 
        return true;
      }else{
        return false;    
      }      
    }else if("Float".equals(validado2)){
      return true;    
    }return false;
  }
}
