
package gui;
import java.awt.Font;
import gestorbasedatos.BaseDatos;
import gestorbasedatos.BaseDatosUsuarios;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

/**
 * Clase que se encarga de crear la intergaz grafica de CrearBasesDatos
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class CrearBaseDatosUsuarioFinal extends javax.swing.JFrame {

  /**
   * Metodo constructor de la interfaz grafica CrearBaseDatosUsuarioFinal
   */  
  public CrearBaseDatosUsuarioFinal() {
    setSize(500,300);
    setTitle("Eleccion de Usuario");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz CrearBaseDatosUsuarioFinal
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tituloBaseDatosUF = new javax.swing.JLabel();
        textoDigiteUF = new javax.swing.JLabel();
        cajaTextoNombreDatos = new javax.swing.JTextField();
        botonCrearBase = new javax.swing.JButton();
        botonVolverCBD = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tituloBaseDatosUF.setText("Crear Base de Datos");
        tituloBaseDatosUF.setBounds(40,10,500,30);
        tituloBaseDatosUF.setFont(new Font("arial",Font.BOLD,20));

        textoDigiteUF.setText("Digite el nombre de la base de datos:");

        botonCrearBase.setText("Crear");
        botonCrearBase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCrearBaseActionPerformed(evt);
            }
        });

        botonVolverCBD.setText("Atras");
        botonVolverCBD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCBDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addComponent(tituloBaseDatosUF))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(botonCrearBase)
                            .addComponent(textoDigiteUF))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cajaTextoNombreDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(botonVolverCBD)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloBaseDatosUF)
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoDigiteUF)
                    .addComponent(cajaTextoNombreDatos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCrearBase)
                    .addComponent(botonVolverCBD))
                .addContainerGap(153, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 409, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonCrearBaseaDatos de la interfaz CrearBaseDatosUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonCrearBaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCrearBaseActionPerformed
      BaseDatos crear=new BaseDatos();
      BaseDatosUsuarios meterXmlS=new BaseDatosUsuarios();
      boolean acNombreS=meterXmlS.recorrerNombreBaseDatos(cajaTextoNombreDatos.getText());
      boolean validar=crear.validarNombre(cajaTextoNombreDatos.getText());
      if(validar==true){
        if(acNombreS==true){
          JOptionPane.showMessageDialog(null,"El nombre de la base de datos ya existe");
        }else if(cajaTextoNombreDatos.getText().length()<= 12){
          try {
            crear.crearBaseDatos(cajaTextoNombreDatos.getText());
            meterXmlS.AgregarBaseDatosAUsuarios(VentanaInicial.usuario, cajaTextoNombreDatos.getText());
            meterXmlS.agregarBaseDatos(cajaTextoNombreDatos.getText());
            JOptionPane.showMessageDialog(null,"Base de datos creada con exito");
          }catch (ParserConfigurationException | TransformerException ex) {
            Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(Level.SEVERE, null, ex);
          }catch (Exception ex) {
            Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(Level.SEVERE, null, ex);
          }
        }else{
          JOptionPane.showMessageDialog(null,"Base de datos es mayor que 12 caracteres");
        }
      }else{
        JOptionPane.showMessageDialog(null,"El nombre de la base de datos posee numeros o caracteres especiales"); 
      }
    }//GEN-LAST:event_botonCrearBaseActionPerformed
    /**
     * Metodo que se encarga de configurar el botonVolverCBD de la interfaz CrearBaseDatosUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCBDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCBDActionPerformed
      VentanaUsuarioFinal volverFinalS=new VentanaUsuarioFinal();
      volverFinalS.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverCBDActionPerformed

    /**
     * Metodo main de la interfaz CrearBaseDatosUsuarioFinal
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearBaseDatosUsuarioFinal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCrearBase;
    private javax.swing.JButton botonVolverCBD;
    private javax.swing.JTextField cajaTextoNombreDatos;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel textoDigiteUF;
    private javax.swing.JLabel tituloBaseDatosUF;
    // End of variables declaration//GEN-END:variables
}
