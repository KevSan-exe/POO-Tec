package gui;
import gestorbasedatos.BaseDatosUsuarios;
import static gui.VentanaBaseDatosParaIngresar.datos;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JOptionPane;
/**
 * Clase que se encarga de crear la iinterfaz grafica VentanaBaseDatosSeleccionarDatos 
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class VentanaBaseDatosSeleccionarDatos extends javax.swing.JFrame {
  public static String baseDatos;
  
  /**
   * Metodo constructor de la interfaz grafica VentanaBaseDatosSeleccionarDatos
   */
  public VentanaBaseDatosSeleccionarDatos() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfza grafica VentanaBaseDatosSeleccionarDatos
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textoBaseDatosSeleccionar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textoMostrarBasesDatos = new javax.swing.JTextArea();
        botonAceptarSeleccionar = new javax.swing.JButton();
        botonVolverSeleccionar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);
        jPanel1.setBackground(Color.white);

        jLabel1.setText("Ingrese el nombre de la base de datos donde se encuentra la tabla");

        jLabel2.setText("Base de datos:");

        textoMostrarBasesDatos.setEditable(false);
        textoMostrarBasesDatos.setColumns(20);
        textoMostrarBasesDatos.setRows(5);
        textoMostrarBasesDatos.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                textoMostrarBasesDatosAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(textoMostrarBasesDatos);

        botonAceptarSeleccionar.setText("Aceptar");
        botonAceptarSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarSeleccionarActionPerformed(evt);
            }
        });

        botonVolverSeleccionar.setText("Volver");
        botonVolverSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverSeleccionarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoBaseDatosSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(botonAceptarSeleccionar)
                        .addGap(41, 41, 41)
                        .addComponent(botonVolverSeleccionar)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoBaseDatosSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarSeleccionar)
                    .addComponent(botonVolverSeleccionar))
                .addContainerGap(64, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 387, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonVolverSeleccionar de la interfaz grafica VentanaBaseDatosSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverSeleccionarActionPerformed
      VentanaUsuarioFinal ventanaUF2= new VentanaUsuarioFinal();
      ventanaUF2.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverSeleccionarActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAceptarSeleccionar de la interfaz grafica VentanaBaseDatosSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarSeleccionarActionPerformed
      BaseDatosUsuarios verifica=new BaseDatosUsuarios();
      boolean verificaUsuario=verifica.ValidarBasesDatosUsuario(VentanaInicial.usuario,textoBaseDatosSeleccionar.getText());
      if (verificaUsuario==true){
        baseDatos=textoBaseDatosSeleccionar.getText();
        VentanaSeleccionarDatos ventanaSeleccionar=new VentanaSeleccionarDatos();
        ventanaSeleccionar.setVisible(true);
        this.setVisible(false);
      }else{
         JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
      }
    }//GEN-LAST:event_botonAceptarSeleccionarActionPerformed
    /**
     * Metodo que se encarga de configurar el textoMostarBasesDatos de la interfaz grafica VentanaBaseDatosSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void textoMostrarBasesDatosAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_textoMostrarBasesDatosAncestorAdded
      BaseDatosUsuarios printeo=new BaseDatosUsuarios();
      int cont=6;
      int cont2= printeo.largoDocumento(VentanaInicial.usuario);
      for(int i=cont; i< cont2;i++){
        textoMostrarBasesDatos.append(printeo.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_textoMostrarBasesDatosAncestorAdded

    /**
     * Metodo main de la interfaz grafica VentanaBaseDatosSeleccionarDatos
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBaseDatosSeleccionarDatos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAceptarSeleccionar;
    private javax.swing.JButton botonVolverSeleccionar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField textoBaseDatosSeleccionar;
    private javax.swing.JTextArea textoMostrarBasesDatos;
    // End of variables declaration//GEN-END:variables
}
