
package gui;
import gestorbasedatos.BaseDatos;
import java.awt.Color;
import java.awt.Font;
import gestorbasedatos.BaseDatosUsuarios;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;

  /**
   * Clase que se encarga de crear una Interfaz grafica para cambiarle el nombre a la tabla
   * @author Kevin Lanzas,Daniel Barrantes, Kevin Sanchez
   */
public class CambiarNombreTabla extends javax.swing.JFrame {
    
  /**
   * Metodo constructor de la interfaz grafica CambiarNombreTabla
   */
  public CambiarNombreTabla() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     *Metodo que se encarga de inicializar los componentes de la interfaz CambiarNombreTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        textoNombreTablaAntiguo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textoNombreTablaNuevo = new javax.swing.JTextField();
        botonAceptarCambiarNombreTabla = new javax.swing.JButton();
        botonVolverCambiarNombreTabla = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaTextoMostrarTablas = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("Nombre de la tabla");

        jLabel3.setText("Nombre nuevo de la tabla");

        botonAceptarCambiarNombreTabla.setText("Aceptar");
        botonAceptarCambiarNombreTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarCambiarNombreTablaActionPerformed(evt);
            }
        });

        botonVolverCambiarNombreTabla.setText("Volver");
        botonVolverCambiarNombreTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCambiarNombreTablaActionPerformed(evt);
            }
        });

        jPanel1.setLayout(null);
        jPanel1.setBackground(Color.white);

        areaTextoMostrarTablas.setEditable(false);
        areaTextoMostrarTablas.setColumns(20);
        areaTextoMostrarTablas.setRows(5);
        areaTextoMostrarTablas.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaTextoMostrarTablasAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaTextoMostrarTablas);

        jLabel1.setText("Tablas:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(86, 86, 86))
        );

        jLabel4.setText("Cambiar nombre de la tabla");
        jLabel4.setBounds(40,10,500,30);
        jLabel4.setFont(new Font("arial",Font.BOLD,20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(botonAceptarCambiarNombreTabla)
                .addGap(81, 81, 81)
                .addComponent(botonVolverCambiarNombreTabla)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textoNombreTablaAntiguo, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textoNombreTablaNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
            .addGroup(layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoNombreTablaAntiguo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(textoNombreTablaNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarCambiarNombreTabla)
                    .addComponent(botonVolverCambiarNombreTabla))
                .addGap(25, 25, 25))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addGap(0, 94, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    /**
     * Metodo que se encarga de configurar el boton aceptar de la interfaz CambiarNombreTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarCambiarNombreTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarCambiarNombreTablaActionPerformed
      BaseDatosUsuarios cambiarNombre=new BaseDatosUsuarios();
      BaseDatos validarNombre= new BaseDatos();
      boolean recorredor=cambiarNombre.recorrerCambiarNombre(VentanaBaseDatosCambiarTabla.baseDatosCT,textoNombreTablaNuevo.getText());
      boolean verificoNombre=cambiarNombre.ValidarBasesDatosUsuario(VentanaInicial.usuario,VentanaBaseDatosCambiarTabla.baseDatosCT);
      if (validarNombre.validarNombre(textoNombreTablaNuevo.getText())==true){
        if(verificoNombre==true){
          if(recorredor==true){
            JOptionPane.showMessageDialog(null,"El nombre de la tabla de datos ya existe");
          }else if(textoNombreTablaNuevo.getText().length()<= 12){
            try {
              if(validarNombre.validarCambiarNombreTabla(textoNombreTablaAntiguo.getText(), VentanaBaseDatosCambiarTabla.baseDatosCT)){
                cambiarNombre.changeTagName(VentanaBaseDatosCambiarTabla.baseDatosCT, textoNombreTablaAntiguo.getText(), textoNombreTablaNuevo.getText());
                JOptionPane.showMessageDialog(null,"Se cambio el nombre de la tabla con exito"); 
              }else{
                JOptionPane.showMessageDialog(null,"El nombre de la tabla esta incorrecto");     
              }
            }catch (ParserConfigurationException | SAXException | IOException | TransformerException ex) {
              Logger.getLogger(CambiarNombreTabla.class.getName()).log(Level.SEVERE, null, ex);
            }
          }else{
            JOptionPane.showMessageDialog(null,"El nombre de la tabla es mayor que 12 caracteres");
          }
        }else{
           JOptionPane.showMessageDialog(null,"Tabla no pertenece a este usuario"); 
        }
      }else{
          JOptionPane.showMessageDialog(null,"El nuevo nombre de la tabla posee numeros o caracteres especiales");  
      }   
    }//GEN-LAST:event_botonAceptarCambiarNombreTablaActionPerformed
    /**
     * Metodo que se encarga de configurarnel boton volver de la interfaz CambiarNombreTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCambiarNombreTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCambiarNombreTablaActionPerformed
      VentanaBaseDatosCambiarTabla ventanaVolverUF=new VentanaBaseDatosCambiarTabla();
      ventanaVolverUF.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverCambiarNombreTablaActionPerformed
    /**
     * Metodo que se encarga de la configuracion del JTextArea de la interfaz CambiarNombreTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaTextoMostrarTablasAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaTextoMostrarTablasAncestorAdded
      BaseDatosUsuarios printearCambiarTabla=new BaseDatosUsuarios();
      int cont=0;
      int cont2= printearCambiarTabla.largoDocTablas(VentanaBaseDatosCambiarTabla.baseDatosCT);
      for(int i=0; i< cont2;i++){
        areaTextoMostrarTablas.append(printearCambiarTabla.PrintearTablas(VentanaBaseDatosCambiarTabla.baseDatosCT,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaTextoMostrarTablasAncestorAdded

    /**
     * Metodo main de la interfaz CambiarNombreTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarNombreTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaTextoMostrarTablas;
    private javax.swing.JButton botonAceptarCambiarNombreTabla;
    private javax.swing.JButton botonVolverCambiarNombreTabla;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField textoNombreTablaAntiguo;
    private javax.swing.JTextField textoNombreTablaNuevo;
    // End of variables declaration//GEN-END:variables
}
