package gui;

import gestorbasedatos.BaseDatosUsuarios;
import static gui.VentanaBaseDatosEliminarTabla.baseDatosET;
import javax.swing.JOptionPane;

/**
 * Calse que se encarga de crear la interfaz grafica VentanaBaseDatosCrearTabla
 * @author Dell_e5440
 */
public class VentanaBaseDatosCrearTabla extends javax.swing.JFrame {
  public static String baseDatosCT;
    
  /**
   * Metodo constructor de la interfaz grafica VentanaBaseDatosCrearTabla
   */
  public VentanaBaseDatosCrearTabla() {
    setSize(500,300);
    setTitle("Eleccion de Usuario");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /** 
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaBaseDatosCrearTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textoBaseDatosCrearTabla = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaTextoMostrarBaseCT = new javax.swing.JTextArea();
        botonAceptarCT = new javax.swing.JButton();
        botonVolverCT = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingrese el nombre de la base de datos donde se creara la tabla");

        jLabel2.setText("Nombre Base Datos:");

        areaTextoMostrarBaseCT.setColumns(20);
        areaTextoMostrarBaseCT.setRows(5);
        areaTextoMostrarBaseCT.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaTextoMostrarBaseCTAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaTextoMostrarBaseCT);

        botonAceptarCT.setText("Aceptar");
        botonAceptarCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarCTActionPerformed(evt);
            }
        });

        botonVolverCT.setText("Volver");
        botonVolverCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel1)
                        .addGap(0, 46, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(botonAceptarCT)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(botonVolverCT)
                                .addGap(58, 58, 58))
                            .addComponent(jScrollPane1)
                            .addComponent(textoBaseDatosCrearTabla))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoBaseDatosCrearTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarCT)
                    .addComponent(botonVolverCT))
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 392, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonAceptarCT de la interfaz grafica VentanaBaseDatosCrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarCTActionPerformed
      BaseDatosUsuarios verificadorCT=new BaseDatosUsuarios();
      boolean verificaUsuario=verificadorCT.ValidarBasesDatosUsuario(VentanaInicial.usuario,textoBaseDatosCrearTabla.getText());
      if (verificaUsuario==true){
        baseDatosCT=textoBaseDatosCrearTabla.getText();
        CrearTabla ventanaCT=new CrearTabla();
        ventanaCT.setVisible(true);
        this.setVisible(false);
      }else{
         JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
      } 
    }//GEN-LAST:event_botonAceptarCTActionPerformed
    /**
     * Metodo que se encarga de configurar el botonVolverCT de la interfaz grafica VentanaBaseDatosCrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCTActionPerformed
      VentanaUsuarioFinal volverCT= new VentanaUsuarioFinal();
      volverCT.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverCTActionPerformed
    /**
     * Metodo que se encarga de configurar el areaTextoMostrarBaseCT de la interfaz grafica VentanaBaseDatosCrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaTextoMostrarBaseCTAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaTextoMostrarBaseCTAncestorAdded
      BaseDatosUsuarios printearBasesCT=new BaseDatosUsuarios();
      int cont=6;
      int cont2= printearBasesCT.largoDocumento(VentanaInicial.usuario);
      for(int i=cont; i< cont2;i++){
        areaTextoMostrarBaseCT.append(printearBasesCT.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaTextoMostrarBaseCTAncestorAdded

    /**
     * Metodo main de la interfaz grafica VentanaBaseDatosCrearTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBaseDatosCrearTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaTextoMostrarBaseCT;
    private javax.swing.JButton botonAceptarCT;
    private javax.swing.JButton botonVolverCT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField textoBaseDatosCrearTabla;
    // End of variables declaration//GEN-END:variables

}
