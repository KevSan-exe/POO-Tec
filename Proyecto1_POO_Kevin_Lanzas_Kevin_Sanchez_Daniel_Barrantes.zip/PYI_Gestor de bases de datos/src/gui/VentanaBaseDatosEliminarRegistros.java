package gui;

import gestorbasedatos.BaseDatosUsuarios;
import static gui.VentanaBaseDatosSeleccionarDatos.baseDatos;
import javax.swing.JOptionPane;

/**
 * Clase que se encarga de crear la interfaz VentanaBaseDatosEliminarRegistros
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class VentanaBaseDatosEliminarRegistros extends javax.swing.JFrame {
  public static String baseDatos;
    /**
     * Metodo constructor de la interfaz grafica VentanaBaseDatosEliminarRegistros
     */
  public VentanaBaseDatosEliminarRegistros() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaBaseDatosEliminarRegistros
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        textoBaseDatosEliminar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaBaseDatosEliminar = new javax.swing.JTextArea();
        botonAceptarEliminar = new javax.swing.JButton();
        botonVolverEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingrese la base de datos en la que desea eliminar un registro");

        jLabel2.setText("Base de datos:");

        areaBaseDatosEliminar.setEditable(false);
        areaBaseDatosEliminar.setColumns(20);
        areaBaseDatosEliminar.setRows(5);
        areaBaseDatosEliminar.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaBaseDatosEliminarAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaBaseDatosEliminar);

        botonAceptarEliminar.setText("Aceptar");
        botonAceptarEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarEliminarActionPerformed(evt);
            }
        });

        botonVolverEliminar.setText("Volver");
        botonVolverEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(botonAceptarEliminar)
                .addGap(59, 59, 59)
                .addComponent(botonVolverEliminar)
                .addContainerGap(93, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(textoBaseDatosEliminar))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoBaseDatosEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarEliminar)
                    .addComponent(botonVolverEliminar))
                .addContainerGap(123, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(51, 51, 51))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(298, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonVolverEliminar de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverEliminarActionPerformed
      VentanaUsuarioFinal eliminarR=new VentanaUsuarioFinal();
      eliminarR.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverEliminarActionPerformed
    /**
     * Metodo que se encarga de configurar el areaBaseDatosEliminar de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaBaseDatosEliminarAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaBaseDatosEliminarAncestorAdded
      BaseDatosUsuarios printeo=new BaseDatosUsuarios();
      int cont=6;
      int cont2= printeo.largoDocumento(VentanaInicial.usuario);
      for(int i=cont; i< cont2;i++){
        areaBaseDatosEliminar.append(printeo.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaBaseDatosEliminarAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonAceptarEliminar de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarEliminarActionPerformed
      BaseDatosUsuarios verifica=new BaseDatosUsuarios();
      boolean verificaUsuario=verifica.ValidarBasesDatosUsuario(VentanaInicial.usuario,textoBaseDatosEliminar.getText());
      if (verificaUsuario==true){
        baseDatos=textoBaseDatosEliminar.getText();
        EliminarRegistros ventanaEliminarRegistros=new EliminarRegistros();
        ventanaEliminarRegistros.setVisible(true);
        this.setVisible(false);
      }else{
         JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
      }
    }//GEN-LAST:event_botonAceptarEliminarActionPerformed

    /**
     * Metodo main de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBaseDatosEliminarRegistros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaBaseDatosEliminar;
    private javax.swing.JButton botonAceptarEliminar;
    private javax.swing.JButton botonVolverEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField textoBaseDatosEliminar;
    // End of variables declaration//GEN-END:variables
}
