package gui;
import java.awt.Color;
import java.awt.Font;
import gestorbasedatos.BaseDatosUsuarios;
import javax.swing.JOptionPane;


/**
 * Clase que se encarga de crear la interfaz grafica VentanaInicial
 * @author Kevin Lanzas Quen
 */
public class VentanaInicial extends javax.swing.JFrame {
  public static String usuario; 
  /**
   * Metodo constructor de la interfaz grafica VentanaInicial
   */  
  public VentanaInicial() {
    setSize(500,300);
    setTitle("Eleccion de Usuario");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaInicial
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelVentanaInicial = new javax.swing.JPanel();
        tituloVentanaInicial = new javax.swing.JLabel();
        botonAceptar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        textoUsuario = new javax.swing.JTextField();
        textoNombreUsuario = new javax.swing.JLabel();
        textoContrasenaVentanaInicial = new javax.swing.JLabel();
        textoContrasena = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelVentanaInicial.setLayout(null);
        panelVentanaInicial.setBackground(Color.white);

        tituloVentanaInicial.setText("Validacion de Credenciales");
        tituloVentanaInicial.setBounds(40,10,500,30);
        tituloVentanaInicial.setFont(new Font("arial",Font.BOLD,20));

        botonAceptar.setText("Aceptar");
        botonAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarActionPerformed(evt);
            }
        });

        botonCancelar.setText("Cancelar");
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });

        textoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoUsuarioActionPerformed(evt);
            }
        });

        textoNombreUsuario.setText("Nombre de Usuario");

        textoContrasenaVentanaInicial.setText("Contraseña");

        javax.swing.GroupLayout panelVentanaInicialLayout = new javax.swing.GroupLayout(panelVentanaInicial);
        panelVentanaInicial.setLayout(panelVentanaInicialLayout);
        panelVentanaInicialLayout.setHorizontalGroup(
            panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelVentanaInicialLayout.createSequentialGroup()
                .addContainerGap(82, Short.MAX_VALUE)
                .addGroup(panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelVentanaInicialLayout.createSequentialGroup()
                        .addComponent(textoNombreUsuario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelVentanaInicialLayout.createSequentialGroup()
                        .addComponent(textoContrasenaVentanaInicial)
                        .addGap(3, 3, 3)))
                .addGroup(panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textoUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                    .addComponent(textoContrasena))
                .addContainerGap())
            .addGroup(panelVentanaInicialLayout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(botonAceptar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonCancelar)
                .addGap(64, 64, 64))
            .addGroup(panelVentanaInicialLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(tituloVentanaInicial)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelVentanaInicialLayout.setVerticalGroup(
            panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelVentanaInicialLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(tituloVentanaInicial)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addGroup(panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textoNombreUsuario))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoContrasenaVentanaInicial)
                    .addComponent(textoContrasena, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(panelVentanaInicialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCancelar)
                    .addComponent(botonAceptar))
                .addGap(91, 91, 91))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panelVentanaInicial, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panelVentanaInicial, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonAceptar de la interfaz grafica VentanaInicial
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarActionPerformed
      if ("admin".equals(textoUsuario.getText()) && "123Adm$".equals(textoContrasena.getText()) ){
        VentanaAdmi ventanaAdministradorS=new VentanaAdmi();
        ventanaAdministradorS.setVisible(true);
        this.setVisible(false);
      }else{
         BaseDatosUsuarios verificarUFS=new BaseDatosUsuarios();
         boolean accesoU=verificarUFS.recorrer(textoUsuario.getText(),textoContrasena.getText());
         if(accesoU==true){
           VentanaUsuarioFinal ventanaUsuarioFinal=new VentanaUsuarioFinal();
           usuario=textoUsuario.getText();
           ventanaUsuarioFinal.setVisible(true);
           this.setVisible(false);
         }else{
            JOptionPane.showMessageDialog(null,"Usuario no encontrado o los datos son incorrectos");
        }  
      }
    }//GEN-LAST:event_botonAceptarActionPerformed
    /**
     * Metodo que se encarga de configurar el botonCancelar de la interfaz grafica VentanaInicial
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
      this.setVisible(false);
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void textoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoUsuarioActionPerformed
    
    }//GEN-LAST:event_textoUsuarioActionPerformed

    /**
     * Metodo main de la interfaz grafica VentanaInicial
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaInicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAceptar;
    private javax.swing.JButton botonCancelar;
    private javax.swing.JPanel panelVentanaInicial;
    private javax.swing.JPasswordField textoContrasena;
    private javax.swing.JLabel textoContrasenaVentanaInicial;
    private javax.swing.JLabel textoNombreUsuario;
    private javax.swing.JTextField textoUsuario;
    private javax.swing.JLabel tituloVentanaInicial;
    // End of variables declaration//GEN-END:variables
}
