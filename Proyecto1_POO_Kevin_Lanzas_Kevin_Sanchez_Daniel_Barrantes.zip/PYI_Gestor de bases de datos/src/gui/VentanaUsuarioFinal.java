package gui;
import java.awt.Font;
import java.awt.Color;

/**
 * Clase que se encarga de crear la interfaz grafica VentanaUsuarioFinal
 * @author Kevin Lanzas, Daniel Barrantes, Kevin  Sanchez
 */
public class VentanaUsuarioFinal extends javax.swing.JFrame {

  /**
   * Metodo constructor de la interfaz grafica VentanaUsuarioFinal
   */
  public VentanaUsuarioFinal() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaUsuarioFinal
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelUsuarioFinal = new javax.swing.JPanel();
        tituloUF = new javax.swing.JLabel();
        botonDatosUsuarioFinal = new javax.swing.JButton();
        botonCerrarSesionFinal = new javax.swing.JButton();
        botonAccesoCrearTablas = new javax.swing.JButton();
        botonEliminarTablas = new javax.swing.JButton();
        botonCambiarNombre = new javax.swing.JButton();
        botonInsertarRegistros = new javax.swing.JButton();
        botonSeleccionarDatos = new javax.swing.JButton();
        botonEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelUsuarioFinal.setLayout(null);
        panelUsuarioFinal.setBackground(Color.white);

        tituloUF.setText("Ingrese sus datos");
        tituloUF.setBounds(60,10,500,30);
        tituloUF.setFont(new Font("arial",Font.BOLD,20));

        botonDatosUsuarioFinal.setText("Crear Base de Datos");
        botonDatosUsuarioFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonDatosUsuarioFinalActionPerformed(evt);
            }
        });

        botonCerrarSesionFinal.setText("Cerrar Sesion");
        botonCerrarSesionFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarSesionFinalActionPerformed(evt);
            }
        });

        botonAccesoCrearTablas.setText("Crear Tablas");
        botonAccesoCrearTablas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAccesoCrearTablasActionPerformed(evt);
            }
        });

        botonEliminarTablas.setText("Eliminar Tabla");
        botonEliminarTablas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarTablasActionPerformed(evt);
            }
        });

        botonCambiarNombre.setText("Cambiar nombre tabla");
        botonCambiarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCambiarNombreActionPerformed(evt);
            }
        });

        botonInsertarRegistros.setText("Insertar Registros");
        botonInsertarRegistros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonInsertarRegistrosActionPerformed(evt);
            }
        });

        botonSeleccionarDatos.setText("Seleccionar Datos");
        botonSeleccionarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSeleccionarDatosActionPerformed(evt);
            }
        });

        botonEliminar.setText("Eliminar Registros");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelUsuarioFinalLayout = new javax.swing.GroupLayout(panelUsuarioFinal);
        panelUsuarioFinal.setLayout(panelUsuarioFinalLayout);
        panelUsuarioFinalLayout.setHorizontalGroup(
            panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelUsuarioFinalLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(botonInsertarRegistros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonDatosUsuarioFinal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonEliminarTablas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(botonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(botonCambiarNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonAccesoCrearTablas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonCerrarSesionFinal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonSeleccionarDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30))
            .addGroup(panelUsuarioFinalLayout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addComponent(tituloUF)
                .addContainerGap(166, Short.MAX_VALUE))
        );
        panelUsuarioFinalLayout.setVerticalGroup(
            panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelUsuarioFinalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloUF)
                .addGap(38, 38, 38)
                .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonDatosUsuarioFinal)
                    .addComponent(botonCambiarNombre))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonEliminarTablas)
                    .addComponent(botonAccesoCrearTablas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonInsertarRegistros)
                    .addComponent(botonCerrarSesionFinal))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelUsuarioFinalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonSeleccionarDatos)
                    .addComponent(botonEliminar))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panelUsuarioFinal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 245, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(panelUsuarioFinal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonDatosUsuarioFinal de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonDatosUsuarioFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonDatosUsuarioFinalActionPerformed
      CrearBaseDatosUsuarioFinal ventana=new CrearBaseDatosUsuarioFinal();
      ventana.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonDatosUsuarioFinalActionPerformed
    /**
     * Metodo que se encarga de configurar el botonCerrarSesion de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonCerrarSesionFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarSesionFinalActionPerformed
      VentanaInicial cerrarSesionFS=new VentanaInicial();
      cerrarSesionFS.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonCerrarSesionFinalActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAccesoCrearTabla de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAccesoCrearTablasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAccesoCrearTablasActionPerformed
      VentanaBaseDatosCrearTabla ventanaDatosCT= new VentanaBaseDatosCrearTabla();
      ventanaDatosCT.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonAccesoCrearTablasActionPerformed
    /**
     * Metodo que se encarga de configurar el botonEliminarTablas de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonEliminarTablasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarTablasActionPerformed
      VentanaBaseDatosEliminarTabla ventanaEliminarTabla=new VentanaBaseDatosEliminarTabla();
      ventanaEliminarTabla.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonEliminarTablasActionPerformed
    /**
     * Metodo que se encarga de configurar el botonCambiarNombre de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonCambiarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCambiarNombreActionPerformed
      VentanaBaseDatosCambiarTabla ventanaCambiarT= new VentanaBaseDatosCambiarTabla();
      ventanaCambiarT.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonCambiarNombreActionPerformed
    /**
     * Metodo que se encarga de configurar el botonInsertarRegistros de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonInsertarRegistrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonInsertarRegistrosActionPerformed
      VentanaBaseDatosParaIngresar ventanaDatos=new VentanaBaseDatosParaIngresar();
      ventanaDatos.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonInsertarRegistrosActionPerformed
    /**
     * Metodo que se encarga de configurar el botonSeleccionarDatos de la interfaz grafica VentanaUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonSeleccionarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSeleccionarDatosActionPerformed
      VentanaBaseDatosSeleccionarDatos ventanaSeleccionarDatos= new VentanaBaseDatosSeleccionarDatos();
      ventanaSeleccionarDatos.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonSeleccionarDatosActionPerformed
    /**
     * Metodo que se encarga de configurar el botonEliminar de la interfaz grafica VentanaUsuarioFinal 
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
      VentanaBaseDatosEliminarRegistros ventanaEliminarRegistros= new VentanaBaseDatosEliminarRegistros();
      ventanaEliminarRegistros.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonEliminarActionPerformed

    /**
     * Metodo main de la interfaz grafica VentanaUsuarioFinal
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaUsuarioFinal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAccesoCrearTablas;
    private javax.swing.JButton botonCambiarNombre;
    private javax.swing.JButton botonCerrarSesionFinal;
    private javax.swing.JButton botonDatosUsuarioFinal;
    private javax.swing.JButton botonEliminar;
    private javax.swing.JButton botonEliminarTablas;
    private javax.swing.JButton botonInsertarRegistros;
    private javax.swing.JButton botonSeleccionarDatos;
    private javax.swing.JPanel panelUsuarioFinal;
    private javax.swing.JLabel tituloUF;
    // End of variables declaration//GEN-END:variables
}
