package gui;
import java.awt.Color;
import java.awt.Font;
import gestorbasedatos.BaseDatos;
import gestorbasedatos.BaseDatosUsuarios;
import java.awt.List;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 * Clase que se encarga de crear la interfaz grafica CrearTabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class CrearTabla extends javax.swing.JFrame {
  /**
   * Metodo constructor de la interfaz grafica CrearTabla
   */
  public CrearTabla() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz CrearTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        areaTextoNombre = new javax.swing.JTextField();
        indicacionNombreCampo = new javax.swing.JLabel();
        panelCrearTabla = new javax.swing.JPanel();
        comboBoxTabla = new javax.swing.JComboBox<>();
        botonAgregarTabla = new javax.swing.JButton();
        checkRequerido = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaTextoTablas = new javax.swing.JTextArea();
        botonVolverCrearTabla = new javax.swing.JButton();
        indicacionTipoDato = new javax.swing.JLabel();
        botonAgregarAUnaTabla = new javax.swing.JButton();
        botonMostrarEstructuraCrearT = new javax.swing.JButton();
        areaTextoNombreCampo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaTextoMostrarTablasCT = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        indicacionNombreCampo.setText("Nombre del campo:");

        panelCrearTabla.setLayout(null);
        panelCrearTabla.setBackground(Color.white);

        comboBoxTabla.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "String", "Int", "Logico", "Float" }));
        comboBoxTabla.setToolTipText("");
        comboBoxTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxTablaActionPerformed(evt);
            }
        });

        botonAgregarTabla.setText("Agregar");
        botonAgregarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarTablaActionPerformed(evt);
            }
        });

        checkRequerido.setText("Requerido");
        checkRequerido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkRequeridoActionPerformed(evt);
            }
        });

        areaTextoTablas.setEditable(false);
        areaTextoTablas.setColumns(20);
        areaTextoTablas.setRows(5);
        jScrollPane1.setViewportView(areaTextoTablas);

        botonVolverCrearTabla.setText("Volver");
        botonVolverCrearTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCrearTablaActionPerformed(evt);
            }
        });

        indicacionTipoDato.setText("Tipo del dato:");

        botonAgregarAUnaTabla.setText("Agregar a una tabla");
        botonAgregarAUnaTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarAUnaTablaActionPerformed(evt);
            }
        });

        botonMostrarEstructuraCrearT.setText("Mostrar Estructura de la tabla");
        botonMostrarEstructuraCrearT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarEstructuraCrearTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelCrearTablaLayout = new javax.swing.GroupLayout(panelCrearTabla);
        panelCrearTabla.setLayout(panelCrearTablaLayout);
        panelCrearTablaLayout.setHorizontalGroup(
            panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCrearTablaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(checkRequerido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelCrearTablaLayout.createSequentialGroup()
                                .addComponent(indicacionTipoDato)
                                .addGap(63, 63, 63)
                                .addComponent(comboBoxTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                        .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                                .addComponent(botonAgregarTabla)
                                .addGap(32, 32, 32))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                                .addComponent(botonAgregarAUnaTabla)
                                .addContainerGap())))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonMostrarEstructuraCrearT)
                .addGap(59, 59, 59)
                .addComponent(botonVolverCrearTabla)
                .addContainerGap())
        );
        panelCrearTablaLayout.setVerticalGroup(
            panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(indicacionTipoDato)
                    .addComponent(comboBoxTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonAgregarAUnaTabla))
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(checkRequerido))
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(botonAgregarTabla)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonVolverCrearTabla)
                    .addComponent(botonMostrarEstructuraCrearT))
                .addGap(41, 41, 41))
        );

        jLabel2.setText("Crear Tabla");
        jLabel2.setBounds(40,10,500,30);
        jLabel2.setFont(new Font("arial",Font.BOLD,20));

        jLabel1.setText("Nombre de Tabla:");

        areaTextoMostrarTablasCT.setColumns(20);
        areaTextoMostrarTablasCT.setRows(5);
        areaTextoMostrarTablasCT.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaTextoMostrarTablasCTAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(areaTextoMostrarTablasCT);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(indicacionNombreCampo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(areaTextoNombreCampo)
                .addGap(31, 31, 31))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(areaTextoNombre))
                .addContainerGap())
            .addComponent(panelCrearTabla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(areaTextoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(indicacionNombreCampo)
                    .addComponent(areaTextoNombreCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelCrearTabla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonVolverCrearTabla de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCrearTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCrearTablaActionPerformed
        VentanaBaseDatosCrearTabla VentanaVolverUsuarioFinalS=new VentanaBaseDatosCrearTabla();
        VentanaVolverUsuarioFinalS.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_botonVolverCrearTablaActionPerformed

    private void checkRequeridoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkRequeridoActionPerformed

    }//GEN-LAST:event_checkRequeridoActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAgregarTabla de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAgregarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarTablaActionPerformed
      BaseDatos agregarElementoTabla=new BaseDatos();
      BaseDatosUsuarios verificaar=new BaseDatosUsuarios();
      boolean accesoVerificar=verificaar.ValidarBasesDatosUsuario(VentanaInicial.usuario, VentanaBaseDatosCrearTabla.baseDatosCT);
      boolean verifico=agregarElementoTabla.validarNombre(areaTextoNombre.getText());
      try {
        if(areaTextoNombre.getText().length()<= 12){
          if (accesoVerificar==true){
            boolean validador=agregarElementoTabla.validarNombreTabla(areaTextoNombre.getText(),VentanaBaseDatosCrearTabla.baseDatosCT);
            if(verifico==true){
              if(validador==true){
                JOptionPane.showMessageDialog(null,"El nombre de la tabla ya existe");
              }else{
                 agregarElementoTabla.agregarTabla(VentanaBaseDatosCrearTabla.baseDatosCT, areaTextoNombre.getText(), areaTextoNombreCampo.getText(), (String) comboBoxTabla.getSelectedItem(),checkRequerido.isSelected());
                 JOptionPane.showMessageDialog(null,"La tabla se agrego a la tabla con exito");
              }
            }else{
              JOptionPane.showMessageDialog(null,"El nombre de la tabla contiene numeros o caracteres especiales");  
            }
          }else{
             JOptionPane.showMessageDialog(null,"Base de datos no pertenece al usuario"); 
          }
        }else{
           JOptionPane.showMessageDialog(null,"El nombre de la base de datos supera los 12 caracteres"); 
        }
      } catch (ParserConfigurationException | SAXException | IOException ex) {
          Logger.getLogger(CrearTabla.class.getName()).log(Level.SEVERE, null, ex);
      } catch (Exception ex) {
          Logger.getLogger(CrearTabla.class.getName()).log(Level.SEVERE, null, ex);
      } 
    }//GEN-LAST:event_botonAgregarTablaActionPerformed

    private void comboBoxTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxTablaActionPerformed

    }//GEN-LAST:event_comboBoxTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAgregarAUnaTabla de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAgregarAUnaTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarAUnaTablaActionPerformed
      BaseDatos agregarElemento=new BaseDatos();
      BaseDatosUsuarios verifico=new BaseDatosUsuarios();
      boolean accesoVerifico=verifico.ValidarBasesDatosUsuario(VentanaInicial.usuario, VentanaBaseDatosCrearTabla.baseDatosCT);
      try {
        if(accesoVerifico==true){
          boolean validador=agregarElemento.validarNombreTabla(areaTextoNombre.getText(), VentanaBaseDatosCrearTabla.baseDatosCT);
          if(validador==false){
            JOptionPane.showMessageDialog(null,"El nombre de la tabla no existe");
          }else if(agregarElemento.validarRepetidos(areaTextoNombre.getText(), VentanaBaseDatosCrearTabla.baseDatosCT, areaTextoNombreCampo.getText())==true){
            agregarElemento.agregarTabla(VentanaBaseDatosCrearTabla.baseDatosCT, areaTextoNombre.getText(), areaTextoNombreCampo.getText(), (String) comboBoxTabla.getSelectedItem(),checkRequerido.isSelected());
            JOptionPane.showMessageDialog(null,"Los elementos se agregaron a la tabla con exito");
          }else{
            JOptionPane.showMessageDialog(null,"El nombre del caampo  ya existe");     
          }
        }else{
           JOptionPane.showMessageDialog(null,"El nombre de la tabla no existe"); 
        }
      }catch (ParserConfigurationException | SAXException | IOException ex) {
         Logger.getLogger(CrearTabla.class.getName()).log(Level.SEVERE, null, ex);
      }catch (Exception ex) {
         Logger.getLogger(CrearTabla.class.getName()).log(Level.SEVERE, null, ex);
      }
    }//GEN-LAST:event_botonAgregarAUnaTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el botonMostrarEstructuraCrearT de la interfaz CrearTabla
     * @param evt 
     */
    private void botonMostrarEstructuraCrearTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMostrarEstructuraCrearTActionPerformed
      areaTextoTablas.setText(null);
      BaseDatos printear=new BaseDatos();
      List lista=new List();
      try {
        lista=printear.printearEstructuraCrear(VentanaBaseDatosCrearTabla.baseDatosCT, areaTextoNombre.getText());
        for(int i=0; i< lista.getItemCount();i++){
          areaTextoTablas.append(lista.getItem(i)+"\n");
        }
      }catch (SAXException | ParserConfigurationException | IOException ex) {
         Logger.getLogger(CrearTabla.class.getName()).log(Level.SEVERE, null, ex);
      }  
    }//GEN-LAST:event_botonMostrarEstructuraCrearTActionPerformed
    /**
     * Metodo que se encarga de configurar el areaTextoMostrarTablasCT de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaTextoMostrarTablasCTAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaTextoMostrarTablasCTAncestorAdded
      BaseDatosUsuarios printearCrearCT=new BaseDatosUsuarios();
      int cont=0;
      int cont2= printearCrearCT.largoDocTablas(VentanaBaseDatosCrearTabla.baseDatosCT);
      for(int i=0; i< cont2;i++){
        areaTextoMostrarTablasCT.append(printearCrearCT.PrintearTablas(VentanaBaseDatosCrearTabla.baseDatosCT,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaTextoMostrarTablasCTAncestorAdded

    /**
     * Metodo main de la interfaz grafica CrearTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaTextoMostrarTablasCT;
    private javax.swing.JTextField areaTextoNombre;
    private javax.swing.JTextField areaTextoNombreCampo;
    private javax.swing.JTextArea areaTextoTablas;
    private javax.swing.JButton botonAgregarAUnaTabla;
    private javax.swing.JButton botonAgregarTabla;
    private javax.swing.JButton botonMostrarEstructuraCrearT;
    private javax.swing.JButton botonVolverCrearTabla;
    private javax.swing.JCheckBox checkRequerido;
    private javax.swing.JComboBox<String> comboBoxTabla;
    private javax.swing.JLabel indicacionNombreCampo;
    private javax.swing.JLabel indicacionTipoDato;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelCrearTabla;
    // End of variables declaration//GEN-END:variables
}
