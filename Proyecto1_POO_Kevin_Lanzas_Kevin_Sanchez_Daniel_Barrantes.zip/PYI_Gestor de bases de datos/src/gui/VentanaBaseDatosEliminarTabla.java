package gui;

import gestorbasedatos.BaseDatosUsuarios;
import static gui.VentanaBaseDatosEliminarRegistros.baseDatos;
import javax.swing.JOptionPane;

/**
 * Clase que se encarga de crear la interfaz grafica VentanaBaseDatosEliminarTabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class VentanaBaseDatosEliminarTabla extends javax.swing.JFrame {
  public static String baseDatosET;
  
  /**
   * Metodo constructor de la interfaz grafica VentanaBaseDatosEliminarTabla 
   */
  public VentanaBaseDatosEliminarTabla() {
    setSize(500,300);
    setTitle("Eleccion de Usuario");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaBaseDatosEliminarTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textoBaseDatosEliminarTabla = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaBaseDatosEliminarTabla = new javax.swing.JTextArea();
        botonAceptarEliminarTabla = new javax.swing.JButton();
        botonVolverEliminarTabla = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingrese la base de datos de la cual eliminara la tabla");

        jLabel2.setText("Nombre Base Datos:");

        areaBaseDatosEliminarTabla.setEditable(false);
        areaBaseDatosEliminarTabla.setColumns(20);
        areaBaseDatosEliminarTabla.setRows(5);
        areaBaseDatosEliminarTabla.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaBaseDatosEliminarTablaAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaBaseDatosEliminarTabla);

        botonAceptarEliminarTabla.setText("Aceptar");
        botonAceptarEliminarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarEliminarTablaActionPerformed(evt);
            }
        });

        botonVolverEliminarTabla.setText("Volver");
        botonVolverEliminarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverEliminarTablaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(70, 70, 70))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(botonAceptarEliminarTabla)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                        .addComponent(botonVolverEliminarTabla)
                        .addGap(65, 65, 65))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(textoBaseDatosEliminarTabla))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoBaseDatosEliminarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarEliminarTabla)
                    .addComponent(botonVolverEliminarTabla))
                .addContainerGap(73, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonAceptarEliminarTabla de la interfaz grafica VentanaBaseDatosEliminarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarEliminarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarEliminarTablaActionPerformed
      BaseDatosUsuarios verificadorET=new BaseDatosUsuarios();
      boolean verificaUsuario=verificadorET.ValidarBasesDatosUsuario(VentanaInicial.usuario,textoBaseDatosEliminarTabla.getText());
      if (verificaUsuario==true){
        baseDatosET=textoBaseDatosEliminarTabla.getText();
        EliminarTabla ventanaEliTabla=new EliminarTabla();
        ventanaEliTabla.setVisible(true);
        this.setVisible(false);
      }else{
         JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
      } 
    }//GEN-LAST:event_botonAceptarEliminarTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el botonVolverEliminarTabla de la interfaz grafica VentanaBaseDatosEliminarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverEliminarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverEliminarTablaActionPerformed
      VentanaUsuarioFinal ventanaUsuarioFin= new VentanaUsuarioFinal();
      ventanaUsuarioFin.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverEliminarTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el areaBaseDatosEliminarTabla de la interfaz grafica VentanaBaseDatosEliminarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaBaseDatosEliminarTablaAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaBaseDatosEliminarTablaAncestorAdded
      BaseDatosUsuarios printearBases=new BaseDatosUsuarios();
      int cont=6;
      int cont2= printearBases.largoDocumento(VentanaInicial.usuario);
      for(int i=cont; i< cont2;i++){
        areaBaseDatosEliminarTabla.append(printearBases.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaBaseDatosEliminarTablaAncestorAdded

    /**
     * Metodo main de la interfaz grafica VentanaBaseDatosEliminarTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBaseDatosEliminarTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaBaseDatosEliminarTabla;
    private javax.swing.JButton botonAceptarEliminarTabla;
    private javax.swing.JButton botonVolverEliminarTabla;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField textoBaseDatosEliminarTabla;
    // End of variables declaration//GEN-END:variables
}
