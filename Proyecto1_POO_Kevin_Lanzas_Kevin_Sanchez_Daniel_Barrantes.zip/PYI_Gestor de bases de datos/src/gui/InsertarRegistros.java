package gui;
import java.awt.Color;
import java.awt.Font;
import gestorbasedatos.BaseDatosUsuarios;
import gestorbasedatos.BaseDatos;
import java.awt.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 * Clase que se encarga de crear la interfaz grafica InsertarRegistros
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class InsertarRegistros extends javax.swing.JFrame {
  /**
   * Metodo constructor de la interfaz grafica InsertarRegistros
   */  
  public InsertarRegistros() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
    }

    /**
     * Metodo que se encarga de  inicializar los componentes de la interfaz grafica InsertarRegistros
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tituloInsertarRegistros = new javax.swing.JLabel();
        indicacionTabla = new javax.swing.JLabel();
        textoTablaAModificar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaMostrarTablas = new javax.swing.JTextArea();
        botonMostrarEstructura = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        textoDatosIngresar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaMostrarEstructura = new javax.swing.JTextArea();
        botonInsertar = new javax.swing.JButton();
        botonVolverInsertar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);
        jPanel1.setBackground(Color.white);

        tituloInsertarRegistros.setText("Mantenimiento de datos");
        tituloInsertarRegistros.setBounds(1234,10,500,30);
        tituloInsertarRegistros.setFont(new Font("arial",Font.BOLD,20));

        indicacionTabla.setText("Tabla:");

        areaMostrarTablas.setEditable(false);
        areaMostrarTablas.setColumns(20);
        areaMostrarTablas.setRows(5);
        areaMostrarTablas.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaMostrarTablasAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaMostrarTablas);

        botonMostrarEstructura.setText("Mostrar estructura de la tabla");
        botonMostrarEstructura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarEstructuraActionPerformed(evt);
            }
        });

        jLabel1.setText("Datos a ingresar:");

        jLabel2.setText("Estructura de la tabla:");

        areaMostrarEstructura.setColumns(20);
        areaMostrarEstructura.setRows(5);
        jScrollPane2.setViewportView(areaMostrarEstructura);

        botonInsertar.setText("Insertar");
        botonInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonInsertarActionPerformed(evt);
            }
        });

        botonVolverInsertar.setText("Volver");
        botonVolverInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverInsertarActionPerformed(evt);
            }
        });

        jLabel3.setText("AVISO: Si el dato no es requerido por favor digite \"\"");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(138, 138, 138)
                                .addComponent(tituloInsertarRegistros))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(botonInsertar)
                                        .addGap(67, 67, 67)
                                        .addComponent(botonVolverInsertar))
                                    .addComponent(textoDatosIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 6, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(indicacionTabla)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoTablaAModificar)
                                .addGap(83, 83, 83))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(botonMostrarEstructura)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jScrollPane2))))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(33, 33, 33))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloInsertarRegistros)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoTablaAModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(indicacionTabla))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonMostrarEstructura)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textoDatosIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonInsertar)
                    .addComponent(botonVolverInsertar))
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 398, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonMostrarEstructura de la interfaz grafica InsertarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonMostrarEstructuraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMostrarEstructuraActionPerformed
      areaMostrarEstructura.setText(null);
      BaseDatosUsuarios printeo=new BaseDatosUsuarios();
      int cont=0;
      int cont2= printeo.largoDocEstructura(VentanaBaseDatosParaIngresar.datos,textoTablaAModificar.getText());
      for(int i=cont; i< cont2;i++){
        if (cont+1==cont2){
          areaMostrarEstructura.append(printeo.printearEstructuraTabla(VentanaBaseDatosParaIngresar.datos,textoTablaAModificar.getText(),cont));
          cont++;
        }else{
           areaMostrarEstructura.append(printeo.printearEstructuraTabla(VentanaBaseDatosParaIngresar.datos,textoTablaAModificar.getText(),cont)+",");
           cont++;   
        }
      }
    }//GEN-LAST:event_botonMostrarEstructuraActionPerformed
    /**
     * Metodo que se encarga de configurar el botonInsertar de la interfaz InsertarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonInsertarActionPerformed
      String nombreDeTabla=textoTablaAModificar.getText();
      String datosIngresar= textoDatosIngresar.getText();
      BaseDatosUsuarios prueba=new BaseDatosUsuarios();
      List lista= new List();
      lista=prueba.ConstruirStringIngresar(datosIngresar);
      List lista2=new List();
      lista2=prueba.ConstruirStringIngresar(areaMostrarEstructura.getText());
      BaseDatos inserto=new BaseDatos();
      if(prueba.ValidarSupport(lista, lista2)==true && inserto.estructuralargoInsertar(lista2)== lista.getItemCount()){
        try {
          inserto.agregarRegistros(VentanaBaseDatosParaIngresar.datos, nombreDeTabla, lista, lista2);
          JOptionPane.showMessageDialog(null,"Se inserto el registro exitosamente");
        }catch (Exception ex) {
           Logger.getLogger(InsertarRegistros.class.getName()).log(Level.SEVERE, null, ex);
        }
      }else{
         JOptionPane.showMessageDialog(null,"Tipo de dato incorrecto");
      }
    }//GEN-LAST:event_botonInsertarActionPerformed
    /**
     * Metodo que se encarga de configurar el areaMostrarTablas InsertarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaMostrarTablasAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaMostrarTablasAncestorAdded
      BaseDatosUsuarios printa=new BaseDatosUsuarios();
      int cont=0;
      int cont2= printa.largoDocTablas(VentanaBaseDatosParaIngresar.datos);
      for(int i=0; i< cont2;i++){
        areaMostrarTablas.append(printa.PrintearTablas(VentanaBaseDatosParaIngresar.datos,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaMostrarTablasAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonVolverInsertar de la intterfaz InsertarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverInsertarActionPerformed
      VentanaBaseDatosParaIngresar ventanaBaseDatos=new VentanaBaseDatosParaIngresar();
      ventanaBaseDatos.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverInsertarActionPerformed

    /**
     * Metodo main de la interfaz grafica InsertarRegistros
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InsertarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InsertarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InsertarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InsertarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InsertarRegistros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaMostrarEstructura;
    private javax.swing.JTextArea areaMostrarTablas;
    private javax.swing.JButton botonInsertar;
    private javax.swing.JButton botonMostrarEstructura;
    private javax.swing.JButton botonVolverInsertar;
    private javax.swing.JLabel indicacionTabla;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField textoDatosIngresar;
    private javax.swing.JTextField textoTablaAModificar;
    private javax.swing.JLabel tituloInsertarRegistros;
    // End of variables declaration//GEN-END:variables
}
