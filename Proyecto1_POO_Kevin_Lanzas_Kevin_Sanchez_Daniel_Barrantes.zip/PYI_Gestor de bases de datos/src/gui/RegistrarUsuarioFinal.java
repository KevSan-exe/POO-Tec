package gui;
import java.awt.Color;
import java.awt.Font;
import usuarios.UsuarioFinal; 
import java.util.logging.Level;
import java.util.logging.Logger;
import usuarios.Admin;
import gestorbasedatos.BaseDatosUsuarios;
import javax.swing.JOptionPane;
    
/**
 * Clase que se encarga de crear la interfaz grafica RegistrarUsuarioFinal
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez 
 */
public class RegistrarUsuarioFinal extends javax.swing.JFrame {
  /**
   * Metodo constructor de la interfaz RegistrarUsuarioFinal
   */  
  public RegistrarUsuarioFinal() {
    setSize(500,500);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica RegistrarUsuarioFinal
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelRegistrar = new javax.swing.JPanel();
        labelRegistrar = new javax.swing.JLabel();
        labelNombre = new javax.swing.JLabel();
        textoNombre = new javax.swing.JTextField();
        labelPuesto = new javax.swing.JLabel();
        textoPuesto = new javax.swing.JTextField();
        labelNombreUsuario = new javax.swing.JLabel();
        textoNombreUsuario = new javax.swing.JTextField();
        labelTelefono = new javax.swing.JLabel();
        textoTelefono = new javax.swing.JTextField();
        botonRegistrar = new javax.swing.JButton();
        botonAtras = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelRegistrar.setLayout(null);
        panelRegistrar.setBackground(Color.white);

        labelRegistrar.setText("Registrar Usuario Final");
        labelRegistrar.setBounds(1234,10,500,30);
        labelRegistrar.setFont(new Font("arial",Font.BOLD,20));

        labelNombre.setText("Nombre Completo");

        labelPuesto.setText("Puesto en la Compañia");

        labelNombreUsuario.setText("Nombre de Usuario (Correo)");

        labelTelefono.setText("Telefono");

        botonRegistrar.setText("Registrar");
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });

        botonAtras.setText("Atras");
        botonAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRegistrarLayout = new javax.swing.GroupLayout(panelRegistrar);
        panelRegistrar.setLayout(panelRegistrarLayout);
        panelRegistrarLayout.setHorizontalGroup(
            panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRegistrarLayout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addComponent(labelRegistrar)
                .addGap(198, 198, 198))
            .addGroup(panelRegistrarLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRegistrarLayout.createSequentialGroup()
                        .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(labelTelefono)
                            .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(labelNombreUsuario)
                                .addComponent(labelNombre, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(labelPuesto, javax.swing.GroupLayout.Alignment.TRAILING)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textoNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                            .addComponent(textoNombreUsuario)
                            .addComponent(textoPuesto)
                            .addComponent(textoTelefono)))
                    .addGroup(panelRegistrarLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(botonRegistrar)
                        .addGap(98, 98, 98)
                        .addComponent(botonAtras)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRegistrarLayout.setVerticalGroup(
            panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRegistrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelRegistrar)
                .addGap(44, 44, 44)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNombre)
                    .addComponent(textoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelPuesto)
                    .addComponent(textoPuesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNombreUsuario)
                    .addComponent(textoNombreUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelTelefono))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonRegistrar)
                    .addComponent(botonAtras))
                .addGap(49, 49, 49))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de la configuracion del botonAtras de la interfaz grafica RegistrarUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasActionPerformed
      VentanaAdmi atraS=new VentanaAdmi();
      atraS.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonAtrasActionPerformed
    /**
     * Metodo que se encarga de la configuracion del botonRegistrar de la interfaz RegistrarUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
      String nombre= textoNombre.getText();
      String correo=textoNombreUsuario.getText();
      String puesto=textoPuesto.getText();
      String nombreUsuario=textoNombreUsuario.getText();
      String telefono=textoTelefono.getText();
      UsuarioFinal usuarioF=new UsuarioFinal(nombre,correo,nombreUsuario,puesto,telefono);
      BaseDatosUsuarios identific=new BaseDatosUsuarios();
      boolean accesos=identific.recorrer(nombreUsuario);
      if (accesos==true){
      }else{
         Admin adm= new Admin("Administrador","adpyipoogestorbasedatos@gmail.com","admin","123Adm$");
         try {
           adm.registrarUsuario(usuarioF);
           identific.mandarMail(nombreUsuario,usuarioF.getContrasenia());
           JOptionPane.showMessageDialog(null,"Se registro el usuario exitosamente");
         }catch (Exception ex) {
            Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(Level.SEVERE, null, ex);
         }
      }
    }//GEN-LAST:event_botonRegistrarActionPerformed

    /**
     * Metodo main de la interfaz grafica RegistrarUsuarioFinal
     * @param args 
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistrarUsuarioFinal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAtras;
    private javax.swing.JButton botonRegistrar;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel labelNombreUsuario;
    private javax.swing.JLabel labelPuesto;
    private javax.swing.JLabel labelRegistrar;
    private javax.swing.JLabel labelTelefono;
    private javax.swing.JPanel panelRegistrar;
    private javax.swing.JTextField textoNombre;
    private javax.swing.JTextField textoNombreUsuario;
    private javax.swing.JTextField textoPuesto;
    private javax.swing.JTextField textoTelefono;
    // End of variables declaration//GEN-END:variables
}
