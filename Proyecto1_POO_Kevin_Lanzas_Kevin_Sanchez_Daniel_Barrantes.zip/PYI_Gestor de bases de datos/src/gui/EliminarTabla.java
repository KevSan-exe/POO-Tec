
package gui;
import java.awt.Color;
import java.awt.Font;
import gestorbasedatos.BaseDatos;
import gestorbasedatos.BaseDatosUsuarios;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;

/**
 * Clase que se encarga de crear la interfaz grafica EliminarTabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class EliminarTabla extends javax.swing.JFrame {
  /**
   * Metodo constructor de la interfaz grafica EliminarTabla
   */
  public EliminarTabla() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica EliminarTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelEliminarTabla = new javax.swing.JPanel();
        tituloEliminarTabla = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        textoTablaEliminar = new javax.swing.JTextField();
        botonAceptarEliminarTabla = new javax.swing.JButton();
        botonVolverEliminarTabla = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaMostrarTablasET = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelEliminarTabla.setLayout(null);
        panelEliminarTabla.setBackground(Color.white);

        tituloEliminarTabla.setText("Eliminar Tabla");
        tituloEliminarTabla.setBounds(1234,10,500,30);
        tituloEliminarTabla.setFont(new Font("arial",Font.BOLD,20));

        jLabel1.setText("Tabla a eliminar");

        botonAceptarEliminarTabla.setText("Aceptar");
        botonAceptarEliminarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarEliminarTablaActionPerformed(evt);
            }
        });

        botonVolverEliminarTabla.setText("Volver");
        botonVolverEliminarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverEliminarTablaActionPerformed(evt);
            }
        });

        areaMostrarTablasET.setColumns(20);
        areaMostrarTablasET.setRows(5);
        areaMostrarTablasET.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaMostrarTablasETAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaMostrarTablasET);

        javax.swing.GroupLayout panelEliminarTablaLayout = new javax.swing.GroupLayout(panelEliminarTabla);
        panelEliminarTabla.setLayout(panelEliminarTablaLayout);
        panelEliminarTablaLayout.setHorizontalGroup(
            panelEliminarTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelEliminarTablaLayout.createSequentialGroup()
                .addGroup(panelEliminarTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelEliminarTablaLayout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(tituloEliminarTabla)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panelEliminarTablaLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelEliminarTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
                            .addComponent(textoTablaEliminar))))
                .addContainerGap())
            .addGroup(panelEliminarTablaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonAceptarEliminarTabla)
                .addGap(71, 71, 71)
                .addComponent(botonVolverEliminarTabla)
                .addGap(71, 71, 71))
        );
        panelEliminarTablaLayout.setVerticalGroup(
            panelEliminarTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelEliminarTablaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloEliminarTabla)
                .addGap(28, 28, 28)
                .addGroup(panelEliminarTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textoTablaEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(panelEliminarTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarEliminarTabla)
                    .addComponent(botonVolverEliminarTabla))
                .addContainerGap(76, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panelEliminarTabla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panelEliminarTabla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonCaeptarEliminar de la interfaz grafica EliminarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarEliminarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarEliminarTablaActionPerformed
      BaseDatos eliminarTablas=new BaseDatos();
      BaseDatosUsuarios accesorEliminar=new BaseDatosUsuarios();
      boolean validador=accesorEliminar.ValidarBasesDatosUsuario(VentanaInicial.usuario,VentanaBaseDatosEliminarTabla.baseDatosET);
        try { 
          if(validador==true){
            boolean eliminacion=eliminarTablas.eliminarTabla(VentanaBaseDatosEliminarTabla.baseDatosET, textoTablaEliminar.getText());
            if(eliminacion==true){
              JOptionPane.showMessageDialog(null,"La tabla fue eliminada correctamente");
            }else{
               JOptionPane.showMessageDialog(null,"La tabla no existe, los datos son incorrectos o la tabla tiene datos");
            }
          }else{
            JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
          }
        }catch (TransformerException | SAXException | IOException | ParserConfigurationException ex) {
          Logger.getLogger(EliminarTabla.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_botonAceptarEliminarTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el botonVolverEliminarTabla de la interfaz EliminarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverEliminarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverEliminarTablaActionPerformed
      VentanaBaseDatosEliminarTabla volverVentanaUFinal=new VentanaBaseDatosEliminarTabla();
      volverVentanaUFinal.setVisible(true);
      this.setVisible(false);
    }//GEN-LAST:event_botonVolverEliminarTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el areaMostrarTablasET de la interfaz EliminarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaMostrarTablasETAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaMostrarTablasETAncestorAdded
      BaseDatosUsuarios printearTablasET=new BaseDatosUsuarios();
      int cont=0;
      int cont2= printearTablasET.largoDocTablas(VentanaBaseDatosEliminarTabla.baseDatosET);
      for(int i=0; i< cont2;i++){
        areaMostrarTablasET.append(printearTablasET.PrintearTablas(VentanaBaseDatosEliminarTabla.baseDatosET,cont)+"\n");
        cont++;
      }
    }//GEN-LAST:event_areaMostrarTablasETAncestorAdded

    /**
     *Metodo main de la interfaz EliminarTabla 
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaMostrarTablasET;
    private javax.swing.JButton botonAceptarEliminarTabla;
    private javax.swing.JButton botonVolverEliminarTabla;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelEliminarTabla;
    private javax.swing.JTextField textoTablaEliminar;
    private javax.swing.JLabel tituloEliminarTabla;
    // End of variables declaration//GEN-END:variables
}
