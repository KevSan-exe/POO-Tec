
package dao;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Clase para crear base de datos
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class CrearBaseDatosDAOXML implements CrearBaseDatosUsuarioFinalDao {
  private static Document documento;
  private static Element raiz;
  private static String nombreDoc;
  private static Element elemento;  
  
  /**
   * crear la base de datos
   * @param pNombre nombre de la base de datos
   * @throws ParserConfigurationException
   * @throws TransformerException 
   */
  public void crearBaseDatos(String pNombre) throws ParserConfigurationException, TransformerException {
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder dBuilder;
    dBuilder = dbFactory.newDocumentBuilder();
    Document doc = dBuilder.newDocument();
    documento = doc;
    raiz = documento.createElement(pNombre);
    documento.appendChild(raiz);
    nombreDoc = pNombre;
    int id=1;
    guardar();
  }
 
  /**
   * agregar la base de datos al documento donde se almacenan los nombres de las mismas
   * @param pUsuario usuario dueno de la base de datos
   * @param pNombreBaseDatos nombre de la base de datos
   */
  public void AgregarBaseDatosAUsuarios(String pUsuario, String pNombreBaseDatos) {
    try{
      EncriptarDesencriptarDAOXML dencriptadoor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());  
        if(desen.equals(pUsuario)){
          elem.getChildNodes().item(i).appendChild(crearElementoBaseDatosAUsuario("BaseDatos",pNombreBaseDatos,document ));
          break;
        }
      }Transformer transformer = TransformerFactory.newInstance().newTransformer();
       Result output = new StreamResult(archivo);
       Source input = new DOMSource(document);
       transformer.transform(input, output);     
    } catch (Exception e){}  
  }
  
  /**
   * agregar la base de datos
   * @param pNombre nombre de la base de datos
   * @throws Exception 
   */
  public void agregarBaseDatos(String pNombre) throws Exception {
    try{
      File archivo = new File("nombresbasesdedatos.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      int id=(int)(Math.random()*1000)+1;
      String idString=Integer.toString(id);
      DOMSource source = new DOMSource(document);
      
      rootElement.appendChild(crearElementoBaseDatos(pNombre,idString,document));
      
      
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }
  
  /**
   * guardar la base de datos
   * @throws TransformerException 
   */
  public void guardar() throws TransformerException {
    String nombreDocumento = nombreDoc + ".xml";
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();           
    DOMSource source = new DOMSource(documento);   
    StreamResult file = new StreamResult(new File(nombreDocumento));
    transformer.transform(source, file);
  }
  
  /**
   * crear elemento base de datos en usuario dueno
   * @param pNombreEtiqueta nombre de la etiqueta
   * @param valor valor de la etiqueta
   * @param pDocumento documento donde ira la etiqueta
   * @return nodo con la etiqueta
   */
  public Node crearElementoBaseDatosAUsuario(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
  
  /**
   * crear elemento base de datos
   * @param pNombre nombre de la base de datos
   * @param pId id de la base de datos
   * @param pDocumento documento donde se guarda
   * @return nodo con el elemento
   */
  public Node crearElementoBaseDatos(String pNombre, String pId, Document pDocumento) {
    Element usuario = pDocumento.createElement("BaseDatos");
    usuario.appendChild(crearElementoBaseDatosS("nombre", pNombre, pDocumento));
    usuario.appendChild(crearElementoBaseDatosS("ID", pId, pDocumento));
    return usuario;
  }
  
  /**
   * crear elemento base de datos
   * @param pNombreEtiqueta nombre de la etiqueta
   * @param valor valor de la etiqueta
   * @param pDocumento documento donde ira la etiqueta
   * @return nodo con el lemento
   */
  public Node crearElementoBaseDatosS(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
    
}
