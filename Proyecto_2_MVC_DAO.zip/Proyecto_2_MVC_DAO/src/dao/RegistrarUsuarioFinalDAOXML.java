package dao;

import com.sun.jdi.connect.Transport;
import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import modelo.UsuarioFinal;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * clase RegistrarUsuarioFinalDAOXML con las funciones que registrar un usuario final
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class RegistrarUsuarioFinalDAOXML implements RegistrarUsuarioFinalDao {

  /**
   * metodo para agregar un usuario a la base de datos
   * @param pUsuario el objeto UsuarioFinal a ingresar
   * @return un objeto tipo UsuarioFinal
   */
  public UsuarioFinal agregarUsuarios(UsuarioFinal pUsuario) { 
    try{
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      
      DOMSource source = new DOMSource(document);
      
      rootElement.appendChild(crearElementoUsuario(pUsuario, document));

      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = null;
        try {
            transformer = transformerFactory.newTransformer();
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(RegistrarUsuarioFinalDAOXML.class.getName()).log(Level.SEVERE, null, ex);
        }
      StreamResult result = new StreamResult(archivo);
        try { 
            transformer.transform(source, result);
        } catch (TransformerException ex) {
            Logger.getLogger(RegistrarUsuarioFinalDAOXML.class.getName()).log(Level.SEVERE, null, ex);
        }
    } catch(IOException | ParserConfigurationException | SAXException e){}
      return pUsuario;
  }
  
  /**
   * metodo para crear un elemento usuario que se puede guardar en un xml
   * @param pNombreEtiqueta el nombre que presentara la etiqueta
   * @param valor el valor que almacenara la etiqueta
   * @param pDocumento el documento donde se guardaran los datos
   * @return 
   */
  public Node crearElementoUsuario(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;  
  }
  
  /**
   * metodo para crear un elemento usuario que se debe guardar en un xml
   * @param pUsuario el objeto usuario a guardar
   * @param pDocumento el documento donde se guardan estos datos
   * @return un nodo usuario
   */
  public Node crearElementoUsuario(UsuarioFinal pUsuario, Document pDocumento) {
    EncriptarDesencriptarDAOXML encriptador=new EncriptarDesencriptarDAOXML();
    Element usuario = pDocumento.createElement("Usuario");
    usuario.appendChild(crearElementoUsuario("nombre",encriptador.encriptar(pUsuario.getNombre()), pDocumento));
    usuario.appendChild(crearElementoUsuario("puesto",encriptador.encriptar(pUsuario.getPuesto()), pDocumento));
    usuario.appendChild(crearElementoUsuario("nombreUsuario",encriptador.encriptar(pUsuario.getUsuario()), pDocumento));
    usuario.appendChild(crearElementoUsuario("correo",encriptador.encriptar(pUsuario.getCorreo()), pDocumento));
    usuario.appendChild(crearElementoUsuario("telefono",encriptador.encriptar(pUsuario.getTelefono()), pDocumento));
    usuario.appendChild(crearElementoUsuario("contrasenia",encriptador.encriptar(pUsuario.getContrasenia()), pDocumento));
    return usuario;
  }
  
  /**
   * metodo para enviar un correo con el correo y la contrasena de acceso al usuario que se ingreso
   * @param pDestinatario correo donde se envian los datos
   * @param pContrasenia contrasena que se genero para el usuario
   */
  public void mandarMail(String pDestinatario, String pContrasenia){
    Properties propiedad = new Properties();
    propiedad.setProperty("mail.smtp.host", "smtp.gmail.com");
    propiedad.setProperty("mail.smtp.starttls.enable", "true");
    propiedad.setProperty("mail.smtp.port", "587");
    propiedad.setProperty("mail.smtp.auth", "true");
    Session sesion = Session.getDefaultInstance(propiedad);    
    String correoEnvia = "adpyipoogestorbasedatos@gmail.com";
    String contrasena = "1234Adm$";
    String destinatario = pDestinatario;
    String asunto = "Nombre de Usuario y Contraseña";
    String mensaje = "Su nombre de usuario es:" +  pDestinatario  +  "y su contraseña es:"  +  pContrasenia; 
    MimeMessage mail = new MimeMessage(sesion); 
    try {
      mail.setFrom(new InternetAddress (correoEnvia));
      mail.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
      mail.setSubject(asunto);
      mail.setText(mensaje);  
      javax.mail.Transport transporte = sesion.getTransport("smtp");
      transporte.connect(correoEnvia,contrasena);
      transporte.sendMessage(mail, mail.getRecipients(Message.RecipientType.TO));
      transporte.close();     
      JOptionPane.showMessageDialog(null, "Se ha enviado un correo electronico con su nombre de usuario y su contraseña");
    } catch (AddressException ex) {
        Logger.getLogger(RegistrarUsuarioFinalDAOXML.class.getName()).log(Level.SEVERE, null, ex);
    } catch (MessagingException ex) {
        Logger.getLogger(RegistrarUsuarioFinalDAOXML.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
  
}
  
    

