
package dao;

import org.w3c.dom.Element;

/**
 * interfaz de la vnetana para obtener la base de datos y crear una tabla en esta
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public interface VentanaBaseDatosCrearTablaDao {
  public abstract int largoDocumento(String pUsuario);    
  public abstract String PrintearBasesDatos(String pUsuario,int cont);
  public abstract int posicionTabla(String nombre,Element rootElement);
}
