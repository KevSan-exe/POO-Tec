package dao;

/**
 * interfaz con los metodos que debe presentar PasswordGeneratorDAOXML
 * @author Kevin Lanzas, Kevin Lanzas, Daniel Barrantes
 */
public interface PasswordGeneratorDao {
  public abstract String getPinNumber();
  public abstract String getPinMayuscula();
  public abstract String getPinEspeciales();
  public abstract String getPassword();
  public abstract String getPassword(int length);
  public abstract String getPassword(String key, int length);
}
