
package dao;

import java.awt.List;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * interfaz para crear tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public interface CrearTablaDao {
  public abstract void agregarTabla(String pNombreBaseDatos,String pNombreTabla,String pNombreCampo,String pTipo,boolean pRequerido) throws Exception;    
  public abstract Node crearElementoTabla(String pNombreEtiqueta, String valor, Document pDocumento);
  public abstract Node crearElementoTabla(String pNombreTabla,String pNombreCampo,String pTipo,boolean pRequerido, Document pDocumento);
  public abstract int posicionTabla(String nombre,Element rootElement);
  public abstract boolean validarTabla(String nombre,Element rootElement);
  public abstract int largoDocTablas(String pNombreBaseDatos);
  public abstract String PrintearTablas(String pNombreBaseDatos,int cont);
  public abstract List printearEstructuraCrear(String pNombreBaseDatos,String pNombreTabla) throws SAXException, ParserConfigurationException, IOException;
}
