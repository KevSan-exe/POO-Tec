
package dao;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * clase para eliminar una tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class EliminarTablaDAOXML implements EliminarTablaDao {
    /**
     * Metodo para eliminar la tabla
     * @param pNombreBaseDatos nombre de la base de datos
     * @param pNombreTabla nombre de la tabla
     * @return verificacion de que se elimino la tabla
     * @throws TransformerConfigurationException
     * @throws TransformerException
     * @throws SAXException
     * @throws IOException
     * @throws ParserConfigurationException 
     */
    public boolean eliminarTabla(String pNombreBaseDatos, String pNombreTabla) throws TransformerConfigurationException, TransformerException, SAXException, IOException, ParserConfigurationException{
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      NodeList nodeList = document.getElementsByTagName(pNombreTabla);
      for (int i = 0; i < nodeList.getLength(); i++){
        Node node = nodeList.item(i);
        Element eElement = (Element) node;
        if(eElement.getTagName().equals(pNombreTabla)){
          NodeList tabla = eElement.getChildNodes();
          if (esTablaVacia(tabla)){ 
            node.getParentNode().removeChild(eElement);
            File archivoNuevo = new File(pNombreBaseDatos + ".xml");
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            Result output = new StreamResult(archivoNuevo);
            Source input = new DOMSource(document);
            transformer.transform(input, output);
            return true;
          }else{
            return false; 
          }
        }
          
      }return false; 
      
    } catch (IOException | ParserConfigurationException | DOMException | SAXException e){} 
      return false;
  }
  
    /**
     * verificar que la tabla es vacia
     * @param tabla nodo con los registros de la tabla
     * @return verficacion si la tabla es vacia
     */
  public boolean esTablaVacia(NodeList tabla){
    int cant = 0;
    for (int i = 0; i < tabla.getLength(); i++){
      cant++; 
    }
    if (cant == 1) {
      return true;
    }else{
      return false;
    }
  }
}
