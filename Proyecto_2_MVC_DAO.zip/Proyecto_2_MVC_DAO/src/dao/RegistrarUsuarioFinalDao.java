package dao;
import modelo.UsuarioFinal;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * interfaz con los metodos que debe presentar RegistrarUsuarioFinalDAOXML
 * @author Kevin Lazas, Kevin Sanchez, Daniel Barrantes
 */
public interface RegistrarUsuarioFinalDao {
  public abstract UsuarioFinal agregarUsuarios(UsuarioFinal pUsuario);  
  public abstract Node crearElementoUsuario(String pNombreEtiqueta, String valor, Document pDocumento);
  public abstract Node crearElementoUsuario(UsuarioFinal pUsuario, Document pDocumento);
  public abstract void mandarMail(String pDestinatario, String pContrasenia);
}
