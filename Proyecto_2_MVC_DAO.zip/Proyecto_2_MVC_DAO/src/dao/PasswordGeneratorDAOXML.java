package dao;

/**
 * Clase la cual permite generar una contrasenia aleatoria a sus usuarios
 * @author Daniel Barrantes,Kevin Lanzas, Kevin Sanchez
 */
public class PasswordGeneratorDAOXML implements PasswordGeneratorDao{
  public static String NUMEROS = "0123456789";
  public static String MAYUSCULAS = "ABCDFGHJKLMNPQRSTVWXYZ";
  public static String MINUSCULAS = "abcdfghjklmnpqrstvwxyz";
  public static String ESPECIALES = "ñÑ@/<>*%$-+";
 
  public String getPinNumber(){
    return getPassword(NUMEROS, 3);
  }
        
  public String getPinMayuscula(){
    return getPassword(MAYUSCULAS,2);
  }
  
  public String getPinEspeciales(){
    return getPassword(ESPECIALES,2);
  }
  
  public String getPassword(){
    return getPassword(2);
  }

  public String getPassword(int length) {
    return getPassword(MINUSCULAS, length);
  }
 
  public String getPassword(String key, int length) {
    String pswd = "";
    for (int i = 0; i < length; i++) {
      pswd+=(key.charAt((int)(Math.random() * key.length())));
    }return pswd;
  }
}    
