
package dao;

import java.awt.List;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import vista.EliminarRegistros;

/**
 * clase para eliminar un registro
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class EliminarRegistrosDAOXML implements EliminarRegistrosDao {
  public int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla) {
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      for(int i = 0; i<elem.getChildNodes().getLength();i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().getLength();
        }
      }  
    }catch (Exception e){} 
     return 0;
  }
  
  /**
   * mostrar la estructura de la tabla
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @param cont contrador
   * @return estructura de la tabla
   */
  public String printearEstructuraTabla(String pNombreBaseDatos, String pNombreTabla, int cont) {
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().item(cont).getTextContent();
        }
      }   
    } catch (Exception e){} 
      return null;
  }
  
  /**
   * construir string de ingreso
   * @param pDatos dato con el cual se construye la string
   * @return una lista con los datos de la string 
   */
  public List ConstruirStringIngresar(String pDatos){
    List lista= new List();
    String prueba="";
    int contComa= ContadorComas(pDatos);
    int cont=0;
    boolean bandera=false;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        lista.add(prueba);
        prueba="";
        cont++;     
      }else if(cont==contComa){
        for(int j=i; j< pDatos.length();j++){
          if(pDatos.charAt(j)!='"'){
            prueba=prueba+pDatos.charAt(j); 
          }  
        }bandera=true;
         break;
      } else if(pDatos.charAt(i)=='"'){
          
      } else if (pDatos.charAt(i) != '"'){
        prueba=prueba+pDatos.charAt(i);
      }
    }lista.add(prueba);
    for(int i=0; i< lista.getItemCount();i++){
    }return lista;
  }
  
  /**
   * contador de comas
   * @param pDatos string donde se cuentan las comas
   * @return cantidad de comas
   */
   public int ContadorComas(String pDatos){
    int cont=0;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        cont++;
      }  
    }return cont;
  }
   
  /**
  * mostrar los registros eliminados
  * @param pNombreBaseDatos nombre de la base de datos
  * @param pNombreTabla nombre de la tabla
  * @param pCondicion condicion para eliminar la tabla
  * @param pCondicion2 condicion para eliminar la tabla
  * @param pSigno signo de comparacion
  * @return cantidad de elementos de la tabla
  */
  public int PrintearEliminarRegistros(String pNombreBaseDatos,String pNombreTabla,String pCondicion, String pCondicion2,String pSigno){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      EliminarRegistros validador= new EliminarRegistros();
      Element elem=document.getDocumentElement();
      int posicion=posicionTabla(pNombreTabla,elem);
      boolean bandera=false;
      List listita=new List();
      DOMSource source = new DOMSource(document);
      int contEliminados=0;
      if("".equals(pSigno)){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          elem.getChildNodes().item(posicion).removeChild(elem.getChildNodes().item(posicion).getChildNodes().item(i));
          contEliminados++;
          i=0;
        }   
      }else if(verificarCajita(pSigno)==1){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                elem.getChildNodes().item(posicion).removeChild(elem.getChildNodes().item(posicion).getChildNodes().item(i));
                i=0;
                contEliminados++;
                break;
              }
            }
          }
        }
      }else if(verificarCajita(pSigno)==2){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(!pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                elem.getChildNodes().item(posicion).removeChild(elem.getChildNodes().item(posicion).getChildNodes().item(i));
                i=0;
                contEliminados++;
                break;
              }
            }
          }
        } 
      }else if(verificarCajita(pSigno)==3){
        if("Int".equals(validador.validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2);
          contEliminados=EliminarEnteros(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);
        }else if("Float".equals(validador.validarTipo(pCondicion2))){
          float condicion2=Float.parseFloat(pCondicion2);
          contEliminados=EliminarFlotantes(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);    
        }
      }else if(verificarCajita(pSigno)==4){
        if("Int".equals(validador.validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2);
          contEliminados=EliminarEnteros(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);     
        }else if("Float".equals(validador.validarTipo(pCondicion2))){
          float condicion2=Float.parseFloat(pCondicion2);
          contEliminados=EliminarFlotantes(pCondicion,condicion2,posicion,elem,bandera,pSigno,contEliminados);      
        }
      }Transformer transformer = TransformerFactory.newInstance().newTransformer();
       Result output = new StreamResult(archivo);
       Source input = new DOMSource(document);
       transformer.transform(input, output); 
       return contEliminados;
    }catch (Exception e){} 
     return 0;
    
  }
  
  /**
   * posicion de la tabala
   * @param nombre nombre de la tabla
   * @param rootElement nombre del elemento
   * @return posicion  
   */
  public int posicionTabla(String nombre,Element rootElement){
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }
  
  /**
   * verificar la comparacion
   * @param pValor string de la comparacion 
   * @return numero de la comparacion
   */
  public int verificarCajita(String pValor){
    if("==".equals(pValor)){
      return 1;
    }else if("!=".equals(pValor)){
      return 2;
    }else if(">".equals(pValor)){
      return 3;
    }else if("<".equals(pValor)){
      return 4;
    }return 0;
  }
  
  /**
   * eliminar las comparaciones en entero
   * @param pCondicion condicion a trabajar
   * @param pCondicion2 segunda condicion a trabajar
   * @param pPosicion posicion de los datos
   * @param pElem elemento de eliminacion
   * @param pBandera indice
   * @param pSigno signo de comparacion
   * @param pCont largo de la tabla
   * @return cantidad de eliminados
   */
  public int EliminarEnteros(String pCondicion,float pCondicion2,int pPosicion,Element pElem,boolean pBandera,String pSigno,int pCont){
    if(verificarCajita(pSigno)==3){       
      for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 > pCondicion2){
              pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
              i=0;
              pCont++;
              break;
            }
          }
        }
      }
    }else{
       for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
         for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
           if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
             int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
             if(modificador2 < pCondicion2){
               pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
               i=0;
               pCont++;
               break;
             }
           }
         }
       }    
    }return pCont;
  }
  public int EliminarFlotantes(String pCondicion,float pCondicion2,int pPosicion,Element pElem,boolean pBandera,String pSigno,int pCont){
    if(verificarCajita(pSigno)==3){       
      for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            Float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 > pCondicion2){
              pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
              i=0;
              pCont++;
              break;
            }
          }
        }
      }
    }else{
      for(int i=1; i< pElem.getChildNodes().item(pPosicion).getChildNodes().getLength();i++){
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            Float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 < pCondicion2){
              pElem.getChildNodes().item(pPosicion).removeChild(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i));
              i=0;
              pCont++;
              break;
            }
          }
        }
      }    
    }return pCont;
  }
   public boolean VerificarEstructuraSeleccionarDatos(List pLista,List pLista2){
    int item=0;
    for(int i=0; i< pLista.getItemCount();i++){
      for(int j=0; j< pLista2.getItemCount();j+=3){
        if(pLista.getItem(i).equals(pLista2.getItem(j))){
          item++;
          break;
        }
      }
    }return item==pLista.getItemCount();
  }
}
    

