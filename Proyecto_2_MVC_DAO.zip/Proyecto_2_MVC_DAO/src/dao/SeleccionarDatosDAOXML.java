
package dao;

import java.awt.List;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import vista.VentanaSeleccionarDatos;

/**
 * Clase para seleccionar datos de una tabla
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public class SeleccionarDatosDAOXML implements SeleccionarDatosDao{
  
    /**
     * metodo para construir una lista de los datos a seleccionar
     * @param pDatos la string a construir
     * @return una lista con los datos de la string separados
     */
    public List ConstruirStringIngresar(String pDatos){
    List lista= new List();
    String prueba="";
    int contComa= ContadorComas(pDatos);
    int cont=0;
    boolean bandera=false;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        lista.add(prueba);
        prueba="";
        cont++;     
      }else if(cont==contComa){
        for(int j=i; j< pDatos.length();j++){
          if(pDatos.charAt(j)!='"'){
            prueba=prueba+pDatos.charAt(j); 
          }  
        }bandera=true;
         break;
      } else if(pDatos.charAt(i)=='"'){
          
      } else if (pDatos.charAt(i) != '"'){
        prueba=prueba+pDatos.charAt(i);
      }
    }lista.add(prueba);
    for(int i=0; i< lista.getItemCount();i++){
    }return lista;
  }
    
  /**
   * metodo para contar las comas en una string
   * @param pDatos string donde se cuentan las strings
   * @return la cantidad de comas
   */
  public int ContadorComas(String pDatos){
    int cont=0;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        cont++;
      }  
    }return cont;
  }
  
  /**
   * Metodo para verificar la estructura de los datos a seleccionar
   * @param pLista lista con los datos
   * @param pLista2 lista con la estrucutura
   * @return verificacion
   */
  public boolean VerificarEstructuraSeleccionarDatos(List pLista,List pLista2){
    int item=0;
    for(int i=0; i< pLista.getItemCount();i++){
      for(int j=0; j< pLista2.getItemCount();j+=3){
        if(pLista.getItem(i).equals(pLista2.getItem(j))){
          item++;
          break;
        }
      }
    }return item==pLista.getItemCount();
  }
  
  /**
   * Metodo para mostrar los datos a selecionar
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @param pLista lista con los datos a seleccionar
   * @param pCondicion la condicion de los datos
   * @param pCondicion2 el requerimiento de los datos
   * @param pSigno el signo de comparacion
   * @return una lista con los datos que coinciden en la comparacion 
   */
  public List PrintearSeleccionarDatos(String pNombreBaseDatos,String pNombreTabla,List pLista,String pCondicion, String pCondicion2,String pSigno){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      VentanaSeleccionarDatos validador= new VentanaSeleccionarDatos(); 
      Element elem=document.getDocumentElement();
      int posicion=posicionTabla(pNombreTabla,elem);
      boolean bandera=false;
      List listita=new List();
      if("".equals(pSigno)){
         for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
           for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
             for(int y=0; y< pLista.getItemCount();y++){  
               if(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName().equals(pLista.getItem(y))){
                 listita.add(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
                 break;
               }  
             }     
           }
         }return listita;
      }else if(verificarCajita(pSigno)==1){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                bandera=true;
                break;
              }
            }
          }if(bandera==true){
             for(int x=0; x< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();x++){
               for(int y=0; y< pLista.getItemCount();y++){  
                 if(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                   listita.add(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                   bandera=false;
                   break;
                 }  
               }  
             }
          }
        } return listita;
        
      }else if(verificarCajita(pSigno)==2){
        for(int i=1; i< elem.getChildNodes().item(posicion).getChildNodes().getLength();i++){
          for(int j=0; j< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
            if(pCondicion.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
              if(!pCondicion2.equals(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent())){
                bandera=true;
                break;
              }
            }
          }if(bandera==true){
             for(int x=0; x< elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().getLength();x++){
               for(int y=0; y< pLista.getItemCount();y++){  
                 if(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                   listita.add(elem.getChildNodes().item(posicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                   bandera=false;
                   break;
                 }  
               }  
             }
          }
        }return listita;
        
      }else if(verificarCajita(pSigno)==3){
        if("Int".equals(validador.validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2); 
          return PrintearSeleccionarEnteros(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);
        }else{
          float condicion2=Float.parseFloat(pCondicion2);
          return PrintearSeleccionarFlotantes(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);   
            
        }
          
      }else if(verificarCajita(pSigno)==4){
        if("Int".equals(validador.validarTipo(pCondicion2))){
          int condicion2=Integer.parseInt(pCondicion2);
          return PrintearSeleccionarEnteros(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);
        }else if("Float".equals(validador.validarTipo(pCondicion2))){
          float condicion2=Float.parseFloat(pCondicion2);
          return PrintearSeleccionarFlotantes(pCondicion,condicion2,posicion,elem,listita,bandera,pLista,pSigno);
        }
      
      }         
    } catch (Exception e){} 
      return null;
  }
  
  /**
   * metodo para obtener la posicion de la tabla
   * @param nombre nombre de la tabla
   * @param rootElement la raiz elemento
   * @return posicion de el elemeneto en la tabla
   */
  public int posicionTabla(String nombre,Element rootElement){
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }
  
  /**
   * metodo para verificar las comparaciones
   * @param pValor string de la comparacion
   * @return un entero que define a a la comparacion 
   */
  public int verificarCajita(String pValor){
    if("==".equals(pValor)){
      return 1;
    }else if("!=".equals(pValor)){
      return 2;
    }else if(">".equals(pValor)){
      return 3;
    }else if("<".equals(pValor)){
      return 4;
    }return 0;
  }
  
  /**
   * Metodo para seleccionar los datos enteros de la compara los enteros
   * @param pCondicion la condicion con que se compara
   * @param pCondicion2 una comparacion
   * @param pPosicion la posicion donde se encuentran los datos
   * @param pElem el elemento que se compara
   * @param pListita lista con los datos a comparar
   * @param pBandera un indice
   * @param pLista lista con los datos de una tabla a comparar
   * @param pSigno signo para comparacion
   * @return lista con los datos que cumplen en la comparacion
   */
   public List PrintearSeleccionarEnteros(String pCondicion,float pCondicion2,int pPosicion,Element pElem,List pListita,boolean pBandera,List pLista,String pSigno){
    if(verificarCajita(pSigno)==3){
      for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 > pCondicion2){
              pBandera=true;
              break;
            }
          }
        }if(pBandera==true){
           for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
             for(int y=0; y< pLista.getItemCount();y++){  
               if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                 pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                 pBandera=false;
                 break;
               }  
             }  
           }
        }
      } return pListita; 
    }else{
       for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
         for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
           if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
             int modificador2=Integer.parseInt(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
             if(modificador2 < pCondicion2){
               pBandera=true;
               break;
             }
           }
         }if(pBandera==true){
            for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
              for(int y=0; y< pLista.getItemCount();y++){  
                if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                  pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                  pBandera=false;
                  break;
                }  
              }  
            }
         }
       } return pListita;
    }
  }
  
   /**
   * Metodo para seleccionar los datos enteros de la compara los flotantes
   * @param pCondicion la condicion con que se compara
   * @param pCondicion2 una comparacion
   * @param pPosicion la posicion donde se encuentran los datos
   * @param pElem el elemento que se compara
   * @param pListita lista con los datos a comparar
   * @param pBandera un indice
   * @param pLista lista con los datos de una tabla a comparar
   * @param pSigno signo para comparacion
   * @return lista con los datos que cumplen en la comparacion
   */
  public List PrintearSeleccionarFlotantes(String pCondicion,float pCondicion2,int pPosicion,Element pElem,List pListita,boolean pBandera,List pLista,String pSigno){
    if (verificarCajita(pSigno)==3){
      for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
              if(modificador2 > pCondicion2){
                pBandera=true;
                break;
              }
          }
        }if(pBandera==true){
          for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
            for(int y=0; y< pLista.getItemCount();y++){  
              if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                pBandera=false;
                break;
              }  
            }  
          }
        }
      }return pListita;
    }else{
      for (int i = 1; i < pElem.getChildNodes().item(pPosicion).getChildNodes().getLength(); i++) {
        for(int j=0; j< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();j++){  
          if(pCondicion.equals(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getNodeName())){
            float modificador2=Float.parseFloat(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
            if(modificador2 < pCondicion2){
              pBandera=true;
              break;
            }
          }
        }if(pBandera==true){
          for(int x=0; x< pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().getLength();x++){
            for(int y=0; y< pLista.getItemCount();y++){  
              if(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getNodeName().equals(pLista.getItem(y))){
                pListita.add(pElem.getChildNodes().item(pPosicion).getChildNodes().item(i).getChildNodes().item(x).getTextContent());
                pBandera=false;
                break;
              }  
            }  
          }
        }
      } return pListita;     
    }
  }
  
  /**
   * Muestra el largo de la estructura
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @return largo de la estructura
   */
  public int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      for(int i = 0; i<elem.getChildNodes().getLength();i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().getLength();
        }
      }  
    }catch (Exception e){} 
     return 0;
  }
  
  /**
   * Muestra la estrucutura de la tabla
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @param cont largo de la estructura
   * @return un string de la estructura de la tabla
   */
  public String printearEstructuraTabla(String pNombreBaseDatos,String pNombreTabla, int cont){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().item(cont).getTextContent();
        }
      }   
    } catch (Exception e){} 
      return null;
  }
}
