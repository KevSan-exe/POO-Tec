package dao;

import java.awt.List;
import org.w3c.dom.Element;

/**
 * interfaz para eliminar un registro
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public interface EliminarRegistrosDao {
  public abstract int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla); 
  public abstract String printearEstructuraTabla(String pNombreBaseDatos,String pNombreTabla, int cont);  
  public abstract List ConstruirStringIngresar(String pDatos);
  public abstract int ContadorComas(String pDatos);
  public abstract int PrintearEliminarRegistros(String pNombreBaseDatos,String pNombreTabla,String pCondicion, String pCondicion2,String pSigno);
  public abstract int posicionTabla(String nombre,Element rootElement);
  public abstract int verificarCajita(String pValor);
  public abstract int EliminarEnteros(String pCondicion,float pCondicion2,int pPosicion,Element pElem,boolean pBandera,String pSigno,int pCont);
  public abstract int EliminarFlotantes(String pCondicion,float pCondicion2,int pPosicion,Element pElem,boolean pBandera,String pSigno,int pCont);
  public abstract boolean VerificarEstructuraSeleccionarDatos(List pLista,List pLista2);
}
