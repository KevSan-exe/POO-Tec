
package dao;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * clase para cambiar el nombre de la tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class CambiarTablaDAOXML implements CambiarTablaDao {
  /**
   * cambiar el nombre de la tabla
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @param pNombreTablaNuevo nombre nuevo de la tabla 
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws TransformerException 
   */
  public void changeTagName(String pNombreBaseDatos, String pNombreTabla, String pNombreTablaNuevo) throws ParserConfigurationException, SAXException, IOException, TransformerException {
    File archivo = new File(pNombreBaseDatos + ".xml");
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    Document document = documentBuilder.parse(archivo);
    NodeList nodes = document.getElementsByTagName(pNombreTabla);
    for (int i = 0; i < nodes.getLength(); i++) {
      if(nodes.item(i) instanceof Element) {
        Element elem = (Element)nodes.item(i);
        document.renameNode(elem, elem.getNamespaceURI(), pNombreTablaNuevo);
        File archivoNuevo = new File(pNombreBaseDatos + ".xml");  
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        Result output = new StreamResult(archivoNuevo);
        Source input = new DOMSource(document);
        transformer.transform(input, output);
      }
    }
  }
   
}
