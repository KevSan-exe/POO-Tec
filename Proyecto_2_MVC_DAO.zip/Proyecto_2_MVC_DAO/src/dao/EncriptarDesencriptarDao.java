package dao;

/**
 * interfaz con los metodos que deben presentar EncriptarDesencriptarDAOXML
 * @author Kevin Sanchez, Daniel Barrantes, Kevin Lanzas
 */
public interface EncriptarDesencriptarDao {
  public abstract String encriptar(String pTexto);
  public abstract String desencriptar(String pTexto);
  
    
}
