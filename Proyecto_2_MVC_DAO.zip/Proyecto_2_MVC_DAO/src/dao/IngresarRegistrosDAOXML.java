
package dao;

import java.awt.List;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Clase para ingresar un registro a una tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class IngresarRegistrosDAOXML implements IngresarRegistrosDao{
  public int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      for(int i = 0; i<elem.getChildNodes().getLength();i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().getLength();
        }
      }  
    }catch (Exception e){} 
     return 0;
  } 
  
  /**
   * Metodo para printear la estructura de la tabla
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @param cont largo de la estructura de la tabla
   * @return String de la estructura
   */
  public String printearEstructuraTabla(String pNombreBaseDatos,String pNombreTabla, int cont){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return elem.getChildNodes().item(i).getFirstChild().getChildNodes().item(cont).getTextContent();
        }
      }   
    } catch (Exception e){} 
      return null;
  }
  
  /**
   * construir la string
   * @param pDatos dato con el que se construye la string
   * @return una lista con los datos de la string
   */
  public List ConstruirStringIngresar(String pDatos){
    List lista= new List();
    String prueba="";
    int contComa= ContadorComas(pDatos);
    int cont=0;
    boolean bandera=false;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        lista.add(prueba);
        prueba="";
        cont++;     
      }else if(cont==contComa){
        for(int j=i; j< pDatos.length();j++){
          if(pDatos.charAt(j)!='"'){
            prueba=prueba+pDatos.charAt(j); 
          }  
        }bandera=true;
         break;
      } else if(pDatos.charAt(i)=='"'){
          
      } else if (pDatos.charAt(i) != '"'){
        prueba=prueba+pDatos.charAt(i);
      }
    }lista.add(prueba);
    for(int i=0; i< lista.getItemCount();i++){
    }return lista;
  }
  
  /**
   * contador de comas en una string
   * @param pDatos string con las comas
   * @return cantidad de comas
   */
   public int ContadorComas(String pDatos){
    int cont=0;
    for(int i=0; i<pDatos.length();i++){
      if(pDatos.charAt(i)==','){
        cont++;
      }  
    }return cont;
  }
   
   /**
    * metodo para agregar un registro a una tabla
    * @param pNombreBaseDatos nombre de la base de datos
    * @param pNombreTabla nombre de la tabla
    * @param pLista lista con la estructura
    * @param pLista2 lista con los datos del registro
    * @throws Exception 
    */
  public void agregarRegistros(String pNombreBaseDatos,String pNombreTabla,List pLista, List pLista2) throws Exception{
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      int p=posicionTabla(pNombreTabla,rootElement);
      DOMSource source = new DOMSource(document);
  
      rootElement.getChildNodes().item(p).appendChild(crearElementoInsertar(pLista,pLista2,document));
      
      
      
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }
  
  /**
   * metodo para crear un elemento a insertar
   * @param pLista lista con los datos del elemento
   * @param pLista2 lista con los datos para el elemento
   * @param pDocumento documento donde se encontraran los elementos
   * @return nodo con los elementos
   */
  public Node crearElementoInsertar(List pLista,List pLista2, Document pDocumento) {
    Element usuario = pDocumento.createElement("Registros");
    int j=0;
    for(int i=0; i<pLista.getItemCount();i++){
      usuario.appendChild(crearElementoTabla(pLista2.getItem(j),pLista.getItem(i), pDocumento));   
      j+=3;
    }return usuario;
  }
  
  /**
   * obtener con la posicion de la tabla
   * @param nombre dato de la posicion
   * @param rootElement elemento raiz
   * @return 
   */
  public int posicionTabla(String nombre,Element rootElement){
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }
  
  /**
   * creacion del elemento tabla
   * @param pNombreEtiqueta nombre de la etiqueta
   * @param valor valor de la etiqueta
   * @param pDocumento documento donde se va a encontrar la etiqueta
   * @return nodo con el elemento
   */
  public Node crearElementoTabla(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }
  
}
