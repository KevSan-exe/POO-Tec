
package dao;

import java.awt.List;
import org.w3c.dom.Element;

/**
 * interfaz para seleccionar un dato de una base de datos
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public interface SeleccionarDatosDao {
  public abstract List ConstruirStringIngresar(String pDatos);   
  public abstract int ContadorComas(String pDatos);
  public abstract boolean VerificarEstructuraSeleccionarDatos(List pLista,List pLista2);
  public abstract List PrintearSeleccionarDatos(String pNombreBaseDatos,String pNombreTabla,List pLista,String pCondicion, String pCondicion2,String pSigno);
  public abstract int posicionTabla(String nombre,Element rootElement); 
  public abstract int verificarCajita(String pValor);
  public abstract List PrintearSeleccionarEnteros(String pCondicion,float pCondicion2,int pPosicion,Element pElem,List pListita,boolean pBandera,List pLista,String pSigno);
  public abstract List PrintearSeleccionarFlotantes(String pCondicion,float pCondicion2,int pPosicion,Element pElem,List pListita,boolean pBandera,List pLista,String pSigno);
  public abstract int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla);
  public abstract String printearEstructuraTabla(String pNombreBaseDatos,String pNombreTabla, int cont);
}
