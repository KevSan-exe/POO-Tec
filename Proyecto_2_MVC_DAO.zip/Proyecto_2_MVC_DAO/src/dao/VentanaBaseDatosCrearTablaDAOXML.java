
package dao;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Clase para obtener la base de datos donde se creara una tabla
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public class VentanaBaseDatosCrearTablaDAOXML implements VentanaBaseDatosCrearTablaDao {
  
  /**
   * metodo para determinar el largo del documento
   * @param pUsuario el nombre del usuario
   * @return el largo del documento
   */  
  public int largoDocumento(String pUsuario) {
   try{
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      int posicion=posicionTabla(pUsuario,elem);
      return elem.getChildNodes().item(posicion).getChildNodes().getLength();
    } catch (Exception e){} 
      return 0; 
  }
  
  /**
   * Metodo para mostrar las bases de datos que tiene acceso el usuario
   * @param pUsuario el usuario que tiene acceso a las bases de datos
   * @param cont posicion donde esta la base de datos
   * @return el nombre de la base de datos
   */
  public String PrintearBasesDatos(String pUsuario, int cont) {
    try{
      EncriptarDesencriptarDAOXML dencriptadoor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=cont; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            return elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent();  
          }  
        }
      }   
    }catch (Exception e){} 
     return null;    
  }
  
  /**
   * Metodo para conocer donde se encuentra la tabla
   * @param nombre nombre de la tabla
   * @param rootElement elemento nombre de la tabla
   * @return la posicion de la tabla
   */
  public int posicionTabla(String nombre, Element rootElement) {
    EncriptarDesencriptarDAOXML des=new EncriptarDesencriptarDAOXML();
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      String desencripto=des.desencriptar(rootElement.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
      if(desencripto.equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }
      
}
