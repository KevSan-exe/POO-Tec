package dao;

import controlador.ControladorInicioSesion;
import vista.VentanaInicial;

/**
 * metodo main que permite iniciar el programa
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class mainInicioSesion {
  public static void main(String[] args) {
    VentanaInicial vista= new VentanaInicial();
    
    ControladorInicioSesion controlador = new ControladorInicioSesion(vista);
        
    controlador.vista.setVisible(true);
    controlador.vista.setLocationRelativeTo(null);
  }
   
}
