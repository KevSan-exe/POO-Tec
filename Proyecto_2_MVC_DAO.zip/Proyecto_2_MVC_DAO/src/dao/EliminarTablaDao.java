
package dao;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * interfaz para eliminar una tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public interface EliminarTablaDao {
  public abstract boolean eliminarTabla(String pNombreBaseDatos, String pNombreTabla) throws TransformerConfigurationException, TransformerException, SAXException, IOException, ParserConfigurationException;   
  public abstract boolean esTablaVacia(NodeList tabla);
}
