
package dao;

import java.awt.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * interfaz para ingresar un registro a una tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public interface IngresarRegistrosDao {
  public abstract int largoDocEstructura(String pNombreBaseDatos, String pNombreTabla);    
  public abstract String printearEstructuraTabla(String pNombreBaseDatos,String pNombreTabla, int cont);
  public abstract List ConstruirStringIngresar(String pDatos);
  public abstract int ContadorComas(String pDatos);
  public abstract void agregarRegistros(String pNombreBaseDatos,String pNombreTabla,List pLista, List pLista2) throws Exception;
  public abstract Node crearElementoInsertar(List pLista,List pLista2, Document pDocumento);
  public abstract int posicionTabla(String nombre,Element rootElement);
  public abstract Node crearElementoTabla(String pNombreEtiqueta, String valor, Document pDocumento);
}
