package dao;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

/**
 * interfaz con los metodos que se deben presentar en EliminarUsuarioDAOXML
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public interface EliminarUsuarioDao {
  public abstract int prueba();
  public abstract boolean eliminarUsuario(String pEliminado) throws TransformerConfigurationException, TransformerException;
  public abstract String recorrer(int cont);
}
