
package dao;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;

/**
 * interfaz para cambiar el nombre de la tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public interface CambiarTablaDao {
  public abstract void changeTagName(String pNombreBaseDatos, String pNombreTabla, String pNombreTablaNuevo) throws ParserConfigurationException, SAXException, IOException, TransformerException;   
}
