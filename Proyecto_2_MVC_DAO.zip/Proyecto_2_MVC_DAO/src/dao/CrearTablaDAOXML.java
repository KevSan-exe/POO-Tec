
package dao;

import java.awt.List;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * clase para crear una tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class CrearTablaDAOXML implements CrearTablaDao{

  /**
   * agregar una tabla
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @param pNombreCampo nombre del campo
   * @param pTipo tipo del campo
   * @param pRequerido verificacion si es requerido
   * @throws Exception 
   */
  public void agregarTabla(String pNombreBaseDatos, String pNombreTabla, String pNombreCampo, String pTipo, boolean pRequerido) throws Exception {
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      int p=posicionTabla(pNombreTabla,rootElement);
      DOMSource source = new DOMSource(document);
      
      if(rootElement.getChildNodes().getLength()==0){
        rootElement.appendChild(usuario);
        usuario.appendChild(crearElementoTabla("Campos",pNombreCampo,pTipo,pRequerido,document));
      }else if(validarTabla(pNombreTabla,rootElement)){
          rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla(pNombreCampo,pNombreCampo,document));
          rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla("Tipo",pTipo, document));
          if(pRequerido==true){
            rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla("Requerido","SI", document));
          }else{
            rootElement.getChildNodes().item(p).getFirstChild().appendChild(crearElementoTabla("Requerido","NO", document));
          }
          
      }else{
          rootElement.appendChild(usuario);
          usuario.appendChild(crearElementoTabla("Campos",pNombreCampo,pTipo,pRequerido,document));    
      }
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      StreamResult result = new StreamResult(archivo);
      transformer.transform(source, result); 
    } catch(IOException | ParserConfigurationException | SAXException e){}
  }

  /**
   * creacion de un elemento que sera la tabla
   * @param pNombreEtiqueta nombre de la etiqueta
   * @param valor valor en la etiqueta
   * @param pDocumento documento donde ira la etiqueta
   * @return nodo con el elemento
   */
  public Node crearElementoTabla(String pNombreEtiqueta, String valor, Document pDocumento) {
    Element node = pDocumento.createElement(pNombreEtiqueta);
    node.appendChild(pDocumento.createTextNode(valor));
    return node;
  }

  /**
   * creacion del elemento que sera la tabla
   * @param pNombreTabla nombre de la tabla
   * @param pNombreCampo nombre del campo
   * @param pTipo tipo del campo
   * @param pRequerido sera requerido
   * @param pDocumento documento donde ira el elemento
   * @return 
   */
  public Node crearElementoTabla(String pNombreTabla, String pNombreCampo, String pTipo, boolean pRequerido, Document pDocumento) {
    Element usuario = pDocumento.createElement(pNombreTabla);
    usuario.appendChild(crearElementoTabla(pNombreCampo,pNombreCampo, pDocumento));
    usuario.appendChild(crearElementoTabla("Tipo",pTipo, pDocumento));
    if(pRequerido==true){
      usuario.appendChild(crearElementoTabla("Requerido","SI", pDocumento));
    }else{
      usuario.appendChild(crearElementoTabla("Requerido","NO", pDocumento));
    }
    return usuario;
  }

  /**
   * posicion donde estara la tabla
   * @param nombre nombre de la tabla
   * @param rootElement el elemento raiz
   * @return posicion de la tabla
   */
  public int posicionTabla(String nombre, Element rootElement) {
    int cont=0;
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return cont;
      }else{
        cont++;
      }
    }return cont;   
  }

  /**
   * validacion de la tabla
   * @param nombre nombre de la tabla
   * @param rootElement elemento raiz
   * @return validacion de la tabla
   */
  public boolean validarTabla(String nombre, Element rootElement) {
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return true;
      }
    }return false;  
  }
  
  /**
   * largo del documento base de datos con tablas
   * @param pNombreBaseDatos nombre de la base de datos
   * @return largo de la base de datos
   */
  public int largoDocTablas(String pNombreBaseDatos) {
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      Element elem=document.getDocumentElement();
      return elem.getChildNodes().getLength();
    } catch (Exception e){} 
      return 0;
  }
  
  /**
   * mostrar las tablas
   * @param pNombreBaseDatos nombre de la base de datos
   * @param cont indice
   * @return String con las tablas
   */
  public String PrintearTablas(String pNombreBaseDatos, int cont) {
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      return elem.getChildNodes().item(cont).getNodeName();        
    } catch (Exception e){} 
      return null;
  }
  
  /**
   * Mostrar las estructuras para crear las tablas
   * @param pNombreBaseDatos nombre de la base de datos
   * @param pNombreTabla nombre de la tabla
   * @return lista con la estructura
   * @throws SAXException
   * @throws ParserConfigurationException
   * @throws IOException 
   */
  public List printearEstructuraCrear(String pNombreBaseDatos, String pNombreTabla) throws SAXException, ParserConfigurationException, IOException {
    File archivo = new File(pNombreBaseDatos + ".xml");
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    Document document = documentBuilder.parse(archivo);
      
    Element elem=document.getDocumentElement(); 
    int posicion=posicionTabla(pNombreTabla,elem);
    List lista=new List();
    for(int i=0; i<elem.getChildNodes().item(posicion).getChildNodes().item(0).getChildNodes().getLength();i++){
      lista.add(elem.getChildNodes().item(posicion).getChildNodes().item(0).getChildNodes().item(i).getTextContent());
    }return lista;
  }
}
    

