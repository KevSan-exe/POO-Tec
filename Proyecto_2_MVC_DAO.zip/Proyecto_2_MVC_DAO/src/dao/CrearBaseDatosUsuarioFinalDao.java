
package dao;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * interfaz para crear una base de datos
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public interface CrearBaseDatosUsuarioFinalDao {
  public abstract void crearBaseDatos(String pNombre) throws ParserConfigurationException, TransformerException;
  public abstract void AgregarBaseDatosAUsuarios(String pUsuario,String pNombreBaseDatos);
  public abstract void agregarBaseDatos(String pNombre) throws Exception;
  public abstract void guardar() throws TransformerException;
  public abstract Node crearElementoBaseDatosAUsuario(String pNombreEtiqueta, String valor, Document pDocumento);
  public abstract Node crearElementoBaseDatos(String pNombre,String pId,Document pDocumento);
  public abstract Node crearElementoBaseDatosS(String pNombreEtiqueta, String valor, Document pDocumento);
}
