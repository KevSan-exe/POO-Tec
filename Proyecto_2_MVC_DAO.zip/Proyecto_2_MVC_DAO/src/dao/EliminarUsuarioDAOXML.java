package dao;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Clase EliminarUsuarioDAOXML con las funciones para eliminar un usuario
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public class EliminarUsuarioDAOXML implements EliminarUsuarioDao {

  /**
   * metodo prueba para retornar la cantidad de usuarios en la base de datos
   * @return la cantidad de usuarios en la base de datos 
   */
  public int prueba() {
    try{
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      return childeren.item(0).getChildNodes().getLength();
    } catch (Exception e){} 
      return 0; 
  }

  /**
   * metodo que permite eliminar usuarios
   * @param pEliminado el nombre de usuario del usuario que se desea eliminar
   * @return un boolean que indica si se pudo eliminar el usuario
   * @throws TransformerConfigurationException
   * @throws TransformerException 
   */
  public boolean eliminarUsuario(String pEliminado) throws TransformerConfigurationException, TransformerException {
    try{
      EncriptarDesencriptarDAOXML desencriptaa=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      NodeList nodeList = document.getElementsByTagName("Usuario");
      for (int i = 0; i < nodeList.getLength(); i++){
        Node node = nodeList.item(i);
        Element eElement = (Element) node;
        String texto= desencriptaa.desencriptar(eElement.getElementsByTagName("nombreUsuario").item(0).getTextContent());
        if (texto.equals("admin")){
            
        }else if(texto.equals(pEliminado)){
          node.getParentNode().removeChild(eElement);
          File archivoNuevo = new File("basededatosusuarios_Admin.xml");
          Transformer transformer = TransformerFactory.newInstance().newTransformer();
          Result output = new StreamResult(archivoNuevo);
          Source input = new DOMSource(document);
          transformer.transform(input, output);
          return true;
        }
      }return false; 
    }catch (IOException | ParserConfigurationException | DOMException | SAXException e){} 
     return false;
  }

  /**
   * metodo para mostrar un usuario guardado en la base de datos
   * @param cont posicion donde se encuentra el usuario
   * @return un string con los datos del usuario
   */  
  public String recorrer(int cont) {
    try{
      EncriptarDesencriptarDAOXML desencriptor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      for (int i = cont; i < childeren.item(0).getChildNodes().getLength(); i++){
        int contador=0;
        for (int j = 0; j < childeren.item(0).getChildNodes().item(i).getChildNodes().getLength(); j++){
          if(contador==2){
            String printear=(desencriptor.desencriptar(childeren.item(0).getChildNodes().item(i).getChildNodes().item(j).getTextContent()));
            return printear;
          }else{
            contador++;
          }          
        }    
      } 
    }catch (Exception e){} 
      return null;  
  }
}
    

