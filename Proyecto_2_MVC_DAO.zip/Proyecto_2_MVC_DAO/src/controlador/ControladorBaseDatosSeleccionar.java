package controlador;

import dao.VentanaBaseDatosCrearTablaDAOXML;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaBaseDatosParaIngresar;
import vista.VentanaBaseDatosSeleccionarDatos;
import vista.VentanaInicial;

/**
 * Clase controlador para seleccionar una base de datos
 * @author Kevin Sanchez, Kevin Lanzas, Daniel Barrantes
 */
public class ControladorBaseDatosSeleccionar implements ActionListener {
  public VentanaBaseDatosSeleccionarDatos vista;


  /**
   * metodo constructor de la clase ControladorInicioSesion
   * @param pVista ventana de inicio sesion
   */  
  public ControladorBaseDatosSeleccionar(VentanaBaseDatosSeleccionarDatos pVista){
    vista = pVista; 
    int cont=6;
    VentanaBaseDatosCrearTablaDAOXML printear= new VentanaBaseDatosCrearTablaDAOXML();
    int cont2= printear.largoDocumento(VentanaInicial.usuario);
    for(int i=cont; i< cont2;i++){
      vista.textoMostrarBasesDatos.append(printear.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
      cont++;
    }
    this.vista.botonAceptarSeleccionar.addActionListener(this);
    this.vista.botonVolverSeleccionar.addActionListener(this);
  }
  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        avanzaInsertarRegistros();
        break;
      case "Volver":
        cerrarVentanaBaseIngresar();
        break;
    }
  }
  /**
   * metodo logIn que redirecciona a las funciones de administrador o usuario final
   * segun el tipo de usuario que se ingrese
   */
  public void avanzaInsertarRegistros(){
    if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, vista.textoBaseDatosSeleccionar.getText())==true){
      VentanaBaseDatosSeleccionarDatos.baseDatos=vista.textoBaseDatosSeleccionar.getText();
      vista.setVisible(false);
      vista.seleccionarDatos();
    }else{
      JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
    }
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaBaseIngresar() {
    vista.setVisible(false);
    vista.atrasUF();
  }
}
