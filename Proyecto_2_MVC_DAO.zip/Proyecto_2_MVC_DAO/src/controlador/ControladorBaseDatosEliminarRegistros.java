
package controlador;

import dao.VentanaBaseDatosCrearTablaDAOXML;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaBaseDatosEliminarRegistros;
import vista.VentanaInicial;

/**
 * Clase controlador para obtener el nombre de la base de datos para la opcion eliminar registro
 * @author Kevin Sanchez, Daniel Barrantes, Kevin Lanzas
 */
public class ControladorBaseDatosEliminarRegistros implements ActionListener {
  public VentanaBaseDatosEliminarRegistros vista;


  /**
   * metodo constructor de la clase ControladorInicioSesion
   * @param pVista ventana de inicio sesion
   */  
  public ControladorBaseDatosEliminarRegistros(VentanaBaseDatosEliminarRegistros pVista){
    vista = pVista; 
    int cont=6;
    VentanaBaseDatosCrearTablaDAOXML printear= new VentanaBaseDatosCrearTablaDAOXML();
    int cont2= printear.largoDocumento(VentanaInicial.usuario);
    for(int i=cont; i< cont2;i++){
      vista.areaBaseDatosEliminar.append(printear.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
      cont++;
    }
    this.vista.botonAceptarEliminar.addActionListener(this);
    this.vista.botonVolverEliminar.addActionListener(this);
  }
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        avanzaEliminarRegistros();
        break;
      case "Volver":
        cerrarVentanaBaseEliminar();
        break;
    }
  }
  /**
   * metodo logIn que redirecciona a las funciones de administrador o usuario final
   * segun el tipo de usuario que se ingrese
   */
  public void avanzaEliminarRegistros(){
    if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, vista.textoBaseDatosEliminar.getText())==true){
      VentanaBaseDatosEliminarRegistros.baseDatos=vista.textoBaseDatosEliminar.getText();
      vista.setVisible(false);
      vista.ingresarRegistros();
    }else{
      JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
    }
  }
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaBaseEliminar() {
    vista.setVisible(false);
    vista.atrasBaseDatosIngresar();
  }
}
