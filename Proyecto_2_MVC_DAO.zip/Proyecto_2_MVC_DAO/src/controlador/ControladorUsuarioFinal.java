package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaInicial;
import vista.VentanaUsuarioFinal;

/**
 * clase controlador de las funciones que se realizan desde la ventana con las
 * opciones del usuario final
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorUsuarioFinal implements ActionListener {
  public VentanaUsuarioFinal vista;

  /**
   * metodo constructor de la clase ControladorUsuarioFinal
   * @param pVista ventana donde se realizan las funciones de usuario final
   */  
  public ControladorUsuarioFinal(VentanaUsuarioFinal pVista){
    vista = pVista;   
    this.vista.botonDatosUsuarioFinal.addActionListener(this);
    this.vista.botonCambiarNombre.addActionListener(this);
    this.vista.botonEliminarTablas.addActionListener(this);
    this.vista.botonAccesoCrearTablas.addActionListener(this);
    this.vista.botonInsertarRegistros.addActionListener(this);
    this.vista.botonCerrarSesionFinal.addActionListener(this);
    this.vista.botonEliminar.addActionListener(this);
    this.vista.botonSeleccionarDatos.addActionListener(this);
  }
  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Crear Base de Datos":
        crearBaseDatos();
        break;
      case "Cambiar nombre tabla":
        cambiarTabla();
        break;
      case "Eliminar Tabla":
        eliminarTabla();
        break;
      case "Crear Tablas":
        crearTabla();
        break;
      case "Insertar Registros":
        insertarRegistros();
        break;
      case "Cerrar Sesion":
        cerrarSesionUsuarioFinal();
        break;
      case "Eliminar Registros":
        eliminarRegistros();
        break;
      case "Seleccionar Datos":
        seleccionarDatos();
        break;
      default:
        break;
    }
  }
  
  /**
   * metodo para permitir la creacion de una base de datos
   */
  public void crearBaseDatos(){
    vista.setVisible(false);
    vista.avanzarCrearBase();
  }
  
  /**
   * metodo que retorna a la ventana que permite la creacion de tablas
   */
  public void crearTabla(){
    vista.setVisible(false);
    vista.avanzarCrearTabla();
  }
  
  /**
   * metodo que retorna a la ventana que permite cambiar el nombre de una tabla
   */
  public void cambiarTabla(){
    vista.setVisible(false);
    vista.avanzarCambiarTabla();
  }
  
  /**
   * metodo que retorna a la ventana que permite eliminar una tabla
   */
  public void eliminarTabla(){
    vista.setVisible(false);
    vista.avanzarEliminarTabla();
  }
  
  /**
   * metodo que retorna a la ventana que permite insertar registro 
   */
  public void insertarRegistros(){
    vista.setVisible(false);
    vista.avanzarBaseDatosIngresar();
  }
  
  /**
   * metodo que retorna a la ventana que permite eliminar registros
   */
  public void eliminarRegistros(){
    vista.setVisible(false);
    vista.avanzarBaseDatosEliminarRegistros();
  }
  
  /**
   * metodo que retorna a la ventana que permite seleccionar datos
   */
  public void seleccionarDatos(){
    vista.setVisible(false);
    vista.avanzarBaseDatosSeleccionar();
  }
  
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaLogin() {
  }
  
  public void cerrarSesionUsuarioFinal(){
    vista.setVisible(false);
    vista.cerrarSesionUF();
  }
}