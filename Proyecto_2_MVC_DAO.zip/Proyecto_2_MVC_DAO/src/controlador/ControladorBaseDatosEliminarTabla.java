
package controlador;

import dao.VentanaBaseDatosCrearTablaDAOXML;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaBaseDatosCambiarTabla;
import vista.VentanaBaseDatosEliminarTabla;
import vista.VentanaInicial;

/**
 * Clase controlador para eliminar una tabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorBaseDatosEliminarTabla implements ActionListener {
  public VentanaBaseDatosEliminarTabla vista;


  /**
   * metodo constructor de la clase ControladorInicioSesion
   * @param pVista ventana de inicio sesion
   */  
  public ControladorBaseDatosEliminarTabla(VentanaBaseDatosEliminarTabla pVista){
    vista = pVista; 
    int cont=6;
    VentanaBaseDatosCrearTablaDAOXML printear= new VentanaBaseDatosCrearTablaDAOXML();
    int cont2= printear.largoDocumento(VentanaInicial.usuario);
    for(int i=cont; i< cont2;i++){
      vista.areaBaseDatosEliminarTabla.append(printear.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
      cont++;
    }
    this.vista.botonAceptarEliminarTabla.addActionListener(this);
    this.vista.botonVolverEliminarTabla.addActionListener(this);
  }
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        avanzaEliminarTabla();
        break;
      case "Volver":
        cerrarVentanaBaseET();
        break;
    }
  }
  /**
   * metodo logIn que redirecciona a las funciones de administrador o usuario final
   * segun el tipo de usuario que se ingrese
   */
  public void avanzaEliminarTabla(){
    if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, vista.textoBaseDatosEliminarTabla.getText())==true){
      VentanaBaseDatosEliminarTabla.baseDatosET=vista.textoBaseDatosEliminarTabla.getText();
      vista.setVisible(false);
      vista.avanzarVentanaEliminarTabla();
    }else{
      JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
    }
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaBaseET() {
    vista.setVisible(false);
    vista.atrasVentanaUFinal();
  }
}
