package controlador;

import dao.CrearTablaDAOXML;
import dao.EliminarRegistrosDAOXML;
import dao.EliminarRegistrosDao;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.EliminarRegistros;
import vista.VentanaBaseDatosEliminarRegistros;

/**
 * Clase controlador para la funcion eliminar registro
 * @author Daniel Barrantes, Kevin Sanchez, KEvin Lanzas 
 */
public class ControladorEliminarRegistros implements ActionListener {
    public EliminarRegistros vista;
    public EliminarRegistrosDao dao;

  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorEliminarRegistros(EliminarRegistros pVista){
    vista=pVista;
    dao=new EliminarRegistrosDAOXML();
    CrearTablaDAOXML print= new CrearTablaDAOXML();
    vista.AreaTextoTablasEliminar.setText(null);
    int cont=0;
      int cont2= print.largoDocTablas(VentanaBaseDatosEliminarRegistros.baseDatos);
      for(int i=0; i< cont2;i++){
        vista.AreaTextoTablasEliminar.append(print.PrintearTablas(VentanaBaseDatosEliminarRegistros.baseDatos,cont)+"\n");
        cont++;
      }
      this.vista.botonEliminar.addActionListener(this);
      this.vista.botonLimpiar.addActionListener(this);
      this.vista.botonMostrarEstructuraEliminar.addActionListener(this);
      this.vista.botonVolver.addActionListener(this);
  }  
 
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Eliminar":
        eliminarRegistros();
        break;
      case "Limpiar":
        limpiar();
        break;
      case "Mostrar Estructura de la tabla":
        mostrarEstructuraEliminarReg();
        break;
      case "Volver":
        volverVentanaBDER();
        break;
    }
  }
  
  /**
   * metodo que permite eliminar registros de la base de datos
   */
  public void eliminarRegistros(){
    vista.areaTextoRegistros.setText(null);
    String condicion= (String)vista.comboBoxCondicionEli.getSelectedItem();
    String texto= vista.textoCondicion1.getText();
    String texto2=vista.textoCondicion2.getText();
    String estructuraMostrar=vista.areaEstructura.getText();
    List lista2=new List();
    lista2=dao.ConstruirStringIngresar(estructuraMostrar);
    List lista3=new List();
    lista3=dao.ConstruirStringIngresar(texto);
    List listaPrintear=new List();
    if(texto.length()==0 && texto2.length()==0){
      long startTime = System.currentTimeMillis();
      String eliminados= String.valueOf(dao.PrintearEliminarRegistros(VentanaBaseDatosEliminarRegistros.baseDatos,vista.textoTablaEliminarRegistros.getText(),texto,texto2,""));
      long endTime = System.currentTimeMillis() - startTime;
      vista.areaTextoRegistros.append("La cantidad de registros eliminados son " + eliminados+ "  -  Duracion: "+ endTime +" ms");      
    }else if(vista.ValidarCondicion(condicion,texto,texto2)==true){
       if(dao.VerificarEstructuraSeleccionarDatos(lista3,lista2 )){
         long startTime = System.currentTimeMillis();
         String eliminados= String.valueOf(dao.PrintearEliminarRegistros(VentanaBaseDatosEliminarRegistros.baseDatos,vista.textoTablaEliminarRegistros.getText(),texto,texto2,condicion));
         long endTime = System.currentTimeMillis() - startTime;
         vista.areaTextoRegistros.append("La cantidad de registros eliminados son " + eliminados+ "  -  Duracion: "+ endTime +" ms");
       }else{
         JOptionPane.showMessageDialog(null," El dato de la condicion esta incorrecto"); 
       } 
    }else{
      JOptionPane.showMessageDialog(null,"Error en la condicion, los elementos ingresados no son del mismo tipo o la condicion es incopatible");
    }   
  }

  /**
   * metodo que permite volver a la ventana anterior 
   */
  public void volverVentanaBDER(){
    vista.setVisible(false);
    vista.atrasVentanaBDER();
  }
  
  /**
   * metodo que permite mostrar la estructura de la tabla
   */
  public void mostrarEstructuraEliminarReg(){
    vista.areaEstructura.setText(null);
    int cont=0;
    int cont2= dao.largoDocEstructura(VentanaBaseDatosEliminarRegistros.baseDatos,vista.textoTablaEliminarRegistros.getText());
    for(int i=cont; i< cont2;i++){
      if (cont+1==cont2){
        vista.areaEstructura.append(dao.printearEstructuraTabla(VentanaBaseDatosEliminarRegistros.baseDatos,vista.textoTablaEliminarRegistros.getText(),cont));
        cont++;
      }else{
        vista.areaEstructura.append(dao.printearEstructuraTabla(VentanaBaseDatosEliminarRegistros.baseDatos,vista.textoTablaEliminarRegistros.getText(),cont)+",");
        cont++;   
      }
    }
    
  }
  
  /**
   * metodo para limpiar la ventana
   */
  public void limpiar(){
    vista.setVisible(false);
    vista.limpiar();
  }
  
 
}
