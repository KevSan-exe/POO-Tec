package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import vista.VentanaAdmi;
import vista.VentanaInicial;

/**
 * Clase controlador de la ventana con las funciones del administrador
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorAdmi implements ActionListener {
  public VentanaAdmi vista;
  
  /**
   * Constructor vacio de la clase ControladorAdmi
   */
  public ControladorAdmi(){
    this.vista.botonRegistrarUsuario.addActionListener(this);
    this.vista.botonEliminarUsuario.addActionListener(this);
    this.vista.botonCerrarSesion.addActionListener(this);
  }
  
  /**
   * Constructor de la clase ControladorAdmi
   * @param pVista ventana con las funciones de admin 
   */
  public ControladorAdmi(VentanaAdmi pVista){
    vista = pVista;   
    this.vista.botonRegistrarUsuario.addActionListener(this);
    this.vista.botonEliminarUsuario.addActionListener(this);
    this.vista.botonCerrarSesion.addActionListener(this);
  }
  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Registrar Usuario Final":
        registrarUsuarioFinal();
        break;
      case "Eliminar Usuario Final":
        EliminarUsuarioFinal();
        break;
      case "Cerrar Sesion":
        CerrarSesion();
        break;
      default:
        break;
    }
  }
  
  /**
   * metodo que abre la ventana de registrar usuario final
   */
  public void registrarUsuarioFinal(){
      vista.setVisible(false);
      vista.abrirVentanaSiguienteRegistrarUsuarioFinal();
  }
  
  /**
   *metodo que abre la ventana de eliminar usuario final 
   */
  public void EliminarUsuarioFinal(){
    vista.setVisible(false);
    vista.abrirVentanaSiguienteEliminarUusarioFinal();
  }
  
  /**
   * metodo que devuelve a la ventana anterior
   */
  public void CerrarSesion() {
    vista.setVisible(false);
    vista.cerrarSesion();
  }
}
