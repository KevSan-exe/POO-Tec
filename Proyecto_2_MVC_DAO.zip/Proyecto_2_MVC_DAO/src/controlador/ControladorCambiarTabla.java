package controlador;

import dao.CambiarTablaDAOXML;
import dao.CambiarTablaDao;
import dao.CrearTablaDAOXML;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;
import vista.CambiarNombreTabla;
import vista.VentanaBaseDatosCambiarTabla;
import vista.VentanaInicial;

/**
 * Clase controlador para cambiar el nombre de la tabla
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public class ControladorCambiarTabla implements ActionListener {
    public CambiarNombreTabla vista;
    public CambiarTablaDao dao;
    
  /**
   * metodo constructor para la clase ControladorCambiarTabla
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorCambiarTabla(CambiarNombreTabla pVista){
    vista=pVista;
    dao= new CambiarTablaDAOXML();
    CrearTablaDAOXML print= new CrearTablaDAOXML();
    vista.areaTextoMostrarTablas.setText(null);
    int cont=0;
      int cont2= print.largoDocTablas(VentanaBaseDatosCambiarTabla.baseDatosCT);
      for(int i=0; i< cont2;i++){
        vista.areaTextoMostrarTablas.append(print.PrintearTablas(VentanaBaseDatosCambiarTabla.baseDatosCT,cont)+"\n");
        cont++;
      }
      this.vista.botonAceptarCambiarNombreTabla.addActionListener(this);
      this.vista.botonVolverCambiarNombreTabla.addActionListener(this);
  }  
 
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        try {
          cambiarNombre();
        } catch (ParserConfigurationException ex) {
          Logger.getLogger(ControladorCambiarTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
          Logger.getLogger(ControladorCambiarTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
          Logger.getLogger(ControladorCambiarTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
          Logger.getLogger(ControladorCambiarTabla.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;
      case "Volver":
        volverVentanaUF();
        break;
    }
  }
  
  /**
   * Metodo para cambiar el nombre de la tabla
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws TransformerException 
   */
  public void cambiarNombre() throws ParserConfigurationException, SAXException, IOException, TransformerException{
    if(vista.validarNombre(vista.textoNombreTablaNuevo.getText())==true){
      if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario,VentanaBaseDatosCambiarTabla.baseDatosCT)){
        if(vista.recorrerCambiarNombre(VentanaBaseDatosCambiarTabla.baseDatosCT,vista.textoNombreTablaNuevo.getText())==true){
          JOptionPane.showMessageDialog(null,"El nombre de la tabla de datos ya existe");
        }else if(vista.textoNombreTablaNuevo.getText().length()<= 12){
          if(vista.validarCambiarNombreTabla(vista.textoNombreTablaAntiguo.getText(), VentanaBaseDatosCambiarTabla.baseDatosCT)){
            dao.changeTagName(VentanaBaseDatosCambiarTabla.baseDatosCT, vista.textoNombreTablaAntiguo.getText(), vista.textoNombreTablaNuevo.getText());
            JOptionPane.showMessageDialog(null,"Se cambio el nombre de la tabla con exito");
            CrearTablaDAOXML print= new CrearTablaDAOXML();
            vista.areaTextoMostrarTablas.setText(null);
            int cont=0;
            int cont2= print.largoDocTablas(VentanaBaseDatosCambiarTabla.baseDatosCT);
            for(int i=0; i< cont2;i++){
              vista.areaTextoMostrarTablas.append(print.PrintearTablas(VentanaBaseDatosCambiarTabla.baseDatosCT,cont)+"\n");
              cont++;
            }
          }else{
            JOptionPane.showMessageDialog(null,"El nombre de la tabla esta incorrecto");
          }
        }else{
          JOptionPane.showMessageDialog(null,"El nombre de la tabla es mayor que 12 caracteres");
        }
      }else{
        JOptionPane.showMessageDialog(null,"Tabla no pertenece a este usuario"); 
      }
    }else{
      JOptionPane.showMessageDialog(null,"El nuevo nombre de la tabla posee numeros o caracteres especiales");
    }    
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void volverVentanaUF(){
    vista.setVisible(false);
    vista.atrasVentanaUF();
  }
  
 
}
