package controlador;

import dao.CrearTablaDAOXML;
import dao.EliminarRegistrosDAOXML;
import dao.EliminarRegistrosDao;
import dao.SeleccionarDatosDAOXML;
import dao.SeleccionarDatosDao;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.EliminarRegistros;
import vista.VentanaBaseDatosEliminarRegistros;
import vista.VentanaBaseDatosSeleccionarDatos;
import vista.VentanaSeleccionarDatos;

/**
 * clase que funciona como controlador de selccionar datos de una base de datos
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public class ControladorSeleccionarDatos implements ActionListener {
    public VentanaSeleccionarDatos vista;
    public SeleccionarDatosDao dao;
    

  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorSeleccionarDatos(VentanaSeleccionarDatos pVista){
    vista=pVista;
    dao= new SeleccionarDatosDAOXML();
    CrearTablaDAOXML print= new CrearTablaDAOXML();
    vista.textoMostrarTablasSeleccionar.setText(null);
    int cont=0;
      int cont2= print.largoDocTablas(VentanaBaseDatosSeleccionarDatos.baseDatos);
      for(int i=0; i< cont2;i++){
        vista.textoMostrarTablasSeleccionar.append(print.PrintearTablas(VentanaBaseDatosSeleccionarDatos.baseDatos,cont)+"\n");
        cont++;
      }
      this.vista.botonSeleccionarDatos.addActionListener(this);
      this.vista.botonLimpiar.addActionListener(this);
      this.vista.botonMostrarEstructuraEliminarRegistros.addActionListener(this);
      this.vista.botonVolver.addActionListener(this);
  }  
 
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Seleccionar":
        eliminarRegistros();
        break;
      case "Limpiar":
        limpiar();
        break;
      case "Mostrar estructura de la tabla":
        mostrarEstructuraEliminarReg();
        break;
      case "Volver":
        volverVentanaBDER();
        break;
    }
  }
  
  /**
   * metodo para eliminar registro
   */
  public void eliminarRegistros(){
    vista.textoRegistrosEncontrados.setText(null);
    String condicion= (String)vista.comboBoxCondicion.getSelectedItem();
    String texto= vista.textoCondicion.getText();
    String texto2=vista.textoCondicion2.getText();
    String estructuraMostrar=vista.textoMostrarEstructuraSeleccionar.getText();
    String seleccion= vista.textoSeleccionarDatos.getText();
    List lista=new List();
    lista=dao.ConstruirStringIngresar(seleccion);
    List lista2=new List();
    lista2=dao.ConstruirStringIngresar(estructuraMostrar);
    List lista3=new List();
    lista3=dao.ConstruirStringIngresar(texto);
    List listaPrintear=new List();
    long startTime = System.currentTimeMillis();
    if(vista.ValidarCondicion(condicion,texto,texto2)==true){
      if(dao.VerificarEstructuraSeleccionarDatos(lista, lista2)==true){
        if(texto.length()==0 && texto2.length()==0){
          listaPrintear=dao.PrintearSeleccionarDatos(VentanaBaseDatosSeleccionarDatos.baseDatos, vista.textoTablaSeleccionar.getText(), lista, texto, texto2, "");
          for(int i=0; i< listaPrintear.getItemCount();i++){  
            vista.textoRegistrosEncontrados.append(listaPrintear.getItem(i)+"\n");
          }
          long endTime = System.currentTimeMillis() - startTime;
          vista.textoRegistrosEncontrados.append("\nDuracion: "+ endTime +" ms");
        }else if(dao.VerificarEstructuraSeleccionarDatos(lista3,lista2 )){
          listaPrintear=dao.PrintearSeleccionarDatos(VentanaBaseDatosSeleccionarDatos.baseDatos, vista.textoTablaSeleccionar.getText(), lista, texto, texto2, condicion);
          for(int i=0; i< listaPrintear.getItemCount();i++){  
            vista.textoRegistrosEncontrados.append(listaPrintear.getItem(i)+"\n");
          }
          long endTime = System.currentTimeMillis() - startTime;
          vista.textoRegistrosEncontrados.append("\nDuracion: "+ endTime +" ms");
        }else{
           JOptionPane.showMessageDialog(null,"Datos de la condicion no pertenecen a la tabla");
        }
      }else{
         JOptionPane.showMessageDialog(null,"Los datos ingresados en campos a seleccionar no pertenecen a la tabla"); 
      } 
    }else{
      JOptionPane.showMessageDialog(null,"Error en la condicion, los elementos ingresados no son del mismo tipo o la condicion es incopatible");
    } 
  }

  /**
   * metodo para volver a la ventana anterior
   */
  public void volverVentanaBDER(){
    vista.setVisible(false);
    vista.atrasVentanaBDER();
  }
  
  /**
   * metodo para mostrar los registros que se almacenan en la base de datos
   */
  public void mostrarEstructuraEliminarReg(){
    vista.textoMostrarEstructuraSeleccionar.setText(null);
    int cont=0;
    int cont2= dao.largoDocEstructura(VentanaBaseDatosSeleccionarDatos.baseDatos,vista.textoTablaSeleccionar.getText());
    for(int i=cont; i< cont2;i++){
      if (cont+1==cont2){
        vista.textoMostrarEstructuraSeleccionar.append(dao.printearEstructuraTabla(VentanaBaseDatosSeleccionarDatos.baseDatos,vista.textoTablaSeleccionar.getText(),cont));
        cont++;
      }else{
        vista.textoMostrarEstructuraSeleccionar.append(dao.printearEstructuraTabla(VentanaBaseDatosSeleccionarDatos.baseDatos,vista.textoTablaSeleccionar.getText(),cont)+",");
        cont++;   
      }
    }
    
  }
  
  /**
   * metodo para limpiar la pantalla
   */
  public void limpiar(){
    vista.setVisible(false);
    vista.limpiar();
  }
  
 
}
