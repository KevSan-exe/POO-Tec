
package controlador;

import dao.CrearTablaDAOXML;
import dao.IngresarRegistrosDAOXML;
import dao.IngresarRegistrosDao;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import vista.InsertarRegistros;
import vista.VentanaBaseDatosParaIngresar;

/**
 * Metodo controlador de la funcion de insertar registros
 * @author Kevin Sanchez, Kevin Lanzas, Daniel Barrantes
 */
public class ControladorInsertarRegistros implements ActionListener {
    public InsertarRegistros vista;
    public IngresarRegistrosDao dao;

    
  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorInsertarRegistros(InsertarRegistros pVista){
    vista=pVista;
    dao=new IngresarRegistrosDAOXML();
    CrearTablaDAOXML print= new CrearTablaDAOXML();
    vista.areaMostrarTablas.setText(null);
    int cont=0;
      int cont2= print.largoDocTablas(VentanaBaseDatosParaIngresar.datos);
      for(int i=0; i< cont2;i++){
        vista.areaMostrarTablas.append(print.PrintearTablas(VentanaBaseDatosParaIngresar.datos,cont)+"\n");
        cont++;
      }
      this.vista.botonInsertar.addActionListener(this);
      this.vista.botonVolverInsertar.addActionListener(this);
      this.vista.botonMostrarEstructura.addActionListener(this);
  }  
 
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Insertar":
        try {
          insertarTabla();
        } catch (Exception ex) {
          Logger.getLogger(ControladorInsertarRegistros.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;
      case "Volver":
        volverVentanaUF();
        break;
      case "Mostrar estructura de la tabla":
        mostrarEstructuraIngresar();
        break;
    }
  }
  
  /**
   * Metodo para insertar los registros a la tabla
   * @throws Exception 
   */
  public void insertarTabla() throws Exception {
    String nombreDeTabla=vista.textoTablaAModificar.getText();
    String datosIngresar= vista.textoDatosIngresar.getText();
    List lista= new List();
    lista=dao.ConstruirStringIngresar(datosIngresar);
    List lista2=new List();
    lista2=dao.ConstruirStringIngresar(vista.areaMostrarEstructura.getText());
    if(vista.ValidarSupport(lista, lista2)==true && vista.estructuralargoInsertar(lista2)== lista.getItemCount()){
      dao.agregarRegistros(VentanaBaseDatosParaIngresar.datos, nombreDeTabla, lista, lista2);
      JOptionPane.showMessageDialog(null,"Se inserto el registro exitosamente");
    }else{
      JOptionPane.showMessageDialog(null,"Tipo de dato incorrecto");
    } 
  }

  /**
   * metodo para volver a la ventana anterior
   */
  public void volverVentanaUF(){
    vista.setVisible(false);
    vista.atrasVentanaBDI();
  }
  
  /**
   * metodo para mostrar la estructura de la tabla
   */
  public void mostrarEstructuraIngresar(){
    vista.areaMostrarEstructura.setText(null);
    int cont=0;
    int cont2= dao.largoDocEstructura(VentanaBaseDatosParaIngresar.datos,vista.textoTablaAModificar.getText());
    for(int i=cont; i< cont2;i++){
      if (cont+1==cont2){
        vista.areaMostrarEstructura.append(dao.printearEstructuraTabla(VentanaBaseDatosParaIngresar.datos,vista.textoTablaAModificar.getText(),cont));
        cont++;
      }else{
        vista.areaMostrarEstructura.append(dao.printearEstructuraTabla(VentanaBaseDatosParaIngresar.datos,vista.textoTablaAModificar.getText(),cont)+",");
        cont++;   
      }
    }
  }
  
 
}
