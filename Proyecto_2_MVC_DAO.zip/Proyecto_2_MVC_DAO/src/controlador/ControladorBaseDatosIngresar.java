/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import dao.VentanaBaseDatosCrearTablaDAOXML;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaBaseDatosParaIngresar;
import vista.VentanaInicial;

/**
 * Clase controlador para ingresar a la base de datos
 * @author Daniel Barrantes, Kevin Lanzas, Kevin Sanchez
 */
public class ControladorBaseDatosIngresar implements ActionListener {
  public VentanaBaseDatosParaIngresar vista;


  /**
   * metodo constructor de la clase ControladorInicioSesion
   * @param pVista ventana de inicio sesion
   */  
  public ControladorBaseDatosIngresar(VentanaBaseDatosParaIngresar pVista){
    vista = pVista; 
    int cont=6;
    VentanaBaseDatosCrearTablaDAOXML printear= new VentanaBaseDatosCrearTablaDAOXML();
    int cont2= printear.largoDocumento(VentanaInicial.usuario);
    for(int i=cont; i< cont2;i++){
      vista.areaTextoBaseDatos.append(printear.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
      cont++;
    }
    this.vista.botonAceptar.addActionListener(this);
    this.vista.botonVolver.addActionListener(this);
  }
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        avanzaInsertarRegistros();
        break;
      case "Volver":
        cerrarVentanaBaseIngresar();
        break;
    }
  }
  /**
   * metodo logIn que redirecciona a las funciones de administrador o usuario final
   * segun el tipo de usuario que se ingrese
   */
  public void avanzaInsertarRegistros(){
    if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, vista.textoBaseDatoss.getText())==true){
      VentanaBaseDatosParaIngresar.datos=vista.textoBaseDatoss.getText();
      vista.setVisible(false);
      vista.ingresarRegistros();
    }else{
      JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
    }
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaBaseIngresar() {
    vista.setVisible(false);
    vista.atrasBaseDatosIngresar();
  }
}
