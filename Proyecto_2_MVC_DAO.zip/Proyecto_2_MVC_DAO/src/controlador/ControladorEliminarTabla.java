
package controlador;

import dao.CambiarTablaDAOXML;
import dao.CambiarTablaDao;
import dao.CrearTablaDAOXML;
import dao.EliminarTablaDAOXML;
import dao.EliminarTablaDao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;
import vista.CambiarNombreTabla;
import vista.EliminarTabla;
import vista.VentanaBaseDatosCambiarTabla;
import vista.VentanaBaseDatosEliminarTabla;
import vista.VentanaInicial;

/**
 * Controlador para la funcion eliminar tabla
 * @author Daniel Barrante, Kevin Lanzas, Kevin Sanchez
 */
public class ControladorEliminarTabla implements ActionListener {
    public EliminarTabla vista;
    public EliminarTablaDao dao;

    
  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorEliminarTabla(EliminarTabla pVista){
    vista=pVista;
    dao= new EliminarTablaDAOXML();
    CrearTablaDAOXML print= new CrearTablaDAOXML();
    vista.areaMostrarTablasET.setText(null);
    int cont=0;
      int cont2= print.largoDocTablas(VentanaBaseDatosEliminarTabla.baseDatosET);
      for(int i=0; i< cont2;i++){
        vista.areaMostrarTablasET.append(print.PrintearTablas(VentanaBaseDatosEliminarTabla.baseDatosET,cont)+"\n");
        cont++;
      }
      this.vista.botonAceptarEliminarTabla.addActionListener(this);
      this.vista.botonVolverEliminarTabla.addActionListener(this);
  }  
 
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        try {
          eliminarTabla();
        } catch (TransformerException ex) {
          Logger.getLogger(ControladorEliminarTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
          Logger.getLogger(ControladorEliminarTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
          Logger.getLogger(ControladorEliminarTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
          Logger.getLogger(ControladorEliminarTabla.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;
      case "Volver":
        volverVentanaUF();
        break;
    }
  }
  
  /**
   * Metodo para eliminar una tabla de una base datos
   * @throws TransformerException
   * @throws TransformerConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws ParserConfigurationException 
   */
  public void eliminarTabla() throws TransformerException, TransformerConfigurationException, SAXException, IOException, ParserConfigurationException{
    if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario,VentanaBaseDatosEliminarTabla.baseDatosET)==true){
      if(dao.eliminarTabla(VentanaBaseDatosEliminarTabla.baseDatosET, vista.textoTablaEliminar.getText())){
        JOptionPane.showMessageDialog(null,"La tabla fue eliminada correctamente");
        CrearTablaDAOXML print= new CrearTablaDAOXML();
        vista.areaMostrarTablasET.setText(null);
        int cont=0;
        int cont2= print.largoDocTablas(VentanaBaseDatosEliminarTabla.baseDatosET);
        for(int i=0; i< cont2;i++){
          vista.areaMostrarTablasET.append(print.PrintearTablas(VentanaBaseDatosEliminarTabla.baseDatosET,cont)+"\n");
          cont++;
        }
      }else{
        JOptionPane.showMessageDialog(null,"La tabla no existe, los datos son incorrectos o la tabla tiene datos");
      }
    }else{
      JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
    }
  }

  /**
   * Metodo para volver a la ventana anterior
   */
  public void volverVentanaUF(){
    vista.setVisible(false);
    vista.atrasVentanaBDET();
  }
  
 
}
