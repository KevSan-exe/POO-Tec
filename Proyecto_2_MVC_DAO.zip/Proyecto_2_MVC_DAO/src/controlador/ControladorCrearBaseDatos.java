
package controlador;

import dao.CrearBaseDatosDAOXML;
import dao.CrearBaseDatosUsuarioFinalDao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import vista.CrearBaseDatosUsuarioFinal;
import vista.VentanaInicial;

/**
 * Clase controlador para crear una base de datos 
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorCrearBaseDatos implements ActionListener {
  public CrearBaseDatosUsuarioFinal vista;
  public CrearBaseDatosUsuarioFinalDao dao;

  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorCrearBaseDatos(CrearBaseDatosUsuarioFinal pVista){
    vista=pVista;
    dao= new CrearBaseDatosDAOXML();
    this.vista.botonCrearBase.addActionListener(this);
    this.vista.botonVolverCBD.addActionListener(this);
  }  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Crear":
        crearBaseDatos();
        break;
      case "Atras":
        atrasVentana();
        break;
      default:
        break;
    }
  }
  
  /**
   * metodo para crear la base de datos
   */
  public void crearBaseDatos(){
    if(vista.validarNombre(vista.cajaTextoNombreDatos.getText())){  
      if(vista.recorrerNombreBaseDatos(vista.cajaTextoNombreDatos.getText())){
        JOptionPane.showMessageDialog(null,"El nombre de la base de datos ya existe");
      }else if(vista.cajaTextoNombreDatos.getText().length()<= 12){
         try {
           dao.crearBaseDatos(vista.cajaTextoNombreDatos.getText());
           dao.AgregarBaseDatosAUsuarios(VentanaInicial.usuario, vista.cajaTextoNombreDatos.getText());
           dao.agregarBaseDatos(vista.cajaTextoNombreDatos.getText());
           JOptionPane.showMessageDialog(null,"Base de datos creada con exito");
         }catch (ParserConfigurationException | TransformerException ex) {
           Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(Level.SEVERE, null, ex);
         }catch (Exception ex) {
           Logger.getLogger(CrearBaseDatosUsuarioFinal.class.getName()).log(Level.SEVERE, null, ex);
         }
      }else{
        JOptionPane.showMessageDialog(null,"Base de datos es mayor que 12 caracteres");
      }
    }else{
      JOptionPane.showMessageDialog(null,"El nombre de la base de datos posee numeros o caracteres especiales"); 
    } 
  }
  /**
   * metodo para volver a la ventana anterior
   */
  public void atrasVentana() {
    vista.setVisible(false);
    vista.devolverVentanaUF();
  }
}

