
package controlador;

import dao.CrearTablaDAOXML;
import dao.CrearTablaDao;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import vista.CrearTabla;
import vista.VentanaBaseDatosCambiarTabla;
import vista.VentanaBaseDatosCrearTabla;
import vista.VentanaInicial;

/**
 * Clase controlador para el requerimiento de crear tabla
 * @author Kevin Sanchez, Kevin Lanzas, Daniel Barrantes
 */
  public class ControladorCrearTabla implements ActionListener {
    public CrearTabla vista;
    public CrearTablaDao dao;
    
  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorCrearTabla(CrearTabla pVista){
    vista=pVista;
    dao= new CrearTablaDAOXML();
    int cont=0;
      int cont2= dao.largoDocTablas(VentanaBaseDatosCrearTabla.baseDatosCT);
      for(int i=0; i< cont2;i++){
        vista.areaTextoMostrarTablasCT.append(dao.PrintearTablas(VentanaBaseDatosCrearTabla.baseDatosCT,cont)+"\n");
        cont++;
      }
      this.vista.botonAgregarAUnaTabla.addActionListener(this);
      this.vista.botonAgregarTabla.addActionListener(this);
      this.vista.botonMostrarEstructuraCrearT.addActionListener(this);
      this.vista.botonVolverCrearTabla.addActionListener(this);
  }  
 
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Agregar a una tabla":
        try {
          agregarATabla();
        } catch (SAXException ex) {
          Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
          Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
          Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;
      case "Agregar":
        try {
          agregar();
        } catch (ParserConfigurationException ex) {
          Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
          Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
          Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(ControladorCrearTabla.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;

      case "Mostrar Estructura de la tabla":
        mostrarEstructura();
        break;
      case "Volver":
        atras();
        break;
      default:
        break;
    }
  }
  
  /**
   * Metodo para agregar un tabla a una base de datos
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws Exception 
   */
  public void agregar() throws ParserConfigurationException, SAXException, IOException, Exception{
    if(vista.areaTextoNombre.getText().length()<=12){
      if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, VentanaBaseDatosCrearTabla.baseDatosCT)==true){
        if(vista.validarNombre(vista.areaTextoNombre.getText())==true){
          if(vista.validarNombreTabla(vista.areaTextoNombre.getText(),VentanaBaseDatosCrearTabla.baseDatosCT)==true){
            JOptionPane.showMessageDialog(null,"El nombre de la tabla ya existe");
          }else{
            dao.agregarTabla(VentanaBaseDatosCrearTabla.baseDatosCT, vista.areaTextoNombre.getText(), vista.areaTextoNombreCampo.getText(), (String) vista.comboBoxTabla.getSelectedItem(),vista.checkRequerido.isSelected());
            JOptionPane.showMessageDialog(null,"La tabla se agrego a la tabla con exito");
          }
        }else{
          JOptionPane.showMessageDialog(null,"El nombre de la tabla contiene numeros o caracteres especiales");
        }
      }else{
        JOptionPane.showMessageDialog(null,"Base de datos no pertenece al usuario"); 
      }
    }else{
      JOptionPane.showMessageDialog(null,"El nombre de la base de datos supera los 12 caracteres"); 
    }
  }
  
  /**
   * metodo para agregar la tabla a las que tiene acceso el usuario
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws Exception 
   */
  public void agregarATabla() throws ParserConfigurationException, SAXException, IOException, Exception{
    if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, VentanaBaseDatosCrearTabla.baseDatosCT)==true){
      if(vista.validarNombreTabla(vista.areaTextoNombre.getText(), VentanaBaseDatosCrearTabla.baseDatosCT)==false){
        JOptionPane.showMessageDialog(null,"El nombre de la tabla no existe");
      }else if(vista.validarRepetidos(vista.areaTextoNombre.getText(), VentanaBaseDatosCrearTabla.baseDatosCT, vista.areaTextoNombreCampo.getText())==true){
        dao.agregarTabla(VentanaBaseDatosCrearTabla.baseDatosCT, vista.areaTextoNombre.getText(), vista.areaTextoNombreCampo.getText(), (String) vista.comboBoxTabla.getSelectedItem(),vista.checkRequerido.isSelected());
        JOptionPane.showMessageDialog(null,"Los elementos se agregaron a la tabla con exito");
      }else{
        JOptionPane.showMessageDialog(null,"El nombre del caampo  ya existe");  
      }      
    }else{
      JOptionPane.showMessageDialog(null,"El nombre de la tabla no existe");
    }
  }
  
  /**
   * metodo para mostrar la estructura que presentara la tabla
   */
  public void mostrarEstructura(){
    vista.areaTextoTablas.setText(null);
    List lista=new List();
    try {
      lista=dao.printearEstructuraCrear(VentanaBaseDatosCrearTabla.baseDatosCT, vista.areaTextoNombre.getText());
        for(int i=0; i< lista.getItemCount();i++){
          vista.areaTextoTablas.append(lista.getItem(i)+"\n");
        }
      }catch (SAXException | ParserConfigurationException | IOException ex) {
         Logger.getLogger(CrearTabla.class.getName()).log(Level.SEVERE, null, ex);
      }  
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void atras() {
    vista.setVisible(false);
    vista.atrasVentanaBaseDatosCT();
  }
}
