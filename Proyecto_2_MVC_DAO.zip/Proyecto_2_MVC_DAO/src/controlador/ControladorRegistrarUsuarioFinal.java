package controlador;

import dao.RegistrarUsuarioFinalDAOXML;
import dao.RegistrarUsuarioFinalDao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.UsuarioFinal;
import vista.RegistrarUsuarioFinal;

/**
 * clase controlador de la ventana para registrar usuario finales
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorRegistrarUsuarioFinal implements ActionListener {
  public RegistrarUsuarioFinal vista;
  public RegistrarUsuarioFinalDao dao;
  public UsuarioFinal modelo;

  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final 
   */
  public ControladorRegistrarUsuarioFinal(RegistrarUsuarioFinal pVista){
    vista=pVista;
    dao= new RegistrarUsuarioFinalDAOXML();
    this.vista.botonRegistrar.addActionListener(this);
    this.vista.botonAtras.addActionListener(this);
  }  
  
  /**
   * metodo constructor para la clase ControladorRegistrarUsuarioFinal
   * @param pVista ventana para registrar usuario final
   * @param pModelo usuario final que se va a ingresar
   */
  public ControladorRegistrarUsuarioFinal(RegistrarUsuarioFinal pVista, UsuarioFinal pModelo){
    vista = pVista;  
    modelo= pModelo;
    dao= new RegistrarUsuarioFinalDAOXML();
    this.vista.botonRegistrar.addActionListener(this);
    this.vista.botonAtras.addActionListener(this);
  }
  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Registrar":
        Registrar();
        break;
      case "Atras":
        cerrarVentanaLogin();
        break;
      default:
        break;
    }
  }
  
  /**
   * metodo para registrar al usuarioFinal
   */
  public void Registrar(){
    String nombreUsuario = vista.textoNombreUsuario.getText();
    if (vista.ValidarCorrectos(nombreUsuario) == false){
      String Nombre= vista.textoNombre.getText();
      String puesto= vista.textoPuesto.getText();
      String telefono= vista.textoTelefono.getText();
      modelo= new UsuarioFinal(Nombre,nombreUsuario,nombreUsuario,puesto,telefono);
      dao.agregarUsuarios(modelo);
      dao.mandarMail(nombreUsuario, modelo.getContrasenia());
    }else{
      JOptionPane.showMessageDialog(null, "El usuario indicado ya se encuentra registrado");
    }
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaLogin() {
    vista.cerrar();
  }
}
