
package controlador;

import dao.VentanaBaseDatosCrearTablaDAOXML;
import dao.VentanaBaseDatosCrearTablaDao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaBaseDatosCrearTabla;
import vista.VentanaInicial;

/**
 * Metodo controlador para obtener el nombre de la base de datos y crear una tabla
 * @author Daniel Barrantes, Kevin Sanchez, Kevin Lanzas
 */
public class ControladorBaseDatosCrearTabla implements ActionListener {
  public VentanaBaseDatosCrearTabla vista;
  public VentanaBaseDatosCrearTablaDao dao;

  /**
   * metodo constructor de la clase ControladorInicioSesion
   * @param pVista ventana de inicio sesion
   */  
  public ControladorBaseDatosCrearTabla(VentanaBaseDatosCrearTabla pVista){
    vista = pVista; 
    dao= new VentanaBaseDatosCrearTablaDAOXML();
    this.vista.botonAceptarCT.addActionListener(this);
    this.vista.botonVolverCT.addActionListener(this);
    this.vista.mostrarBaseDatosCT.addActionListener(this);
  }
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        avanzaCrearTabla();
        break;
      case "Volver":
        cerrarVentanaBaseCT();
        break;
      case "Mostrar Base datos disponibles":
        mostrarBaseDatosCT();
        break;
      default:
        break;
    }
  }
  /**
   * metodo logIn que redirecciona a las funciones de administrador o usuario final
   * segun el tipo de usuario que se ingrese
   */
  public void avanzaCrearTabla(){
   if(vista.ValidarBasesDatosUsuario(VentanaInicial.usuario, vista.textoBaseDatosCrearTabla.getText())==true){
     VentanaBaseDatosCrearTabla.baseDatosCT=vista.textoBaseDatosCrearTabla.getText();
     vista.setVisible(false);
     vista.avanzarVentanaCrearTabla();
     
   }else{
     JOptionPane.showMessageDialog(null,"La base de datos no pertenece a este usuario");
   } 
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaBaseCT() {
    vista.setVisible(false);
    vista.atrasVentanaUF();
  }
  public void mostrarBaseDatosCT() {
    vista.areaTextoMostrarBaseCT.setText(null);
    int cont=6;
    int cont2= dao.largoDocumento(VentanaInicial.usuario);
    for(int i=cont; i< cont2;i++){
      vista.areaTextoMostrarBaseCT.append(dao.PrintearBasesDatos(VentanaInicial.usuario,cont)+"\n");
      cont++;
    }
  }
}
