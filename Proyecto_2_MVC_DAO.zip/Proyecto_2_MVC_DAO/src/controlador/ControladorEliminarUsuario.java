package controlador;

import dao.EliminarUsuarioDAOXML;
import dao.EliminarUsuarioDao;
import dao.RegistrarUsuarioFinalDAOXML;
import dao.RegistrarUsuarioFinalDao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.transform.TransformerException;
import modelo.UsuarioFinal;
import vista.EliminarUsuario;
import vista.RegistrarUsuarioFinal;

/**
 *clase que es controlador de la ventana para eliminar usuarios
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorEliminarUsuario implements ActionListener {
  public EliminarUsuario vista;
  public EliminarUsuarioDao dao;

  /**
   * metodo constructor del controlador para la ventana de eliminar usuarios
   * @param pVista ventana donde se eliminan los usuarios
   */
  public ControladorEliminarUsuario(EliminarUsuario pVista){
    vista=pVista;
    dao= new EliminarUsuarioDAOXML();
    this.vista.mostrarUsuarios.addActionListener(this);
    this.vista.botonEliminarUsuarioFinal.addActionListener(this);
    this.vista.botonAtrasEliminar.addActionListener(this);  
  }  
  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Mostrar Usuarios Disponbles":
        mostrarUsuario();
        break;
      case "Eliminar":
        try {
          eliminarUsuario();
        } catch (TransformerException ex) {
          Logger.getLogger(ControladorEliminarUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        break;
      case "Volver":
        volverAdmi();
        break;
      default:
        break;
    }
  }
  
  /**
   * metodo que permite la eliminacion de un usuario 
   * @throws TransformerException 
   */
  public void eliminarUsuario() throws TransformerException{
    String nombreUsuarioEli= vista.textoEliminar.getText();
    boolean eliminado=dao.eliminarUsuario(nombreUsuarioEli);
    if (eliminado==true){
      JOptionPane.showMessageDialog(null,"Se elimino el usuario con exito");
    }else{
      JOptionPane.showMessageDialog(null,"Usuario no encontrado o los datos son incorrectos");
    }    
  }
  
  /**
   * metodo para mostrar los usuarios almacenados en la base de datos
   */
  public void mostrarUsuario(){
    vista.areaMostrarUsuarios.setText(null);
    int cont=0;
    int cont2= dao.prueba();
    for(int i=0; i< cont2;i++){
      vista.areaMostrarUsuarios.append(dao.recorrer(cont)+"\n");
      cont++;
    }
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void volverAdmi(){
    vista.volverAdmin();
  }
}    

