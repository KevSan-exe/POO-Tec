package controlador;
        
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import vista.VentanaInicial;

/**
 * clase controlador de la ventana de incio de sesion
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class ControladorInicioSesion implements ActionListener {
  public VentanaInicial vista;

  /**
   * metodo constructor de la clase ControladorInicioSesion
   * @param pVista ventana de inicio sesion
   */  
  public ControladorInicioSesion(VentanaInicial pVista){
    vista = pVista;   
    this.vista.botonAceptar.addActionListener(this);
    this.vista.botonCancelar.addActionListener(this);
  }
  
  /**
   * metodo para recibir los clicks en los botones y realizar sus funciones
   * @param e commando de un boton 
   */
  public void actionPerformed(ActionEvent e) {
    switch(e.getActionCommand()){
      case "Aceptar":
        logIn();
        break;
      case "Salir":
        cerrarVentanaLogin();
        break;
      default:
        break;
    }
  }
  
  /**
   * metodo logIn que redirecciona a las funciones de administrador o usuario final
   * segun el tipo de usuario que se ingrese
   */
  public void logIn(){
    if (vista.datosCorrectosAdministrador() == true){
      String usuario=vista.textoUsuario.getText();
      VentanaInicial.usuario= usuario;
      vista.setVisible(false);
      vista.abrirVentanaSiguienteAdministrador();
    }else if (vista.datosCorrectosUsuarioFinal(vista.textoUsuario.getText(), vista.textoContrasena.getText())==true){ 
      String usuario=vista.textoUsuario.getText();
      VentanaInicial.usuario= usuario;
      vista.setVisible(false);
      vista.abrirVentanaSiguienteUsuarioFinal();
    }else{
      JOptionPane.showMessageDialog(vista, "El usuario indicado no existe");
    }
  }
  
  /**
   * metodo para volver a la ventana anterior
   */
  public void cerrarVentanaLogin() {
    vista.cerrar();
  }
}



