package modelo;
        
/**
 * Clase la cual presenta los datos de los usuarios finales y permite realizar sus funciones
 * @author Kevin Sanchez, Daniel Barrantes, Kevin Lanzas
 */
public class UsuarioFinal extends Usuario{
  private String puesto;
  private String telefono;
  private String contrasenia;
  
          
  /**
   * Metodo constructor de la clase UsuarioFinal
   * @param pNombre es de tipo String y es el nombre del usuario
   * @param pCorreo es de tipo String y es el correo del usuario
   * @param pUsuario es de tipo String y es el correo del usuario
   * @param pPuesto es de tipo String y es el puesto del usuario
   * @param pTelefono  es de tipo String y es el telefono del usuario
   */
  public UsuarioFinal (String pNombre, String pCorreo, String pUsuario, String pPuesto, String pTelefono){
    super(pNombre,pCorreo, pUsuario);
    setUsuario(pCorreo);
    setPuesto(pPuesto);
    setTelefono(pTelefono);
    setContrasenia();
  }
  
  public void setPuesto(String pPuesto){
    puesto = pPuesto;
  }
  
  public void setTelefono(String pTelefono){
    telefono = pTelefono;
  }
  
  public void setContrasenia(){
    contrasenia = PasswordGenerator.getPassword()+PasswordGenerator.getPinNumber()+
    PasswordGenerator.getPinMayuscula()+PasswordGenerator.getPinEspeciales();
  }
  
  public String getPuesto(){
    return puesto;
  }
  
  public String getTelefono(){
    return telefono;
  }
  
  public String getContrasenia(){
    return contrasenia;
  }
}
