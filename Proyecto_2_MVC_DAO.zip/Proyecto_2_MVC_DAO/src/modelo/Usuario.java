package modelo;

/**
 * Clase padre la cual heredan Admin y Usuario Final
 * @author Kevin Lanzas, Kevin Sanchez, Daniel Barrantes
 */
public class Usuario{
  protected String nombre;
  protected String correo;
  protected String usuario;
  
  /**
   * Metodo constructor de la clase Usuario
   * @param pNombre es de tipo String y es el nombre del usuario
   * @param pCorreo es de tipo String y es el correo del usuario
   * @param pUsuario es de tipo String y es el correo del usuario
   */
  public Usuario(String pNombre, String pCorreo, String pUsuario){
    setNombre(pNombre);
    setCorreo(pCorreo);
    setUsuario(pUsuario);
  }
  
  public void setNombre(String pNombre){
    nombre = pNombre;
  }
  
  public void setCorreo(String pCorreo){
    correo = pCorreo;
  }
  
  public void setUsuario(String pUsuario){
    usuario = pUsuario;
  }
  
  public String getNombre(){
    return nombre;
  }
  
  public String getCorreo(){
    return correo;
  }
  
  public String getUsuario(){
    return usuario;
  }
}
