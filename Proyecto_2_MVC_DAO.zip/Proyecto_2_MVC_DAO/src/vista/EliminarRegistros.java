package vista;
import controlador.ControladorBaseDatosEliminarRegistros;
import controlador.ControladorEliminarRegistros;
import java.awt.Font;
import java.awt.Color;
import java.awt.List;
import javax.swing.JOptionPane;

/**
 *Clase que se encarga de crear la interfaz grafica EliminarRegistros
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class EliminarRegistros extends javax.swing.JFrame {
    /**
     * Metodo constructor de la interfaz grafica EliminarRegistros
     */
  public EliminarRegistros() {
    setSize(500,600);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     *Metodo que se encarga inicializar los componentes de la interfaz EliminarRegistros
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tituloEliminar = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textoTablaEliminarRegistros = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        AreaTextoTablasEliminar = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaEstructura = new javax.swing.JTextArea();
        botonMostrarEstructuraEliminar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        textoCondicion1 = new javax.swing.JTextField();
        comboBoxCondicionEli = new javax.swing.JComboBox<>();
        textoCondicion2 = new javax.swing.JTextField();
        botonEliminar = new javax.swing.JButton();
        botonLimpiar = new javax.swing.JButton();
        botonVolver = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        areaTextoRegistros = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);
        jPanel1.setBackground(Color.white);

        tituloEliminar.setText("Eliminar Registros");
        tituloEliminar.setBounds(60,10,500,30);
        tituloEliminar.setFont(new Font("arial",Font.BOLD,20));

        jLabel2.setText("Tabla:");

        AreaTextoTablasEliminar.setEditable(false);
        AreaTextoTablasEliminar.setColumns(20);
        AreaTextoTablasEliminar.setRows(5);
        AreaTextoTablasEliminar.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                AreaTextoTablasEliminarAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(AreaTextoTablasEliminar);

        jLabel3.setText("Estructura de la tabla:");

        areaEstructura.setEditable(false);
        areaEstructura.setColumns(20);
        areaEstructura.setRows(5);
        areaEstructura.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaEstructuraAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(areaEstructura);

        botonMostrarEstructuraEliminar.setText("Mostrar Estructura de la tabla");
        botonMostrarEstructuraEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarEstructuraEliminarActionPerformed(evt);
            }
        });

        jLabel4.setText("Condicion:");

        comboBoxCondicionEli.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "==", "!=", ">", "<" }));

        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });

        botonLimpiar.setText("Limpiar");
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });

        botonVolver.setText("Volver");
        botonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverActionPerformed(evt);
            }
        });

        areaTextoRegistros.setEditable(false);
        areaTextoRegistros.setColumns(20);
        areaTextoRegistros.setRows(5);
        jScrollPane3.setViewportView(areaTextoRegistros);

        jLabel5.setText("Registros:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(170, 170, 170)
                                .addComponent(tituloEliminar))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel4)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonVolver))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1)
                                    .addComponent(textoTablaEliminarRegistros)))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(117, 117, 117)
                                .addComponent(botonMostrarEstructuraEliminar)
                                .addGap(0, 132, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(textoCondicion1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(comboBoxCondicionEli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(botonEliminar)
                                        .addGap(18, 18, 18)
                                        .addComponent(botonLimpiar)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(textoCondicion2))))))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoTablaEliminarRegistros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonMostrarEstructuraEliminar)
                .addGap(1, 1, 1)
                .addComponent(jLabel4)
                .addGap(2, 2, 2)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoCondicion1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxCondicionEli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textoCondicion2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(botonEliminar)
                            .addComponent(botonLimpiar))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(5, 5, 5)))
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(botonVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 444, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 533, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el areaTextoTablasEliminar de la interfaz EliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void AreaTextoTablasEliminarAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_AreaTextoTablasEliminarAncestorAdded
      
    }//GEN-LAST:event_AreaTextoTablasEliminarAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonVolver de la interfaz EliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverActionPerformed
     
    }//GEN-LAST:event_botonVolverActionPerformed
    /**
     * Metodo que se encarga de configurar el botonLimpiar de la interfaz EliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
     
    }//GEN-LAST:event_botonLimpiarActionPerformed

    private void areaEstructuraAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaEstructuraAncestorAdded
        
    }//GEN-LAST:event_areaEstructuraAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonMostrarEstructuraEliminar de la interfaz EliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonMostrarEstructuraEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMostrarEstructuraEliminarActionPerformed
     
    }//GEN-LAST:event_botonMostrarEstructuraEliminarActionPerformed
    /**
     * Metodo que se encarga de configurar el botonEliminar de la interfaz EliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
      
    }//GEN-LAST:event_botonEliminarActionPerformed

  public boolean ValidarCondicion(String pCondicion,String pTexto, String pTexto2){
    String validado=validarTipo(pTexto);
    String validado2=validarTipo(pTexto2);
    if("String".equals(validado2)){
      if("==".equals(pCondicion) || "!=".equals(pCondicion)){
        return true;
      }else{
        return false;   
      } 
    }else if("Int".equals(validado2)){
      return true;    
    }else if("Logico".equals(validado2)){
      if("==".equals(pCondicion) || "!=".equals(pCondicion)){ 
        return true;
      }else{
        return false;    
      }      
    }else if("Float".equals(validado2)){
      return true;    
    }return false;
  }
  public String validarTipo(String cadena){
    boolean f=true;
    if (f==true){
      try {
        Integer.parseInt(cadena);
        return "Int";
      } catch (NumberFormatException nfe){
        f=false;
      }
    }if(f==false){
      for(int i =0; i<cadena.length(); i++){
        if(cadena.charAt(i) == '.'){
          return "Float";
        }
      }f=true;
    }if(f==true){
      String cadena2 = cadena.toLowerCase();
      if("false".equals(cadena2) || "true".equals(cadena2)){
        return "Logico";
      }
    }return "String";
  }
    
  public void atrasVentanaBDER(){
    VentanaBaseDatosEliminarRegistros vistaBDER= new VentanaBaseDatosEliminarRegistros();
    
    ControladorBaseDatosEliminarRegistros controladorBDER = new ControladorBaseDatosEliminarRegistros(vistaBDER);
        
    controladorBDER.vista.setVisible(true);
    controladorBDER.vista.setLocationRelativeTo(null);
  }
  public void limpiar(){
    EliminarRegistros limpiar= new EliminarRegistros();
    
    ControladorEliminarRegistros controladorER = new ControladorEliminarRegistros(limpiar);
        
    controladorER.vista.setVisible(true);
    controladorER.vista.setLocationRelativeTo(null); 
  }
    /**
     * Metodo main de la interfaz EliminarRegistros
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarRegistros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea AreaTextoTablasEliminar;
    public javax.swing.JTextArea areaEstructura;
    public javax.swing.JTextArea areaTextoRegistros;
    public javax.swing.JButton botonEliminar;
    public javax.swing.JButton botonLimpiar;
    public javax.swing.JButton botonMostrarEstructuraEliminar;
    public javax.swing.JButton botonVolver;
    public javax.swing.JComboBox<String> comboBoxCondicionEli;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    public javax.swing.JTextField textoCondicion1;
    public javax.swing.JTextField textoCondicion2;
    public javax.swing.JTextField textoTablaEliminarRegistros;
    private javax.swing.JLabel tituloEliminar;
    // End of variables declaration//GEN-END:variables
}
