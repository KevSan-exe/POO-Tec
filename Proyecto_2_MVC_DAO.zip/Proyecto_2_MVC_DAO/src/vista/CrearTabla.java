package vista;
import controlador.ControladorBaseDatosCrearTabla;
import controlador.ControladorInicioSesion;
import dao.CrearTablaDAOXML;
import dao.EncriptarDesencriptarDAOXML;
import java.awt.Color;
import java.awt.Font;
import java.awt.List;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Clase que se encarga de crear la interfaz grafica CrearTabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class CrearTabla extends javax.swing.JFrame {
  /**
   * Metodo constructor de la interfaz grafica CrearTabla
   */
  public CrearTabla() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz CrearTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        areaTextoNombre = new javax.swing.JTextField();
        indicacionNombreCampo = new javax.swing.JLabel();
        panelCrearTabla = new javax.swing.JPanel();
        comboBoxTabla = new javax.swing.JComboBox<>();
        botonAgregarTabla = new javax.swing.JButton();
        checkRequerido = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaTextoTablas = new javax.swing.JTextArea();
        botonVolverCrearTabla = new javax.swing.JButton();
        indicacionTipoDato = new javax.swing.JLabel();
        botonAgregarAUnaTabla = new javax.swing.JButton();
        botonMostrarEstructuraCrearT = new javax.swing.JButton();
        areaTextoNombreCampo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaTextoMostrarTablasCT = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        indicacionNombreCampo.setText("Nombre del campo:");

        panelCrearTabla.setLayout(null);
        panelCrearTabla.setBackground(Color.white);

        comboBoxTabla.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "String", "Int", "Logico", "Float" }));
        comboBoxTabla.setToolTipText("");
        comboBoxTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxTablaActionPerformed(evt);
            }
        });

        botonAgregarTabla.setText("Agregar");
        botonAgregarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarTablaActionPerformed(evt);
            }
        });

        checkRequerido.setText("Requerido");
        checkRequerido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkRequeridoActionPerformed(evt);
            }
        });

        areaTextoTablas.setEditable(false);
        areaTextoTablas.setColumns(20);
        areaTextoTablas.setRows(5);
        jScrollPane1.setViewportView(areaTextoTablas);

        botonVolverCrearTabla.setText("Volver");
        botonVolverCrearTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCrearTablaActionPerformed(evt);
            }
        });

        indicacionTipoDato.setText("Tipo del dato:");

        botonAgregarAUnaTabla.setText("Agregar a una tabla");
        botonAgregarAUnaTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarAUnaTablaActionPerformed(evt);
            }
        });

        botonMostrarEstructuraCrearT.setText("Mostrar Estructura de la tabla");
        botonMostrarEstructuraCrearT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarEstructuraCrearTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelCrearTablaLayout = new javax.swing.GroupLayout(panelCrearTabla);
        panelCrearTabla.setLayout(panelCrearTablaLayout);
        panelCrearTablaLayout.setHorizontalGroup(
            panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCrearTablaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(checkRequerido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelCrearTablaLayout.createSequentialGroup()
                                .addComponent(indicacionTipoDato)
                                .addGap(63, 63, 63)
                                .addComponent(comboBoxTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                        .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                                .addComponent(botonAgregarTabla)
                                .addGap(32, 32, 32))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                                .addComponent(botonAgregarAUnaTabla)
                                .addContainerGap())))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonMostrarEstructuraCrearT)
                .addGap(59, 59, 59)
                .addComponent(botonVolverCrearTabla)
                .addContainerGap())
        );
        panelCrearTablaLayout.setVerticalGroup(
            panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCrearTablaLayout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(indicacionTipoDato)
                    .addComponent(comboBoxTabla, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonAgregarAUnaTabla))
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(checkRequerido))
                    .addGroup(panelCrearTablaLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(botonAgregarTabla)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelCrearTablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonVolverCrearTabla)
                    .addComponent(botonMostrarEstructuraCrearT))
                .addGap(41, 41, 41))
        );

        jLabel2.setText("Crear Tabla");
        jLabel2.setBounds(40,10,500,30);
        jLabel2.setFont(new Font("arial",Font.BOLD,20));

        jLabel1.setText("Nombre de Tabla:");

        areaTextoMostrarTablasCT.setEditable(false);
        areaTextoMostrarTablasCT.setColumns(20);
        areaTextoMostrarTablasCT.setRows(5);
        areaTextoMostrarTablasCT.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaTextoMostrarTablasCTAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane2.setViewportView(areaTextoMostrarTablasCT);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(indicacionNombreCampo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(areaTextoNombreCampo)
                .addGap(31, 31, 31))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addComponent(areaTextoNombre))
                .addContainerGap())
            .addComponent(panelCrearTabla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(areaTextoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(indicacionNombreCampo)
                    .addComponent(areaTextoNombreCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelCrearTabla, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonVolverCrearTabla de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCrearTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCrearTablaActionPerformed
      
    }//GEN-LAST:event_botonVolverCrearTablaActionPerformed

    private void checkRequeridoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkRequeridoActionPerformed

    }//GEN-LAST:event_checkRequeridoActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAgregarTabla de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAgregarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarTablaActionPerformed
      
    }//GEN-LAST:event_botonAgregarTablaActionPerformed

    private void comboBoxTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxTablaActionPerformed

    }//GEN-LAST:event_comboBoxTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAgregarAUnaTabla de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAgregarAUnaTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarAUnaTablaActionPerformed
     
    }//GEN-LAST:event_botonAgregarAUnaTablaActionPerformed
    /**
     * Metodo que se encarga de configurar el botonMostrarEstructuraCrearT de la interfaz CrearTabla
     * @param evt 
     */
    private void botonMostrarEstructuraCrearTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMostrarEstructuraCrearTActionPerformed
      
    }//GEN-LAST:event_botonMostrarEstructuraCrearTActionPerformed
    /**
     * Metodo que se encarga de configurar el areaTextoMostrarTablasCT de la interfaz CrearTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaTextoMostrarTablasCTAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaTextoMostrarTablasCTAncestorAdded

    }//GEN-LAST:event_areaTextoMostrarTablasCTAncestorAdded
  
  public boolean ValidarBasesDatosUsuario(String pUsuario,String pNombreBaseDatos){
    try{
      EncriptarDesencriptarDAOXML dencriptadoor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=6; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            if(elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent().equals(pNombreBaseDatos)){
              return true;
            }
          }  
        }
      }return false;   
    }catch (Exception e){} 
     return false;
      
  }
   public boolean validarNombreTabla(String nombre,String pNombreBaseDatos) throws ParserConfigurationException, SAXException, IOException{
    File archivo = new File(pNombreBaseDatos + ".xml");
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    Document document = documentBuilder.parse(archivo);
    Element rootElement = document.getDocumentElement();
      
    for(int i = 0; i<rootElement.getChildNodes().getLength();i++){
      if(rootElement.getChildNodes().item(i).getNodeName().equals(nombre)){
        return true;
      }
    }return false;   
  }
  public boolean validarNombre(String pNombre){
    String texto="abcdefghijklmnopqrstuvwxyz";
    String minusculo=pNombre.toLowerCase();
    int cont=0;  
    for(int i=0;i< pNombre.length();i++){
      for(int j=0; j< texto.length();j++){
        if(minusculo.charAt(i)==texto.charAt(j)){
          cont++;
          break;
        }
      }
    }if(cont==pNombre.length()){
       return true; 
    }else{
       return false;
    }
    
  }
  public boolean validarRepetidos(String pNombreTabla, String pNombreBaseDatos,String pNombreCampo){  
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      CrearTablaDAOXML posicion= new CrearTablaDAOXML();
      int p=posicion.posicionTabla(pNombreTabla,rootElement);
      DOMSource source = new DOMSource(document);
      if(rootElement.getChildNodes().item(p).getChildNodes().getLength()==0){
        return true;    
      }else{
        for(int i=0; i< rootElement.getChildNodes().item(p).getChildNodes().item(0).getChildNodes().getLength(); i++){
          if(rootElement.getChildNodes().item(p).getChildNodes().item(0).getChildNodes().item(i).getNodeName().equals(pNombreCampo)){
            return false; 
          }
        }return true;
      }
    }catch(IOException | ParserConfigurationException | SAXException e){}
      return false;
  }
  
  public void atrasVentanaBaseDatosCT(){
    VentanaBaseDatosCrearTabla vistaBaseDatosCT= new VentanaBaseDatosCrearTabla();
    
    ControladorBaseDatosCrearTabla controladorBaseDatosCT = new ControladorBaseDatosCrearTabla(vistaBaseDatosCT);
        
    controladorBaseDatosCT.vista.setVisible(true);
    controladorBaseDatosCT.vista.setLocationRelativeTo(null);
  }
    /**
     * Metodo main de la interfaz grafica CrearTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea areaTextoMostrarTablasCT;
    public javax.swing.JTextField areaTextoNombre;
    public javax.swing.JTextField areaTextoNombreCampo;
    public javax.swing.JTextArea areaTextoTablas;
    public javax.swing.JButton botonAgregarAUnaTabla;
    public javax.swing.JButton botonAgregarTabla;
    public javax.swing.JButton botonMostrarEstructuraCrearT;
    public javax.swing.JButton botonVolverCrearTabla;
    public javax.swing.JCheckBox checkRequerido;
    public javax.swing.JComboBox<String> comboBoxTabla;
    private javax.swing.JLabel indicacionNombreCampo;
    private javax.swing.JLabel indicacionTipoDato;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelCrearTabla;
    // End of variables declaration//GEN-END:variables
}
