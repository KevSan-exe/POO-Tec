package vista;

import controlador.ControladorCambiarTabla;
import controlador.ControladorUsuarioFinal;
import dao.EncriptarDesencriptarDAOXML;
import java.io.File;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Clase que se encarga de crear la interfaz grafica VentanaBaseDatosCambiarTabla
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class VentanaBaseDatosCambiarTabla extends javax.swing.JFrame {
  public static String baseDatosCT;
  
  /**
  * Metodo constructor de la interfaz grafica VentanaBaseDatosCambiarTabla
  */
  public VentanaBaseDatosCambiarTabla() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaBaseDatosCambiarTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        textoBaseDatos = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaMostrarCambiarNombres = new javax.swing.JTextArea();
        botonAceptarCambiarNombre = new javax.swing.JButton();
        botonVolverCambiarNombres = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingrese la base de datos donde se encuentra la tabla a cambiar tabla");

        jLabel2.setText("Base de datos:");

        areaMostrarCambiarNombres.setEditable(false);
        areaMostrarCambiarNombres.setColumns(20);
        areaMostrarCambiarNombres.setRows(5);
        areaMostrarCambiarNombres.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaMostrarCambiarNombresAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaMostrarCambiarNombres);

        botonAceptarCambiarNombre.setText("Aceptar");
        botonAceptarCambiarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarCambiarNombreActionPerformed(evt);
            }
        });

        botonVolverCambiarNombres.setText("Volver");
        botonVolverCambiarNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCambiarNombresActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 31, Short.MAX_VALUE)
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addComponent(textoBaseDatos))))
                .addGap(27, 27, 27))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addComponent(botonAceptarCambiarNombre)
                .addGap(68, 68, 68)
                .addComponent(botonVolverCambiarNombres)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoBaseDatos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(botonVolverCambiarNombres)
                    .addComponent(botonAceptarCambiarNombre))
                .addContainerGap(98, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar ell areaMostrarCambiarNombres de la interfaz grafica VentanaBaseDatosCambiarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaMostrarCambiarNombresAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaMostrarCambiarNombresAncestorAdded
      
    }//GEN-LAST:event_areaMostrarCambiarNombresAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonAceptarCambiarNombre de la interfaz grafica VentanaBaseDatosCambiarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarCambiarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarCambiarNombreActionPerformed
      
    }//GEN-LAST:event_botonAceptarCambiarNombreActionPerformed
    /**
     * Metodo que se encarga de configurar el botonVolverCambiarNombre de la  interfaz grafica VentanaBaseDatosCambiarTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCambiarNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCambiarNombresActionPerformed
   
    }//GEN-LAST:event_botonVolverCambiarNombresActionPerformed

  public boolean ValidarBasesDatosUsuario(String pUsuario,String pNombreBaseDatos){
    try{
      EncriptarDesencriptarDAOXML dencriptadoor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=6; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            if(elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent().equals(pNombreBaseDatos)){
              return true;
            }
          }  
        }
      }return false;   
    }catch (Exception e){} 
     return false;
      
  }
  
  public void avanzarVentanaCrearTabla(){
    CambiarNombreTabla vistaCambiarTabla= new CambiarNombreTabla();
    
    ControladorCambiarTabla controladorCambiarTabla = new ControladorCambiarTabla(vistaCambiarTabla);
        
    controladorCambiarTabla.vista.setVisible(true);
    controladorCambiarTabla.vista.setLocationRelativeTo(null);  
  }
  
  public void atrasVentanaUF(){
    VentanaUsuarioFinal vistaUF2= new VentanaUsuarioFinal();
    
    ControladorUsuarioFinal controladorUF2 = new ControladorUsuarioFinal(vistaUF2);
        
    controladorUF2.vista.setVisible(true);
    controladorUF2.vista.setLocationRelativeTo(null);
  }
    /**
     * Metodo main de la interfaz grafica VentanaBaseDatosCambiarTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCambiarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCambiarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCambiarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosCambiarTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBaseDatosCambiarTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea areaMostrarCambiarNombres;
    public javax.swing.JButton botonAceptarCambiarNombre;
    public javax.swing.JButton botonVolverCambiarNombres;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextField textoBaseDatos;
    // End of variables declaration//GEN-END:variables
}
