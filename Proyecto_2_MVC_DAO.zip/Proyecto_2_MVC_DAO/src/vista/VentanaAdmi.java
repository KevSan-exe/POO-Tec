package vista;
import controlador.ControladorAdmi;
import controlador.ControladorEliminarUsuario;
import controlador.ControladorInicioSesion;
import controlador.ControladorRegistrarUsuarioFinal;
import java.awt.Color;
import java.awt.Font;
/**
 * Clase que se encarga de crear la interfaz grafica VentanaAdmi
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez 
 */
public class VentanaAdmi extends javax.swing.JFrame {
    
  /**
   * Metodo constructor de la interfaz grafica VentanaAdmi
   */  
  public VentanaAdmi() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
   /**
    * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaAdmi 
    */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelAdmi = new javax.swing.JLabel();
        panelAdmi = new javax.swing.JPanel();
        botonRegistrarUsuario = new javax.swing.JButton();
        botonEliminarUsuario = new javax.swing.JButton();
        botonCerrarSesion = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelAdmi.setText("Seleccione la operacion que desea realizar");
        labelAdmi.setBounds(1234,10,500,30);
        labelAdmi.setFont(new Font("arial",Font.BOLD,20));

        panelAdmi.setLayout(null);
        panelAdmi.setBackground(Color.white);

        botonRegistrarUsuario.setText("Registrar Usuario Final");
        botonRegistrarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarUsuarioActionPerformed(evt);
            }
        });

        botonEliminarUsuario.setText("Eliminar Usuario Final");
        botonEliminarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarUsuarioActionPerformed(evt);
            }
        });

        botonCerrarSesion.setText("Cerrar Sesion");
        botonCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarSesionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelAdmiLayout = new javax.swing.GroupLayout(panelAdmi);
        panelAdmi.setLayout(panelAdmiLayout);
        panelAdmiLayout.setHorizontalGroup(
            panelAdmiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAdmiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAdmiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(botonCerrarSesion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonEliminarUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonRegistrarUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelAdmiLayout.setVerticalGroup(
            panelAdmiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAdmiLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botonRegistrarUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonEliminarUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonCerrarSesion)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(labelAdmi)
                .addContainerGap(75, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(panelAdmi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelAdmi)
                .addContainerGap(112, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(23, 23, 23)
                    .addComponent(panelAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de la configuracion del botonResgitrarUsuario de la interfaz grafica VentanaAdmi
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonRegistrarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarUsuarioActionPerformed
     
    }//GEN-LAST:event_botonRegistrarUsuarioActionPerformed
    /**
     * Metodo que se encarga de la configguracion del botonEliminarUsuario de la interfaz grafica VentanaAdmi
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonEliminarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarUsuarioActionPerformed
   
    }//GEN-LAST:event_botonEliminarUsuarioActionPerformed
    /**
     * Metodo que se encarga de la configuracion del botonCerarSesion  de la  interfazz grafica VentanaAdmi
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarSesionActionPerformed

    }//GEN-LAST:event_botonCerrarSesionActionPerformed

  public void abrirVentanaSiguienteRegistrarUsuarioFinal(){
    RegistrarUsuarioFinal registrar= new RegistrarUsuarioFinal();
    
    ControladorRegistrarUsuarioFinal controladorRegistros = new ControladorRegistrarUsuarioFinal(registrar);   
    
    controladorRegistros.vista.setVisible(true);
    
    controladorRegistros.vista.setLocationRelativeTo(null);
  }
  
  public void abrirVentanaSiguienteEliminarUusarioFinal(){
    EliminarUsuario Eliminar= new EliminarUsuario();
    
    ControladorEliminarUsuario controladorEliminar = new ControladorEliminarUsuario(Eliminar);   
    
    controladorEliminar.vista.setVisible(true);
    
    controladorEliminar.vista.setLocationRelativeTo(null);   
  }
   
  public void cerrarSesion(){
    VentanaInicial inicio= new VentanaInicial();
    
    ControladorInicioSesion controlador = new ControladorInicioSesion(inicio);
       
    controlador.vista.setVisible(true);
    controlador.vista.setLocationRelativeTo(null);  
  }
    /**
     * Metodo main de la interfaz grafica VentanaAdmi
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaAdmi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaAdmi().setVisible(true);
            }
        });
    }
    
   
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton botonCerrarSesion;
    public javax.swing.JButton botonEliminarUsuario;
    public javax.swing.JButton botonRegistrarUsuario;
    private javax.swing.JLabel labelAdmi;
    private javax.swing.JPanel panelAdmi;
    // End of variables declaration//GEN-END:variables
}
