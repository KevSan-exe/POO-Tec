package vista;

import controlador.ControladorEliminarRegistros;
import controlador.ControladorInicioSesion;
import controlador.ControladorUsuarioFinal;
import dao.EncriptarDesencriptarDAOXML;
import java.io.File;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Clase que se encarga de crear la interfaz VentanaBaseDatosEliminarRegistros
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class VentanaBaseDatosEliminarRegistros extends javax.swing.JFrame {
  public static String baseDatos;
    /**
     * Metodo constructor de la interfaz grafica VentanaBaseDatosEliminarRegistros
     */
  public VentanaBaseDatosEliminarRegistros() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica VentanaBaseDatosEliminarRegistros
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        textoBaseDatosEliminar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaBaseDatosEliminar = new javax.swing.JTextArea();
        botonAceptarEliminar = new javax.swing.JButton();
        botonVolverEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingrese la base de datos en la que desea eliminar un registro");

        jLabel2.setText("Base de datos:");

        areaBaseDatosEliminar.setEditable(false);
        areaBaseDatosEliminar.setColumns(20);
        areaBaseDatosEliminar.setRows(5);
        areaBaseDatosEliminar.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaBaseDatosEliminarAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaBaseDatosEliminar);

        botonAceptarEliminar.setText("Aceptar");
        botonAceptarEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarEliminarActionPerformed(evt);
            }
        });

        botonVolverEliminar.setText("Volver");
        botonVolverEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(botonAceptarEliminar)
                .addGap(59, 59, 59)
                .addComponent(botonVolverEliminar)
                .addContainerGap(93, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(textoBaseDatosEliminar))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoBaseDatosEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarEliminar)
                    .addComponent(botonVolverEliminar))
                .addContainerGap(123, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(51, 51, 51))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(298, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de configurar el botonVolverEliminar de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverEliminarActionPerformed
      
    }//GEN-LAST:event_botonVolverEliminarActionPerformed
    /**
     * Metodo que se encarga de configurar el areaBaseDatosEliminar de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaBaseDatosEliminarAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaBaseDatosEliminarAncestorAdded
      
    }//GEN-LAST:event_areaBaseDatosEliminarAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonAceptarEliminar de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarEliminarActionPerformed
      
    }//GEN-LAST:event_botonAceptarEliminarActionPerformed

  public boolean ValidarBasesDatosUsuario(String pUsuario,String pNombreBaseDatos){
    try{
      EncriptarDesencriptarDAOXML dencriptadoor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=6; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            if(elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent().equals(pNombreBaseDatos)){
              return true;
            }
          }  
        }
      }return false;   
    }catch (Exception e){} 
     return false;
      
  }
  public void ingresarRegistros(){
    EliminarRegistros vistaEliminarReg= new EliminarRegistros();
    
    ControladorEliminarRegistros controladorER = new ControladorEliminarRegistros(vistaEliminarReg);
        
    controladorER.vista.setVisible(true);
    controladorER.vista.setLocationRelativeTo(null);   
  }
  public void atrasBaseDatosIngresar(){
    VentanaUsuarioFinal vistaUF6= new VentanaUsuarioFinal();
    
    ControladorUsuarioFinal controladorUF6 = new ControladorUsuarioFinal(vistaUF6);
        
    controladorUF6.vista.setVisible(true);
    controladorUF6.vista.setLocationRelativeTo(null);
  }
    /**
     * Metodo main de la interfaz grafica VentanaBaseDatosEliminarRegistros
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBaseDatosEliminarRegistros.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBaseDatosEliminarRegistros().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea areaBaseDatosEliminar;
    public javax.swing.JButton botonAceptarEliminar;
    public javax.swing.JButton botonVolverEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextField textoBaseDatosEliminar;
    // End of variables declaration//GEN-END:variables
}
