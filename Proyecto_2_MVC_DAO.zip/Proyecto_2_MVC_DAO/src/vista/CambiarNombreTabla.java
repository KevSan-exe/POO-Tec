
package vista;
import controlador.ControladorBaseDatosCambiarTabla;
import controlador.ControladorUsuarioFinal;
import dao.EncriptarDesencriptarDAOXML;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

  /**
   * Clase que se encarga de crear una Interfaz grafica para cambiarle el nombre a la tabla
   * @author Kevin Lanzas,Daniel Barrantes, Kevin Sanchez
   */
public class CambiarNombreTabla extends javax.swing.JFrame {
    
  /**
   * Metodo constructor de la interfaz grafica CambiarNombreTabla
   */
  public CambiarNombreTabla() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     *Metodo que se encarga de inicializar los componentes de la interfaz CambiarNombreTabla
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        textoNombreTablaAntiguo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textoNombreTablaNuevo = new javax.swing.JTextField();
        botonAceptarCambiarNombreTabla = new javax.swing.JButton();
        botonVolverCambiarNombreTabla = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaTextoMostrarTablas = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("Nombre de la tabla");

        jLabel3.setText("Nombre nuevo de la tabla");

        botonAceptarCambiarNombreTabla.setText("Aceptar");
        botonAceptarCambiarNombreTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAceptarCambiarNombreTablaActionPerformed(evt);
            }
        });

        botonVolverCambiarNombreTabla.setText("Volver");
        botonVolverCambiarNombreTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverCambiarNombreTablaActionPerformed(evt);
            }
        });

        jPanel1.setLayout(null);
        jPanel1.setBackground(Color.white);

        areaTextoMostrarTablas.setEditable(false);
        areaTextoMostrarTablas.setColumns(20);
        areaTextoMostrarTablas.setRows(5);
        areaTextoMostrarTablas.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaTextoMostrarTablasAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaTextoMostrarTablas);

        jLabel1.setText("Tablas:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(86, 86, 86))
        );

        jLabel4.setText("Cambiar nombre de la tabla");
        jLabel4.setBounds(40,10,500,30);
        jLabel4.setFont(new Font("arial",Font.BOLD,20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(botonAceptarCambiarNombreTabla)
                .addGap(81, 81, 81)
                .addComponent(botonVolverCambiarNombreTabla)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textoNombreTablaAntiguo, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textoNombreTablaNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
            .addGroup(layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoNombreTablaAntiguo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(textoNombreTablaNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonAceptarCambiarNombreTabla)
                    .addComponent(botonVolverCambiarNombreTabla))
                .addGap(25, 25, 25))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addGap(0, 94, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    /**
     * Metodo que se encarga de configurar el boton aceptar de la interfaz CambiarNombreTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAceptarCambiarNombreTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAceptarCambiarNombreTablaActionPerformed
     
    }//GEN-LAST:event_botonAceptarCambiarNombreTablaActionPerformed
    /**
     * Metodo que se encarga de configurarnel boton volver de la interfaz CambiarNombreTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverCambiarNombreTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverCambiarNombreTablaActionPerformed

    }//GEN-LAST:event_botonVolverCambiarNombreTablaActionPerformed
    /**
     * Metodo que se encarga de la configuracion del JTextArea de la interfaz CambiarNombreTabla
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaTextoMostrarTablasAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaTextoMostrarTablasAncestorAdded
  
    }//GEN-LAST:event_areaTextoMostrarTablasAncestorAdded

  public boolean recorrerCambiarNombre(String pNombreBaseDatos,String pNombreTabla){
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        if(elem.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
          return true;
        }
      }return false;   
    } catch (Exception e){} 
      return false;
  }
  public boolean ValidarBasesDatosUsuario(String pUsuario,String pNombreBaseDatos){
    try{
      EncriptarDesencriptarDAOXML dencriptadoor=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      Element elem=document.getDocumentElement();
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  elem.getChildNodes().getLength(); i++){
        String desen=dencriptadoor.desencriptar(elem.getChildNodes().item(i).getChildNodes().item(2).getTextContent());
        if(desen.equals(pUsuario)){
          for(int j=6; j<elem.getChildNodes().item(i).getChildNodes().getLength();j++){
            if(elem.getChildNodes().item(i).getChildNodes().item(j).getTextContent().equals(pNombreBaseDatos)){
              return true;
            }
          }  
        }
      }return false;   
    }catch (Exception e){} 
     return false;
      
  }
  public boolean validarNombre(String pNombre){
    String texto="abcdefghijklmnopqrstuvwxyz";
    String minusculo=pNombre.toLowerCase();
    int cont=0;  
    for(int i=0;i< pNombre.length();i++){
      for(int j=0; j< texto.length();j++){
        if(minusculo.charAt(i)==texto.charAt(j)){
          cont++;
          break;
        }
      }
    }if(cont==pNombre.length()){
       return true; 
    }else{
       return false;
    }
  }
  public boolean validarCambiarNombreTabla(String pNombreTabla, String pNombreBaseDatos){  
    try{
      File archivo = new File(pNombreBaseDatos + ".xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      
      Element rootElement = document.getDocumentElement();
      Element usuario = document.createElement(pNombreTabla);
      
      DOMSource source = new DOMSource(document);
      if(rootElement.getChildNodes().getLength()==0){
        return false;    
      }else{
        for(int i=0; i< rootElement.getChildNodes().getLength(); i++){
          if(rootElement.getChildNodes().item(i).getNodeName().equals(pNombreTabla)){
            return true; 
          }
        }return false;
      }
    }catch(IOException | ParserConfigurationException | SAXException e){}
      return false;
  }
  public void atrasVentanaUF(){
    VentanaBaseDatosCambiarTabla vistaUF3= new VentanaBaseDatosCambiarTabla();
    
    ControladorBaseDatosCambiarTabla controladorUF3 = new ControladorBaseDatosCambiarTabla(vistaUF3);
        
    controladorUF3.vista.setVisible(true);
    controladorUF3.vista.setLocationRelativeTo(null);
  }
  
    /**
     * Metodo main de la interfaz CambiarNombreTabla
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CambiarNombreTabla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarNombreTabla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea areaTextoMostrarTablas;
    public javax.swing.JButton botonAceptarCambiarNombreTabla;
    public javax.swing.JButton botonVolverCambiarNombreTabla;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextField textoNombreTablaAntiguo;
    public javax.swing.JTextField textoNombreTablaNuevo;
    // End of variables declaration//GEN-END:variables
}
