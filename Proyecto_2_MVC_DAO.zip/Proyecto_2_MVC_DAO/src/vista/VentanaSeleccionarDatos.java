package vista;
import controlador.ControladorBaseDatosSeleccionar;
import controlador.ControladorInicioSesion;
import controlador.ControladorSeleccionarDatos;
import java.awt.Font;
import java.awt.Color;
import java.awt.List;
import javax.swing.JOptionPane;
/**
* Clase que se encarga de crear  la interfaz grafica VentanaSeleccionarDatos
* @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
*/
public class VentanaSeleccionarDatos extends javax.swing.JFrame {
  
  /**
   * Metodo constructor de la interfaz grafica VentanaSeleccionarDatos
   */
  public VentanaSeleccionarDatos() {
    setSize(500,600);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de la inicializacion de los componentes de la interfaz grafica VentanaSeleccionarDatos
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tituloEliminarRegistros = new javax.swing.JLabel();
        indicacionTablasEliminar = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textoMostrarTablasSeleccionar = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textoMostrarEstructuraSeleccionar = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        textoSeleccionarDatos = new javax.swing.JTextField();
        botonLimpiar = new javax.swing.JButton();
        botonVolver = new javax.swing.JButton();
        textoTablaSeleccionar = new javax.swing.JTextField();
        botonMostrarEstructuraEliminarRegistros = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        textoCondicion = new javax.swing.JTextField();
        comboBoxCondicion = new javax.swing.JComboBox<>();
        textoCondicion2 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        textoRegistrosEncontrados = new javax.swing.JTextArea();
        botonSeleccionarDatos = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);
        jPanel1.setBackground(Color.white);

        tituloEliminarRegistros.setText("Mantenimiento de datos");
        tituloEliminarRegistros.setBounds(60,10,500,30);
        tituloEliminarRegistros.setFont(new Font("arial",Font.BOLD,20));

        indicacionTablasEliminar.setText("Tabla:");

        textoMostrarTablasSeleccionar.setEditable(false);
        textoMostrarTablasSeleccionar.setColumns(20);
        textoMostrarTablasSeleccionar.setRows(5);
        textoMostrarTablasSeleccionar.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                textoMostrarTablasSeleccionarAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(textoMostrarTablasSeleccionar);

        jLabel1.setText("Estructura de la tabla:");

        textoMostrarEstructuraSeleccionar.setEditable(false);
        textoMostrarEstructuraSeleccionar.setColumns(20);
        textoMostrarEstructuraSeleccionar.setRows(5);
        jScrollPane2.setViewportView(textoMostrarEstructuraSeleccionar);

        jLabel2.setText("Campos a seleccionar");

        textoSeleccionarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoSeleccionarDatosActionPerformed(evt);
            }
        });

        botonLimpiar.setText("Limpiar");
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });

        botonVolver.setText("Volver");
        botonVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVolverActionPerformed(evt);
            }
        });

        botonMostrarEstructuraEliminarRegistros.setText("Mostrar estructura de la tabla");
        botonMostrarEstructuraEliminarRegistros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarEstructuraEliminarRegistrosActionPerformed(evt);
            }
        });

        jLabel3.setText("Condicion:");

        textoCondicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoCondicionActionPerformed(evt);
            }
        });

        comboBoxCondicion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "==", "!=", ">", "<" }));
        comboBoxCondicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxCondicionActionPerformed(evt);
            }
        });

        textoRegistrosEncontrados.setEditable(false);
        textoRegistrosEncontrados.setColumns(20);
        textoRegistrosEncontrados.setRows(5);
        textoRegistrosEncontrados.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                textoRegistrosEncontradosAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane3.setViewportView(textoRegistrosEncontrados);

        botonSeleccionarDatos.setText("Seleccionar");
        botonSeleccionarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSeleccionarDatosActionPerformed(evt);
            }
        });

        jLabel4.setText("Registros Encontrados:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonSeleccionarDatos)
                .addGap(33, 33, 33)
                .addComponent(botonLimpiar)
                .addGap(113, 113, 113))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 18, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(indicacionTablasEliminar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoTablaSeleccionar))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoSeleccionarDatos))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(107, 107, 107)
                                        .addComponent(botonMostrarEstructuraEliminarRegistros))
                                    .addComponent(jLabel3))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(textoCondicion, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(comboBoxCondicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoCondicion2))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonVolver))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addComponent(tituloEliminarRegistros))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tituloEliminarRegistros)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(indicacionTablasEliminar)
                    .addComponent(textoTablaSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonMostrarEstructuraEliminarRegistros)
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textoSeleccionarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoCondicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxCondicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textoCondicion2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonLimpiar)
                    .addComponent(botonSeleccionarDatos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonVolver)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    /**
     * Metodo que se encarga de configurar el textoMostrarTablasSeleccionar en la interfaz grafica VentanaSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void textoMostrarTablasSeleccionarAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_textoMostrarTablasSeleccionarAncestorAdded
     
     
    }//GEN-LAST:event_textoMostrarTablasSeleccionarAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonMostrarEstruucturaEliminarRegistros de la interfaz grafica VentanaSeleccionarDatos 
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonMostrarEstructuraEliminarRegistrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMostrarEstructuraEliminarRegistrosActionPerformed
      
    }//GEN-LAST:event_botonMostrarEstructuraEliminarRegistrosActionPerformed
    /**
     * Metodo que se encarga de configurar el botonVolver de la interfaz grafica VentanaSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVolverActionPerformed
     
    }//GEN-LAST:event_botonVolverActionPerformed
    /**
     * Metodo que se encarga de configurar el botonLimpiar de la interfazz grafica VentanaSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
     
    }//GEN-LAST:event_botonLimpiarActionPerformed
    /**
     * Metodo que se encarga de configurar el botonSeleccionarDatos de la interfaz grafica VentanaSeleccionarDatos
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonSeleccionarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSeleccionarDatosActionPerformed
      
    }//GEN-LAST:event_botonSeleccionarDatosActionPerformed

    private void comboBoxCondicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxCondicionActionPerformed
    
    }//GEN-LAST:event_comboBoxCondicionActionPerformed

    private void textoCondicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoCondicionActionPerformed
      
    }//GEN-LAST:event_textoCondicionActionPerformed

    private void textoSeleccionarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoSeleccionarDatosActionPerformed

    }//GEN-LAST:event_textoSeleccionarDatosActionPerformed

    private void textoRegistrosEncontradosAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_textoRegistrosEncontradosAncestorAdded
   
    }//GEN-LAST:event_textoRegistrosEncontradosAncestorAdded

  public boolean ValidarCondicion(String pCondicion,String pTexto, String pTexto2){
    String validado=validarTipo(pTexto);
    String validado2=validarTipo(pTexto2);
    if("String".equals(validado2)){
      if("==".equals(pCondicion) || "!=".equals(pCondicion)){
        return true;
      }else{
        return false;   
      } 
    }else if("Int".equals(validado2)){
      return true;    
    }else if("Logico".equals(validado2)){
      if("==".equals(pCondicion) || "!=".equals(pCondicion)){ 
        return true;
      }else{
        return false;    
      }      
    }else if("Float".equals(validado2)){
      return true;    
    }return false;
  }
  public String validarTipo(String cadena){
    boolean f=true;
    if (f==true){
      try {
        Integer.parseInt(cadena);
        return "Int";
      } catch (NumberFormatException nfe){
        f=false;
      }
    }if(f==false){
      for(int i =0; i<cadena.length(); i++){
        if(cadena.charAt(i) == '.'){
          return "Float";
        }
      }f=true;
    }if(f==true){
      String cadena2 = cadena.toLowerCase();
      if("false".equals(cadena2) || "true".equals(cadena2)){
        return "Logico";
      }
    }return "String";
  }
  public void atrasVentanaBDER(){
    VentanaBaseDatosSeleccionarDatos vistaBDSD= new VentanaBaseDatosSeleccionarDatos();
    
    ControladorBaseDatosSeleccionar controladorBDSD = new ControladorBaseDatosSeleccionar(vistaBDSD);
        
    controladorBDSD.vista.setVisible(true);
    controladorBDSD.vista.setLocationRelativeTo(null);
  }
  public void limpiar(){
    VentanaSeleccionarDatos limpiador= new VentanaSeleccionarDatos();
    
    ControladorSeleccionarDatos controladorBDSD2 = new ControladorSeleccionarDatos(limpiador);
        
    controladorBDSD2.vista.setVisible(true);
    controladorBDSD2.vista.setLocationRelativeTo(null);
  }

    /**
     * Metodo qmain de la interfa grafica VentanaSeleccionarDatos
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaSeleccionarDatos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaSeleccionarDatos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton botonLimpiar;
    public javax.swing.JButton botonMostrarEstructuraEliminarRegistros;
    public javax.swing.JButton botonSeleccionarDatos;
    public javax.swing.JButton botonVolver;
    public javax.swing.JComboBox<String> comboBoxCondicion;
    private javax.swing.JLabel indicacionTablasEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    public javax.swing.JTextField textoCondicion;
    public javax.swing.JTextField textoCondicion2;
    public javax.swing.JTextArea textoMostrarEstructuraSeleccionar;
    public javax.swing.JTextArea textoMostrarTablasSeleccionar;
    public javax.swing.JTextArea textoRegistrosEncontrados;
    public javax.swing.JTextField textoSeleccionarDatos;
    public javax.swing.JTextField textoTablaSeleccionar;
    private javax.swing.JLabel tituloEliminarRegistros;
    // End of variables declaration//GEN-END:variables
}
