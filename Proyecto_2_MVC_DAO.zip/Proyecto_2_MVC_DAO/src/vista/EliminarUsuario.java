package vista;
import controlador.ControladorAdmi;
import java.awt.Font;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.transform.TransformerException;

/**
 * Clase que se encarga de crear la interfaz grafica EliminarUsuario
 * @author  Kevin Lanzas, Daniel Barrantes, Kevin Sanchez
 */
public class EliminarUsuario extends javax.swing.JFrame {

    /**
     * Metodo constructor de la interfaz EliminarUsuario
     */
  public EliminarUsuario() {
    setSize(500,300);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }

    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz EliminarUsuario
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelTituloEliminar = new javax.swing.JLabel();
        labelEliminar2 = new javax.swing.JLabel();
        labelMostrarUsuarios = new javax.swing.JLabel();
        botonEliminarUsuarioFinal = new javax.swing.JButton();
        textoEliminar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaMostrarUsuarios = new javax.swing.JTextArea();
        botonAtrasEliminar = new javax.swing.JButton();
        mostrarUsuarios = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelTituloEliminar.setText("Eliminar Usuario");
        labelTituloEliminar.setBounds(1234,10,500,30);
        labelTituloEliminar.setFont(new Font("arial",Font.BOLD,20));

        labelEliminar2.setText("Digite el usuario a eliminar:");

        labelMostrarUsuarios.setText("Usuarios disponibles:");

        botonEliminarUsuarioFinal.setText("Eliminar");
        botonEliminarUsuarioFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarUsuarioFinalActionPerformed(evt);
            }
        });

        textoEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textoEliminarActionPerformed(evt);
            }
        });

        areaMostrarUsuarios.setEditable(false);
        areaMostrarUsuarios.setColumns(20);
        areaMostrarUsuarios.setRows(5);
        areaMostrarUsuarios.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                areaMostrarUsuariosAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(areaMostrarUsuarios);

        botonAtrasEliminar.setText("Volver");
        botonAtrasEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasEliminarActionPerformed(evt);
            }
        });

        mostrarUsuarios.setText("Mostrar Usuarios Disponbles");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(labelEliminar2)
                                    .addComponent(labelMostrarUsuarios))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textoEliminar))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(mostrarUsuarios)
                                    .addComponent(botonEliminarUsuarioFinal)
                                    .addComponent(botonAtrasEliminar))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(labelTituloEliminar)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelTituloEliminar)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelEliminar2)
                    .addComponent(textoEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(labelMostrarUsuarios)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(mostrarUsuarios)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonEliminarUsuarioFinal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonAtrasEliminar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void textoEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textoEliminarActionPerformed

    }//GEN-LAST:event_textoEliminarActionPerformed
    /**
     * Metodo que se encarga de configurar el areaMostrarUsuarios de la interfaz grafica EliminarUsuario
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void areaMostrarUsuariosAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_areaMostrarUsuariosAncestorAdded
      
    }//GEN-LAST:event_areaMostrarUsuariosAncestorAdded
    /**
     * Metodo que se encarga de configurar el botonEliminarUsuarioFinal de la interfaz EliminarUsuario
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonEliminarUsuarioFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarUsuarioFinalActionPerformed
      
    }//GEN-LAST:event_botonEliminarUsuarioFinalActionPerformed
    /**
     * Metodo que se encarga de configurar el botonAtrasEliminar de la interfaz EliminarUsuario
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAtrasEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasEliminarActionPerformed
  
    }//GEN-LAST:event_botonAtrasEliminarActionPerformed

  public void volverAdmin(){
    this.setVisible(false);
    VentanaAdmi volverAdmi= new VentanaAdmi();
    
    ControladorAdmi controladorAdministrador = new ControladorAdmi(volverAdmi);
        
    controladorAdministrador.vista.setVisible(true);
    controladorAdministrador.vista.setLocationRelativeTo(null);
  }
    /**
     * Metodo main de la interfaz grafica EliminarUsuario
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EliminarUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EliminarUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea areaMostrarUsuarios;
    public javax.swing.JButton botonAtrasEliminar;
    public javax.swing.JButton botonEliminarUsuarioFinal;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelEliminar2;
    private javax.swing.JLabel labelMostrarUsuarios;
    private javax.swing.JLabel labelTituloEliminar;
    public javax.swing.JButton mostrarUsuarios;
    public javax.swing.JTextField textoEliminar;
    // End of variables declaration//GEN-END:variables
}
