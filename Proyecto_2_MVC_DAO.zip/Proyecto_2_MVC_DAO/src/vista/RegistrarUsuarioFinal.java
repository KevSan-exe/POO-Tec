package vista;
import controlador.ControladorAdmi;
import dao.EncriptarDesencriptarDAOXML;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
    
/**
 * Clase que se encarga de crear la interfaz grafica RegistrarUsuarioFinal
 * @author Kevin Lanzas, Daniel Barrantes, Kevin Sanchez 
 */
public class RegistrarUsuarioFinal extends javax.swing.JFrame {
  /**
   * Metodo constructor de la interfaz RegistrarUsuarioFinal
   */  
  public RegistrarUsuarioFinal() {
    setSize(500,500);
    setTitle("Ingrese sus datos");
    setLocationRelativeTo(null);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    initComponents();
  }
    /**
     * Metodo que se encarga de inicializar los componentes de la interfaz grafica RegistrarUsuarioFinal
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelRegistrar = new javax.swing.JPanel();
        labelRegistrar = new javax.swing.JLabel();
        labelNombre = new javax.swing.JLabel();
        textoNombre = new javax.swing.JTextField();
        labelPuesto = new javax.swing.JLabel();
        textoPuesto = new javax.swing.JTextField();
        labelNombreUsuario = new javax.swing.JLabel();
        textoNombreUsuario = new javax.swing.JTextField();
        labelTelefono = new javax.swing.JLabel();
        textoTelefono = new javax.swing.JTextField();
        botonRegistrar = new javax.swing.JButton();
        botonAtras = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelRegistrar.setLayout(null);
        panelRegistrar.setBackground(Color.white);

        labelRegistrar.setText("Registrar Usuario Final");
        labelRegistrar.setBounds(1234,10,500,30);
        labelRegistrar.setFont(new Font("arial",Font.BOLD,20));

        labelNombre.setText("Nombre Completo");

        labelPuesto.setText("Puesto en la Compañia");

        labelNombreUsuario.setText("Nombre de Usuario (Correo)");

        labelTelefono.setText("Telefono");

        botonRegistrar.setText("Registrar");
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });

        botonAtras.setText("Atras");
        botonAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRegistrarLayout = new javax.swing.GroupLayout(panelRegistrar);
        panelRegistrar.setLayout(panelRegistrarLayout);
        panelRegistrarLayout.setHorizontalGroup(
            panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRegistrarLayout.createSequentialGroup()
                .addContainerGap(199, Short.MAX_VALUE)
                .addComponent(labelRegistrar)
                .addGap(198, 198, 198))
            .addGroup(panelRegistrarLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRegistrarLayout.createSequentialGroup()
                        .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(labelTelefono)
                            .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(labelNombreUsuario)
                                .addComponent(labelNombre, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(labelPuesto, javax.swing.GroupLayout.Alignment.TRAILING)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textoNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                            .addComponent(textoNombreUsuario)
                            .addComponent(textoPuesto)
                            .addComponent(textoTelefono)))
                    .addGroup(panelRegistrarLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(botonRegistrar)
                        .addGap(98, 98, 98)
                        .addComponent(botonAtras)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRegistrarLayout.setVerticalGroup(
            panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRegistrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelRegistrar)
                .addGap(44, 44, 44)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNombre)
                    .addComponent(textoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelPuesto)
                    .addComponent(textoPuesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNombreUsuario)
                    .addComponent(textoNombreUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textoTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelTelefono))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(panelRegistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonRegistrar)
                    .addComponent(botonAtras))
                .addGap(49, 49, 49))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Metodo que se encarga de la configuracion del botonAtras de la interfaz grafica RegistrarUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasActionPerformed
  
    }//GEN-LAST:event_botonAtrasActionPerformed
    /**
     * Metodo que se encarga de la configuracion del botonRegistrar de la interfaz RegistrarUsuarioFinal
     * @param evt es de tipo java.awt.event.ActionEvent y es un evento
     */
    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
  
    }//GEN-LAST:event_botonRegistrarActionPerformed

    public boolean ValidarCorrectos(String pCorreo){
    try{
      EncriptarDesencriptarDAOXML desencripto=new EncriptarDesencriptarDAOXML();
      File archivo = new File("basededatosusuarios_Admin.xml");
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      Document document = documentBuilder.parse(archivo);
      NodeList childeren = document.getChildNodes();
      for (int i = 0; i <  childeren.item(0).getChildNodes().getLength(); i++){
        for (int j = 0; j < childeren.item(0).getChildNodes().item(i).getChildNodes().getLength(); j++){
          String desencrip=desencripto.desencriptar(childeren.item(0).getChildNodes().item(i).getChildNodes().item(j).getTextContent());
          if(pCorreo.equals(desencrip)){
            return true; 
          }
        }
      }      
    } catch (Exception e){} 
      return false;
  }
    public void cerrar(){
      this.setVisible(false);
      VentanaAdmi admi= new VentanaAdmi();
    
      ControladorAdmi controladorAdmi = new ControladorAdmi(admi);
       
      controladorAdmi.vista.setVisible(true);
      controladorAdmi.vista.setLocationRelativeTo(null);
    }
    /**
     * Metodo main de la interfaz grafica RegistrarUsuarioFinal
     * @param args 
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrarUsuarioFinal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              new RegistrarUsuarioFinal().setVisible(true);   
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton botonAtras;
    public javax.swing.JButton botonRegistrar;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel labelNombreUsuario;
    private javax.swing.JLabel labelPuesto;
    private javax.swing.JLabel labelRegistrar;
    private javax.swing.JLabel labelTelefono;
    private javax.swing.JPanel panelRegistrar;
    public javax.swing.JTextField textoNombre;
    public javax.swing.JTextField textoNombreUsuario;
    public javax.swing.JTextField textoPuesto;
    public javax.swing.JTextField textoTelefono;
    // End of variables declaration//GEN-END:variables
}
